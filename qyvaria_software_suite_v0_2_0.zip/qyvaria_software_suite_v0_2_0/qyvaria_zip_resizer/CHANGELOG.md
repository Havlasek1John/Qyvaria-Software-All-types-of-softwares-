# Changelog

## 0.2.0 — Qyvaria Stable Desktop Upgrade

- Added Linux installer with venv setup, dependency install, desktop icon, app menu entry, and CLI launcher.
- Added Windows installer with venv setup, dependency install, desktop shortcut, and Start Menu entry.
- Added uninstall scripts for Windows and Linux.
- Added doctor diagnostics script.
- Added Qyvaria icon assets.
- Rebuilt build scripts to install PyInstaller automatically in a local build venv.
- Improved Qyvarian UI consistency and desktop behavior.
- Rebuilt the ZIP Resizer GUI into a cleaner advanced tabbed cockpit.
- Added Advanced Recipe controls: dedupe, junk removal, text normalization, timestamp preservation, store-compressed-media mode, manifest/report toggles, compression level, max text transform size.
- Added Archive Map table and proof report viewer.
- Added new recipes: document, web, proof.


# Changelog

## v0.1.1

- Fixed Linux build error: `/usr/bin/python3: No module named PyInstaller`.
- `scripts/build_linux.sh` now creates `.venv-build` and installs PyInstaller automatically.
- Added Linux checks for `python3-venv`, `pip`, and `tkinter`.
- `scripts/build_windows.bat` now also uses `.venv-build` and installs PyInstaller automatically.
- Added `requirements-build.txt`.
