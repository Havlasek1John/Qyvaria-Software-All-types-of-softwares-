from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def test_demo_resize(tmp_path):
    demo = tmp_path / "demo.zip"
    with zipfile.ZipFile(demo, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=1) as z:
        z.writestr("a.txt", b"hello   \r\n" * 1000)
        z.writestr("b.txt", b"hello   \r\n" * 1000)
        z.writestr(".DS_Store", b"junk")
    out = tmp_path / "small.zip"
    result = subprocess.run([sys.executable, "-m", "qyzipresizer", "resize", str(demo), str(out), "--recipe", "maximum"], cwd=ROOT, capture_output=True, text=True)
    assert result.returncode == 0
    assert out.exists()
    assert zipfile.is_zipfile(out)
