from pathlib import Path
import zipfile

out = Path(__file__).with_name("demo_big.zip")
text = ("Qyvaria repeated log line with extra spaces    \r\n" * 5000).encode("utf-8")
config = b'{"mode":"demo","repeat":true}\r\n' * 1000
fake_jpg = b"\xff\xd8\xff" + b"already-compressed-like-data" * 500 + b"\xff\xd9"

with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=1) as z:
    z.writestr("logs/app.log", text)
    z.writestr("logs/app_copy.log", text)
    z.writestr("config/settings.json", config)
    z.writestr("config/settings_duplicate.json", config)
    z.writestr(".DS_Store", b"junk")
    z.writestr("__MACOSX/._junk", b"junk")
    z.writestr("images/photo.jpg", fake_jpg)
    z.writestr("README.txt", b"Qyvaria demo archive\n" * 100)

print(out)
