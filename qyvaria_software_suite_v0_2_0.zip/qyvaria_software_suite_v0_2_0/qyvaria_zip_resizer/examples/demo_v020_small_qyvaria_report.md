# Qyvaria Zip Resizer Report

Generated: `2026-06-15T20:21:23Z`

## Summary

- Input ZIP: `/mnt/data/qyvaria_upgrade_work/qyvaria_zip_resizer/examples/demo_big.zip`
- Output ZIP: `/mnt/data/qyvaria_upgrade_work/qyvaria_zip_resizer/examples/demo_v020_small.zip`
- Original size: `5,079` bytes
- Output size: `1,391` bytes
- Bytes saved: `3,688` bytes
- Percent saved: `72.61%`
- Compression ratio: `0.2739`
- Files before: `8`
- Files after: `4`
- Duplicates removed: `2`
- Junk files removed: `2`
- Transformed files: `2`

## Verification

- Verified: `True`
- Qyvaria Proof Seal: `True`
- Error: `None`

## Warnings

- Some files are already compressed media/documents/archives and may not shrink much.

## Removed Files

- `logs/app_copy.log` — exact_duplicate duplicate of `logs/app.log`
- `config/settings_duplicate.json` — exact_duplicate duplicate of `config/settings.json`
- `.DS_Store` — junk_pattern
- `__MACOSX/._junk` — junk_pattern

## Kept Files

- `logs/app.log` — kept_transformed / deflated
- `config/settings.json` — kept_transformed / deflated
- `images/photo.jpg` — kept / deflated
- `README.txt` — kept / deflated

## Proof Note

Small ZIP output is a compressed delivery package. Keep the original archive when legal, scientific, or audit accuracy requires exact raw preservation.
