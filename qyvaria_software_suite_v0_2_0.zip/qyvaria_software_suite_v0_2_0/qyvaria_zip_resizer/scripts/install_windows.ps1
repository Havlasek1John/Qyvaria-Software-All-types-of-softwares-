$ErrorActionPreference = "Stop"

$AppName = "Qyvaria Zip Resizer"
$Slug = "qyvaria-zip-resizer"
$GuiModule = "qyzipresizer.gui"
$CliModule = "qyzipresizer.cli"
$InstallRoot = Join-Path $env:LOCALAPPDATA ("Qyvaria\qyvaria-zip-resizer")
$SourceDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

Write-Host "Installing $AppName to $InstallRoot"

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $python) { throw "Python 3.10+ is required. Install Python from python.org and enable 'Add Python to PATH'." }
$pycmd = $python.Source

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
Get-ChildItem -Path $InstallRoot -Force | Where-Object { $_.Name -notin @(".venv") } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path (Join-Path $SourceDir "*") -Destination $InstallRoot -Recurse -Force

Push-Location $InstallRoot
& $pycmd -m venv .venv
$venvPython = Join-Path $InstallRoot ".venv\Scripts\python.exe"
& $venvPython -m pip install --upgrade pip setuptools wheel
if (Test-Path "requirements.txt") { & $venvPython -m pip install -r requirements.txt }
if (Test-Path "requirements-dev.txt") { try { & $venvPython -m pip install -r requirements-dev.txt } catch { Write-Warning "Dev requirements skipped: $_" } }
& $venvPython -m pip install -e .
Pop-Location

$GuiBat = Join-Path $InstallRoot "$Slug-gui.bat"
$CliBat = Join-Path $InstallRoot "$Slug-cli.bat"
Set-Content -Path $GuiBat -Encoding ASCII -Value "@echo off`r`ncd /d `"$InstallRoot`"`r`n`"$InstallRoot\.venv\Scripts\pythonw.exe`" -m $GuiModule %*`r`n"
Set-Content -Path $CliBat -Encoding ASCII -Value "@echo off`r`ncd /d `"$InstallRoot`"`r`n`"$InstallRoot\.venv\Scripts\python.exe`" -m $CliModule %*`r`n"

$WshShell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath("Desktop")
$Programs = [Environment]::GetFolderPath("Programs")
$MenuDir = Join-Path $Programs "Qyvaria"
New-Item -ItemType Directory -Force -Path $MenuDir | Out-Null

foreach ($ShortcutPath in @((Join-Path $Desktop "$AppName.lnk"), (Join-Path $MenuDir "$AppName.lnk"))) {
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $GuiBat
    $Shortcut.WorkingDirectory = $InstallRoot
    $Icon = Join-Path $InstallRoot "assets\qyvaria_icon.ico"
    if (Test-Path $Icon) { $Shortcut.IconLocation = $Icon }
    $Shortcut.Description = "Turn big ZIP files into smaller verified ZIP files."
    $Shortcut.Save()
}

Write-Host ""
Write-Host "$AppName installed."
Write-Host "Launch it from Desktop, Start Menu > Qyvaria, or:"
Write-Host "  $GuiBat"
