$ErrorActionPreference = "SilentlyContinue"
$AppName = "Qyvaria Zip Resizer"
$Slug = "qyvaria-zip-resizer"
$InstallRoot = Join-Path $env:LOCALAPPDATA "Qyvaria\$Slug"
$Desktop = [Environment]::GetFolderPath("Desktop")
$Programs = [Environment]::GetFolderPath("Programs")
Remove-Item -Recurse -Force $InstallRoot
Remove-Item -Force (Join-Path $Desktop "$AppName.lnk")
Remove-Item -Force (Join-Path $Programs "Qyvaria\$AppName.lnk")
Write-Host "$AppName removed."
