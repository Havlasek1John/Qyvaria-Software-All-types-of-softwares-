# Qyvaria Zip Resizer

**Qyvaria Zip Resizer** is a Windows/Linux Python app that turns big ZIP files into smaller verified ZIP files.

It uses a Qyvaria-style pipeline:

```text
Big ZIP → Scan → Deduplicate → Remove Junk → Normalize Text → Recompress → Verify → Small ZIP
```

## What it does

- Analyzes ZIP contents without extracting to disk.
- Detects file types.
- Finds exact duplicate files by SHA-256.
- Removes common junk files such as `.DS_Store`, `Thumbs.db`, caches, temp files, and Python bytecode.
- Recompresses with strong ZIP deflate compression.
- Optionally stores already-compressed files when recompressing them is not useful.
- Optionally normalizes text/code/log files.
- Verifies the output ZIP using ZIP integrity checks.
- Creates a JSON proof report and Markdown report.
- Adds `QYVARIA_MANIFEST.json` and report files to the output ZIP.

## Honest compression note

A ZIP can only shrink if there is removable or recompressible material. Archives full of MP4, JPG, PNG, PDF, MP3, 7Z, RAR, or already highly compressed content may not shrink much. The app reports that honestly.

## Requirements

- Python 3.10+
- No required third-party packages

Tkinter is used for the GUI. It is included with many Python installs. On some Linux systems, install it with your package manager, for example:

```bash
sudo apt install python3-tk
```

## Run on Linux

From this folder:

```bash
chmod +x scripts/run_gui_linux.sh scripts/run_cli_linux.sh
./scripts/run_gui_linux.sh
```

CLI:

```bash
python3 -m qyzipresizer analyze path/to/big.zip
python3 -m qyzipresizer resize path/to/big.zip path/to/small.zip --recipe safe
python3 -m qyzipresizer resize path/to/big.zip path/to/small.zip --recipe maximum
```

## Run on Windows

Double-click:

```text
scripts\run_gui_windows.bat
```

CLI:

```bat
scripts\run_cli_windows.bat analyze C:\path\big.zip
scripts\run_cli_windows.bat resize C:\path\big.zip C:\path\small.zip --recipe safe
```

## Recipe presets

- `safe`: safest mode. Deduplicate, remove junk, strong recompression.
- `maximum`: more aggressive. Also normalizes text/code/log files.
- `developer`: removes more development caches/build artifacts.
- `data`: optimized for CSV/JSON/log/data archives.

Show presets:

```bash
python3 -m qyzipresizer presets
```

## Build standalone executable/app

This project works without packaging if Python is installed. The build scripts are optional and create standalone executables using PyInstaller.

Linux:

```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip python3-tk
chmod +x scripts/build_linux.sh
./scripts/build_linux.sh
```

The Linux build script now creates a local `.venv-build` environment and installs PyInstaller automatically inside it.

Windows:

```bat
scripts\build_windows.bat
```

The Windows build script creates a local `.venv-build` environment and installs PyInstaller automatically inside it.

Manual fallback if needed:

```bash
python3 -m pip install --user pyinstaller
python3 -m PyInstaller --name qyzip --onefile qyzipresizer/cli.py
```

Built files appear in `dist/`.

## Output reports

After resizing, the app creates:

- `*_qyvaria_report.json`
- `*_qyvaria_report.md`
- `QYVARIA_MANIFEST.json` inside the output ZIP
- `QYVARIA_REPORT.json` inside the output ZIP
- `QYVARIA_REPORT.md` inside the output ZIP

The report shows:

- original size
- output size
- bytes saved
- files before/after
- duplicates removed
- junk removed
- verification result
- source SHA-256
- output SHA-256
- kept/removed/transformed file list

## Safety

The app does not extract archive contents to a permanent folder. It streams from input ZIP to output ZIP and writes only the final output and reports. It normalizes unsafe archive paths so ZIP path traversal entries are not reproduced as dangerous paths.

Keep the original archive when legal, scientific, or audit accuracy requires exact raw preservation.


---

## Qyvaria Stable Setup v0.2.0

This package includes installers for both Windows and Linux.

### Linux

```bash
chmod +x scripts/install_linux.sh
./scripts/install_linux.sh
```

This installs the app into `~/.local/share/qyvaria/qyvaria-zip-resizer`, adds a launcher in `~/.local/bin`, creates a desktop icon, and adds the app to your Linux app menu.

### Windows

Double-click:

```text
scripts\install_windows.bat
```

This installs the app into `%LOCALAPPDATA%\Qyvaria\qyvaria-zip-resizer`, creates a Desktop shortcut, and adds the app to Start Menu > Qyvaria.

### Doctor test

```bash
python scripts/doctor.py
```
