
from __future__ import annotations

import json
import os
import platform
import queue
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .core import PRESETS, analyze_zip, human_size, load_recipe, resize_zip


COLORS = {
    "bg": "#0b1020",
    "panel": "#111827",
    "panel2": "#152033",
    "card": "#18243a",
    "text": "#e5e7eb",
    "muted": "#94a3b8",
    "line": "#263248",
    "accent": "#8b5cf6",
    "accent2": "#22d3ee",
    "good": "#22c55e",
    "warn": "#f59e0b",
    "bad": "#fb7185",
}


def open_path(path: str | Path) -> None:
    target = str(path)
    system = platform.system()
    if system == "Windows":
        os.startfile(target)  # type: ignore[attr-defined]
    elif system == "Darwin":
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target])


class MetricCard(ttk.Frame):
    def __init__(self, master: tk.Misc, label: str, value: str = "—") -> None:
        super().__init__(master, style="Card.TFrame")
        self.columnconfigure(0, weight=1)
        ttk.Label(self, text=label, style="CardLabel.TLabel").grid(row=0, column=0, sticky="w", padx=14, pady=(12, 2))
        self.value = ttk.Label(self, text=value, style="CardValue.TLabel")
        self.value.grid(row=1, column=0, sticky="w", padx=14, pady=(0, 12))

    def set(self, value: str) -> None:
        self.value.configure(text=value)


class QyvariaZipResizerGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Qyvaria Zip Resizer — Advanced")
        self.geometry("1180x780")
        self.minsize(1040, 680)

        self.input_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.recipe_var = tk.StringVar(value="safe")
        self.status_var = tk.StringVar(value="Ready")
        self.report_json_var = tk.StringVar(value="")
        self.report_md_var = tk.StringVar(value="")
        self.queue: queue.Queue[tuple[str, object]] = queue.Queue()

        self.remove_duplicates_var = tk.BooleanVar(value=True)
        self.remove_junk_var = tk.BooleanVar(value=True)
        self.normalize_text_var = tk.BooleanVar(value=False)
        self.store_compressed_var = tk.BooleanVar(value=True)
        self.preserve_timestamps_var = tk.BooleanVar(value=True)
        self.add_manifest_var = tk.BooleanVar(value=False)
        self.add_report_var = tk.BooleanVar(value=False)
        self.compression_level_var = tk.IntVar(value=9)
        self.max_text_mb_var = tk.IntVar(value=128)

        self._build()
        self._apply_preset()
        self.after(100, self._poll)

    def _build(self) -> None:
        self.configure(bg=COLORS["bg"])
        self._style()

        header = tk.Frame(self, bg=COLORS["bg"])
        header.pack(fill="x", padx=18, pady=(16, 8))
        tk.Label(header, text="Qyvaria Zip Resizer", bg=COLORS["bg"], fg=COLORS["text"],
                 font=("Segoe UI", 24, "bold")).pack(anchor="w")
        tk.Label(header, text="Big ZIP → scan → deduplicate → optimize → recompress → verify → Small ZIP",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Segoe UI", 11)).pack(anchor="w", pady=(2, 0))

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=18, pady=8)

        self.compress_tab = ttk.Frame(self.notebook, style="Main.TFrame")
        self.recipe_tab = ttk.Frame(self.notebook, style="Main.TFrame")
        self.analyze_tab = ttk.Frame(self.notebook, style="Main.TFrame")
        self.report_tab = ttk.Frame(self.notebook, style="Main.TFrame")
        self.log_tab = ttk.Frame(self.notebook, style="Main.TFrame")

        self.notebook.add(self.compress_tab, text="Compress")
        self.notebook.add(self.recipe_tab, text="Advanced Recipe")
        self.notebook.add(self.analyze_tab, text="Archive Map")
        self.notebook.add(self.report_tab, text="Proof Report")
        self.notebook.add(self.log_tab, text="Log")

        self._build_compress_tab()
        self._build_recipe_tab()
        self._build_analyze_tab()
        self._build_report_tab()
        self._build_log_tab()

        footer = tk.Frame(self, bg=COLORS["panel"], highlightbackground=COLORS["line"], highlightthickness=1)
        footer.pack(fill="x", side="bottom")
        self.status = tk.Label(footer, textvariable=self.status_var, bg=COLORS["panel"], fg=COLORS["muted"], anchor="w")
        self.status.pack(fill="x", padx=14, pady=8)

    def _style(self) -> None:
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.style.configure(".", background=COLORS["bg"], foreground=COLORS["text"], fieldbackground=COLORS["panel"])
        self.style.configure("Main.TFrame", background=COLORS["bg"])
        self.style.configure("Panel.TFrame", background=COLORS["panel"])
        self.style.configure("Card.TFrame", background=COLORS["card"], relief="flat")
        self.style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"])
        self.style.configure("Muted.TLabel", background=COLORS["bg"], foreground=COLORS["muted"])
        self.style.configure("Panel.TLabel", background=COLORS["panel"], foreground=COLORS["text"])
        self.style.configure("CardLabel.TLabel", background=COLORS["card"], foreground=COLORS["muted"], font=("Segoe UI", 10, "bold"))
        self.style.configure("CardValue.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=("Segoe UI", 18, "bold"))
        self.style.configure("Accent.TButton", background=COLORS["accent"], foreground="#ffffff", padding=(12, 8), font=("Segoe UI", 10, "bold"))
        self.style.map("Accent.TButton", background=[("active", "#7c3aed")], foreground=[("active", "#ffffff")])
        self.style.configure("TButton", padding=(10, 7))
        self.style.configure("TCheckbutton", background=COLORS["bg"], foreground=COLORS["text"])
        self.style.configure("TRadiobutton", background=COLORS["bg"], foreground=COLORS["text"])
        self.style.configure("TNotebook", background=COLORS["bg"], borderwidth=0)
        self.style.configure("TNotebook.Tab", background=COLORS["panel"], foreground=COLORS["text"], padding=(14, 9))
        self.style.map("TNotebook.Tab", background=[("selected", COLORS["accent"])], foreground=[("selected", "#ffffff")])
        self.style.configure("Treeview", background=COLORS["panel"], fieldbackground=COLORS["panel"],
                             foreground=COLORS["text"], rowheight=27, bordercolor=COLORS["line"])
        self.style.configure("Treeview.Heading", background=COLORS["panel2"], foreground=COLORS["text"], font=("Segoe UI", 9, "bold"))

    def _build_compress_tab(self) -> None:
        top = ttk.Frame(self.compress_tab, style="Main.TFrame")
        top.pack(fill="x", padx=4, pady=4)
        top.columnconfigure(1, weight=1)

        ttk.Label(top, text="Input ZIP").grid(row=0, column=0, sticky="w", padx=6, pady=8)
        ttk.Entry(top, textvariable=self.input_var).grid(row=0, column=1, sticky="ew", padx=8)
        ttk.Button(top, text="Browse", command=self.browse_input).grid(row=0, column=2, padx=4)

        ttk.Label(top, text="Output ZIP").grid(row=1, column=0, sticky="w", padx=6, pady=8)
        ttk.Entry(top, textvariable=self.output_var).grid(row=1, column=1, sticky="ew", padx=8)
        ttk.Button(top, text="Save As", command=self.browse_output).grid(row=1, column=2, padx=4)

        ttk.Label(top, text="Preset").grid(row=2, column=0, sticky="w", padx=6, pady=8)
        preset = ttk.Combobox(top, textvariable=self.recipe_var, values=list(PRESETS.keys()), state="readonly")
        preset.grid(row=2, column=1, sticky="w", padx=8)
        preset.bind("<<ComboboxSelected>>", lambda _e: self._apply_preset())
        ttk.Button(top, text="Apply Preset", command=self._apply_preset).grid(row=2, column=2, padx=4)

        cards = ttk.Frame(self.compress_tab, style="Main.TFrame")
        cards.pack(fill="x", padx=4, pady=(8, 12))
        for i in range(5):
            cards.columnconfigure(i, weight=1)
        self.metric_size = MetricCard(cards, "Original Size")
        self.metric_files = MetricCard(cards, "Files")
        self.metric_dupes = MetricCard(cards, "Duplicate Groups")
        self.metric_potential = MetricCard(cards, "Shrink Potential")
        self.metric_output = MetricCard(cards, "Output Size")
        for idx, card in enumerate([self.metric_size, self.metric_files, self.metric_dupes, self.metric_potential, self.metric_output]):
            card.grid(row=0, column=idx, sticky="ew", padx=6)

        action = ttk.Frame(self.compress_tab, style="Main.TFrame")
        action.pack(fill="x", padx=4, pady=(2, 10))
        ttk.Button(action, text="Analyze ZIP", command=self.analyze, style="Accent.TButton").pack(side="left", padx=4)
        ttk.Button(action, text="Create Small ZIP", command=self.resize, style="Accent.TButton").pack(side="left", padx=4)
        ttk.Button(action, text="Open Output Folder", command=self.open_output_folder).pack(side="left", padx=4)
        ttk.Button(action, text="Open Latest Report", command=self.open_report).pack(side="left", padx=4)

        self.progress = ttk.Progressbar(self.compress_tab, mode="indeterminate")
        self.progress.pack(fill="x", padx=10, pady=6)

        info = tk.Text(self.compress_tab, height=12, bg=COLORS["panel"], fg=COLORS["text"],
                       insertbackground=COLORS["text"], relief="flat", wrap="word")
        info.pack(fill="both", expand=True, padx=10, pady=6)
        info.insert("end",
            "Qyvaria truth note:\n"
            "ZIP files that already contain compressed media, PDFs, or nested archives may not shrink much. "
            "This app still scans, removes exact duplicates, removes junk files, normalizes text when selected, "
            "recompresses safely, and creates a proof report.\n\n"
            "Use Safe for archives you must preserve closely. Use Maximum for text/code/log-heavy ZIP files.\n")
        info.configure(state="disabled")
        self.info_text = info

    def _build_recipe_tab(self) -> None:
        left = ttk.Frame(self.recipe_tab, style="Main.TFrame")
        left.pack(fill="both", expand=True, padx=10, pady=10)
        sections = [
            ("Exact cleanup", [
                ("Remove exact duplicate files", self.remove_duplicates_var),
                ("Remove junk/cache/temp files", self.remove_junk_var),
                ("Normalize text/code/log line endings", self.normalize_text_var),
            ]),
            ("Compression behavior", [
                ("Store already-compressed media when wise", self.store_compressed_var),
                ("Preserve original timestamps", self.preserve_timestamps_var),
                ("Add QYVARIA_MANIFEST.json into output ZIP", self.add_manifest_var),
                ("Add QYVARIA_REPORT files into output ZIP", self.add_report_var),
            ])
        ]
        row = 0
        for title, items in sections:
            ttk.Label(left, text=title, font=("Segoe UI", 13, "bold")).grid(row=row, column=0, sticky="w", pady=(4, 6))
            row += 1
            for label, var in items:
                ttk.Checkbutton(left, text=label, variable=var).grid(row=row, column=0, sticky="w", padx=12, pady=4)
                row += 1

        ttk.Label(left, text="Compression level").grid(row=row, column=0, sticky="w", pady=(18, 4)); row += 1
        ttk.Scale(left, from_=1, to=9, orient="horizontal", variable=self.compression_level_var).grid(row=row, column=0, sticky="ew", padx=12); row += 1
        self.level_label = ttk.Label(left, text="Level 9 = smallest ZIP, slower")
        self.level_label.grid(row=row, column=0, sticky="w", padx=12, pady=(2, 8)); row += 1

        ttk.Label(left, text="Max text transform size (MB)").grid(row=row, column=0, sticky="w", pady=(8, 4)); row += 1
        ttk.Spinbox(left, from_=1, to=1024, textvariable=self.max_text_mb_var, width=10).grid(row=row, column=0, sticky="w", padx=12); row += 1

        ttk.Button(left, text="Preview Recipe JSON", command=self.preview_recipe).grid(row=row, column=0, sticky="w", pady=18)
        left.columnconfigure(0, weight=1)

    def _build_analyze_tab(self) -> None:
        toolbar = ttk.Frame(self.analyze_tab, style="Main.TFrame")
        toolbar.pack(fill="x", padx=10, pady=8)
        ttk.Button(toolbar, text="Refresh Archive Map", command=self.analyze).pack(side="left")
        ttk.Button(toolbar, text="Export Latest Report", command=self.open_report).pack(side="left", padx=8)

        cols = ("path", "type", "size", "compressed", "action", "potential")
        self.tree = ttk.Treeview(self.analyze_tab, columns=cols, show="headings")
        headings = {
            "path": "Path",
            "type": "Type",
            "size": "Size",
            "compressed": "In ZIP",
            "action": "Recommended Action",
            "potential": "Shrink Potential",
        }
        widths = {"path": 430, "type": 120, "size": 90, "compressed": 90, "action": 190, "potential": 130}
        for col in cols:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="w")
        scroll = ttk.Scrollbar(self.analyze_tab, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=(0, 10))
        scroll.pack(side="right", fill="y", padx=(0, 10), pady=(0, 10))

    def _build_report_tab(self) -> None:
        toolbar = ttk.Frame(self.report_tab, style="Main.TFrame")
        toolbar.pack(fill="x", padx=10, pady=8)
        ttk.Button(toolbar, text="Open JSON Report", command=lambda: self._open_if_exists(self.report_json_var.get())).pack(side="left")
        ttk.Button(toolbar, text="Open Markdown Report", command=lambda: self._open_if_exists(self.report_md_var.get())).pack(side="left", padx=8)
        ttk.Button(toolbar, text="Open Output ZIP", command=lambda: self._open_if_exists(self.output_var.get())).pack(side="left", padx=8)
        self.report_text = tk.Text(self.report_tab, bg=COLORS["panel"], fg=COLORS["text"], insertbackground=COLORS["text"],
                                   relief="flat", wrap="word")
        self.report_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.report_text.insert("end", "Run a compression job to see the Qyvaria proof report here.")

    def _build_log_tab(self) -> None:
        tools = ttk.Frame(self.log_tab, style="Main.TFrame")
        tools.pack(fill="x", padx=10, pady=8)
        ttk.Button(tools, text="Clear Log", command=lambda: self.log.delete("1.0", "end")).pack(side="left")
        self.log = tk.Text(self.log_tab, height=20, bg=COLORS["panel"], fg=COLORS["text"], insertbackground=COLORS["text"], relief="flat")
        self.log.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def browse_input(self) -> None:
        path = filedialog.askopenfilename(title="Select ZIP", filetypes=[("ZIP files", "*.zip"), ("All files", "*.*")])
        if path:
            self.input_var.set(path)
            if not self.output_var.get():
                p = Path(path)
                self.output_var.set(str(p.with_name(p.stem + "_small.zip")))

    def browse_output(self) -> None:
        path = filedialog.asksaveasfilename(title="Save small ZIP", defaultextension=".zip", filetypes=[("ZIP files", "*.zip")])
        if path:
            self.output_var.set(path)

    def _apply_preset(self) -> None:
        data = load_recipe(self.recipe_var.get())
        self.remove_duplicates_var.set(bool(data.get("remove_duplicates", True)))
        self.remove_junk_var.set(bool(data.get("remove_junk", True)))
        self.normalize_text_var.set(bool(data.get("normalize_text", False)))
        self.store_compressed_var.set(bool(data.get("store_already_compressed_when_wise", True)))
        self.preserve_timestamps_var.set(bool(data.get("preserve_timestamps", True)))
        self.add_manifest_var.set(bool(data.get("add_manifest", False)))
        self.add_report_var.set(bool(data.get("add_report_to_zip", False)))
        self.compression_level_var.set(int(data.get("compression_level", 9)))
        self.max_text_mb_var.set(int(data.get("maximum_single_file_mb_for_text_transform", 128)))

    def _recipe(self) -> dict:
        data = load_recipe(self.recipe_var.get())
        data.update({
            "name": f"{data.get('name', self.recipe_var.get())} + UI Custom",
            "remove_duplicates": self.remove_duplicates_var.get(),
            "remove_junk": self.remove_junk_var.get(),
            "normalize_text": self.normalize_text_var.get(),
            "store_already_compressed_when_wise": self.store_compressed_var.get(),
            "preserve_timestamps": self.preserve_timestamps_var.get(),
            "add_manifest": self.add_manifest_var.get(),
            "add_report_to_zip": self.add_report_var.get(),
            "compression_level": int(self.compression_level_var.get()),
            "maximum_single_file_mb_for_text_transform": int(self.max_text_mb_var.get()),
        })
        return data

    def preview_recipe(self) -> None:
        self.notebook.select(self.report_tab)
        self.report_text.configure(state="normal")
        self.report_text.delete("1.0", "end")
        self.report_text.insert("end", json.dumps(self._recipe(), indent=2))
        self.report_text.configure(state="normal")

    def _validate_paths(self) -> tuple[Path, Path] | None:
        if not self.input_var.get():
            messagebox.showwarning("Missing input", "Choose an input ZIP first.")
            return None
        inp = Path(self.input_var.get())
        if not inp.exists():
            messagebox.showerror("Missing file", f"Input ZIP does not exist:\n{inp}")
            return None
        out = Path(self.output_var.get()) if self.output_var.get() else inp.with_name(inp.stem + "_small.zip")
        self.output_var.set(str(out))
        return inp, out

    def analyze(self) -> None:
        paths = self._validate_paths()
        if not paths:
            return
        inp, _ = paths
        self._run("analyze", lambda: analyze_zip(inp, self._recipe(), progress=self._progress))

    def resize(self) -> None:
        paths = self._validate_paths()
        if not paths:
            return
        inp, out = paths
        if out.exists() and not messagebox.askyesno("Overwrite output?", f"{out.name} already exists. Replace it?"):
            return
        self._run("resize", lambda: resize_zip(inp, out, recipe=self._recipe(), report_dir=out.parent, progress=self._progress))

    def _run(self, kind: str, work) -> None:
        self.progress.start(12)
        self.status_var.set(f"{kind.title()} running...")
        self.log.insert("end", f"\n[{kind}] started\n")
        self.log.see("end")
        def worker():
            try:
                result = work()
                self.queue.put((kind, result))
            except Exception as exc:
                self.queue.put(("error", exc))
        threading.Thread(target=worker, daemon=True).start()

    def _progress(self, message: str) -> None:
        self.queue.put(("progress", message))

    def _poll(self) -> None:
        try:
            while True:
                kind, payload = self.queue.get_nowait()
                if kind == "progress":
                    self.status_var.set(str(payload))
                    self.log.insert("end", f"{payload}\n")
                    self.log.see("end")
                elif kind == "analyze":
                    self.progress.stop()
                    self._render_profile(payload)
                elif kind == "resize":
                    self.progress.stop()
                    self._render_result(payload)
                elif kind == "error":
                    self.progress.stop()
                    self.status_var.set("Error")
                    self.log.insert("end", f"ERROR: {payload}\n")
                    self.log.see("end")
                    messagebox.showerror("Qyvaria Zip Resizer", str(payload))
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _render_profile(self, profile) -> None:
        self.metric_size.set(human_size(profile.original_size))
        self.metric_files.set(str(profile.file_count))
        self.metric_dupes.set(str(len(profile.duplicate_groups)))
        dup_bytes = sum(g.get("duplicate_bytes", 0) for g in profile.duplicate_groups)
        potential = "High" if dup_bytes > profile.original_size * 0.15 else "Medium" if dup_bytes else "Low"
        self.metric_potential.set(f"{potential} ({human_size(dup_bytes)})")
        self.status_var.set("Analysis complete")
        self.tree.delete(*self.tree.get_children())
        for f in sorted(profile.files, key=lambda x: x.original_size, reverse=True):
            self.tree.insert("", "end", values=(
                f.path, f.file_type, human_size(f.original_size), human_size(f.compressed_size),
                f.recommended_action, f.shrink_potential
            ))
        self.notebook.select(self.analyze_tab)
        self.log.insert("end", "Analysis complete.\n")
        self.log.see("end")

    def _render_result(self, result) -> None:
        self.metric_output.set(human_size(result.output_size))
        self.report_json_var.set(result.report_json)
        self.report_md_var.set(result.report_markdown)
        self.status_var.set("Small ZIP created and verified" if result.verified else "Small ZIP created with warnings")
        self.log.insert("end", f"Output: {result.output_zip}\nReport: {result.report_markdown}\n")
        self.log.see("end")
        self._load_markdown_report(result.report_markdown)
        self.notebook.select(self.report_tab)
        seal = "Qyvaria Proof Seal: PASSED" if result.qyvaria_proof_seal else "Qyvaria Proof Seal: WARNING"
        messagebox.showinfo("Compression complete",
                            f"{seal}\n\nOriginal: {human_size(result.original_size)}\nOutput: {human_size(result.output_size)}\nSaved: {human_size(result.bytes_saved)}")

    def _load_markdown_report(self, path: str) -> None:
        self.report_text.configure(state="normal")
        self.report_text.delete("1.0", "end")
        try:
            self.report_text.insert("end", Path(path).read_text(encoding="utf-8"))
        except Exception as exc:
            self.report_text.insert("end", f"Could not read report: {exc}")
        self.report_text.configure(state="normal")

    def open_output_folder(self) -> None:
        if self.output_var.get():
            open_path(Path(self.output_var.get()).parent)

    def open_report(self) -> None:
        path = self.report_md_var.get() or self.report_json_var.get()
        self._open_if_exists(path)

    def _open_if_exists(self, path: str) -> None:
        if not path:
            messagebox.showinfo("No file yet", "No file is available yet.")
            return
        p = Path(path)
        if not p.exists():
            messagebox.showwarning("File missing", f"File not found:\n{p}")
            return
        open_path(p)


def main() -> None:
    app = QyvariaZipResizerGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
