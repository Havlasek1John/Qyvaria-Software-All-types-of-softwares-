"""Qyvaria Zip Resizer: big ZIP to smaller verified ZIP packages."""
__version__ = "0.1.0"
