
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .core import analyze_zip, resize_zip, load_recipe, human_size, PRESETS


def _print_progress(message: str) -> None:
    print(f"[qyvaria] {message}", flush=True)


def cmd_analyze(args: argparse.Namespace) -> int:
    profile = analyze_zip(args.input_zip, load_recipe(args.recipe), progress=_print_progress if args.verbose else None)
    payload = {
        "source_path": profile.source_path,
        "archive_sha256": profile.archive_sha256,
        "original_size": profile.original_size,
        "file_count": profile.file_count,
        "folder_count": profile.folder_count,
        "uncompressed_size": profile.uncompressed_size,
        "compressed_payload_size": profile.compressed_payload_size,
        "type_counts": profile.type_counts,
        "largest_files": profile.largest_files,
        "duplicate_groups": profile.duplicate_groups,
        "warnings": profile.warnings,
    }
    if args.json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        print("\nQyvaria ZIP Analysis")
        print("====================")
        print(f"Input: {profile.source_path}")
        print(f"Archive size: {human_size(profile.original_size)}")
        print(f"Files: {profile.file_count}")
        print(f"Folders: {profile.folder_count}")
        print(f"Uncompressed payload: {human_size(profile.uncompressed_size)}")
        print(f"Payload compressed in source ZIP: {human_size(profile.compressed_payload_size)}")
        print("\nFile types:")
        for k, v in sorted(profile.type_counts.items()):
            print(f"  {k}: {v}")
        print(f"\nDuplicate groups: {len(profile.duplicate_groups)}")
        if profile.duplicate_groups:
            saved = sum(g["duplicate_bytes"] for g in profile.duplicate_groups)
            print(f"Potential duplicate bytes removable: {human_size(saved)}")
        if profile.warnings:
            print("\nWarnings:")
            for w in profile.warnings:
                print(f"  - {w}")
    return 0


def cmd_resize(args: argparse.Namespace) -> int:
    result = resize_zip(
        args.input_zip,
        args.output_zip,
        recipe=args.recipe,
        report_dir=args.report_dir,
        progress=_print_progress if not args.quiet else None,
    )
    print("\nQyvaria ZIP Resize Complete")
    print("===========================")
    print(f"Input: {result.input_zip}")
    print(f"Output: {result.output_zip}")
    print(f"Original size: {human_size(result.original_size)}")
    print(f"Output size: {human_size(result.output_size)}")
    print(f"Saved: {human_size(result.bytes_saved)}")
    print(f"Compression ratio: {result.compression_ratio:.4f}")
    print(f"Files before/after: {result.files_before} -> {result.files_after}")
    print(f"Duplicates removed: {result.duplicates_removed}")
    print(f"Junk removed: {result.junk_removed}")
    print(f"Transformed files: {result.transformed_files}")
    print(f"Verified: {result.verified}")
    print(f"Qyvaria Proof Seal: {result.qyvaria_proof_seal}")
    print(f"JSON report: {result.report_json}")
    print(f"Markdown report: {result.report_markdown}")
    if result.verification_error:
        print(f"Verification error: {result.verification_error}")
    if result.warnings:
        print("\nWarnings:")
        for w in result.warnings:
            print(f"  - {w}")
    return 0 if result.verified else 2


def cmd_presets(args: argparse.Namespace) -> int:
    for name, recipe in PRESETS.items():
        print(f"{name}: {recipe.get('name')}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qyzip",
        description="Qyvaria Zip Resizer: turn big ZIP files into smaller verified ZIP files.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    analyze = sub.add_parser("analyze", help="Analyze a ZIP and estimate shrink potential.")
    analyze.add_argument("input_zip")
    analyze.add_argument("--recipe", default="safe", help="Preset name or recipe JSON path.")
    analyze.add_argument("--json", action="store_true", help="Print JSON output.")
    analyze.add_argument("--verbose", action="store_true")
    analyze.set_defaults(func=cmd_analyze)

    resize = sub.add_parser("resize", help="Create a smaller optimized ZIP.")
    resize.add_argument("input_zip")
    resize.add_argument("output_zip")
    resize.add_argument("--recipe", default="safe", help="Preset name or recipe JSON path: safe, maximum, developer, data.")
    resize.add_argument("--report-dir", default=None)
    resize.add_argument("--quiet", action="store_true")
    resize.set_defaults(func=cmd_resize)

    presets = sub.add_parser("presets", help="Show built-in recipe presets.")
    presets.set_defaults(func=cmd_presets)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
