
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import posixpath
import re
import shutil
import tempfile
import time
import zipfile
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Tuple, Any


CHUNK_SIZE = 1024 * 1024

TEXT_EXTENSIONS = {
    ".txt", ".log", ".csv", ".tsv", ".json", ".jsonl", ".xml", ".html", ".htm", ".css", ".js",
    ".ts", ".tsx", ".jsx", ".py", ".java", ".c", ".cpp", ".h", ".hpp", ".cs", ".go", ".rs",
    ".php", ".rb", ".sh", ".bat", ".ps1", ".md", ".yaml", ".yml", ".ini", ".cfg", ".toml",
    ".sql", ".env.example"
}
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff", ".tif", ".svg"}
DOCUMENT_EXTENSIONS = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".ods", ".odp"}
AUDIO_EXTENSIONS = {".mp3", ".aac", ".ogg", ".flac", ".wav", ".m4a"}
VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v"}
ARCHIVE_EXTENSIONS = {".zip", ".7z", ".rar", ".gz", ".bz2", ".xz", ".tar", ".tgz", ".zst"}

ALREADY_COMPRESSED_EXTENSIONS = IMAGE_EXTENSIONS | DOCUMENT_EXTENSIONS | AUDIO_EXTENSIONS | VIDEO_EXTENSIONS | ARCHIVE_EXTENSIONS

DEFAULT_JUNK_PATTERNS = [
    "__MACOSX/*",
    "*/__MACOSX/*",
    ".DS_Store",
    "*/.DS_Store",
    "Thumbs.db",
    "*/Thumbs.db",
    "*.tmp",
    "*.temp",
    "*.bak",
    "*.swp",
    "*~",
    ".cache/*",
    "*/.cache/*",
    "cache/*",
    "*/cache/*",
    "node_modules/.cache/*",
    "*/node_modules/.cache/*",
    "__pycache__/*",
    "*/__pycache__/*",
    "*.pyc",
    "*.pyo",
    ".pytest_cache/*",
    "*/.pytest_cache/*",
]


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_zip_path(name: str) -> str:
    """Normalize archive member names without extracting to disk."""
    name = name.replace("\\", "/")
    name = posixpath.normpath(name)
    while name.startswith("../"):
        name = name[3:]
    if name in (".", ""):
        name = "unnamed"
    if name.startswith("/"):
        name = name.lstrip("/")
    return name


def extension_of(name: str) -> str:
    return Path(name).suffix.lower()


def classify_file(name: str) -> str:
    ext = extension_of(name)
    if ext in TEXT_EXTENSIONS:
        return "text_code_log"
    if ext in IMAGE_EXTENSIONS:
        return "image"
    if ext in DOCUMENT_EXTENSIONS:
        return "document"
    if ext in AUDIO_EXTENSIONS:
        return "audio"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    if ext in ARCHIVE_EXTENSIONS:
        return "archive"
    if ext:
        return "other"
    return "unknown"


def looks_junk(path: str, patterns: Iterable[str]) -> bool:
    norm = safe_zip_path(path)
    base = posixpath.basename(norm)
    for pattern in patterns:
        if fnmatch.fnmatch(norm, pattern) or fnmatch.fnmatch(base, pattern):
            return True
    return False


def is_probably_text(data: bytes) -> bool:
    if not data:
        return True
    sample = data[:4096]
    if b"\x00" in sample:
        return False
    try:
        sample.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


@dataclass
class FileProfile:
    path: str
    original_size: int
    compressed_size: int
    extension: str
    file_type: str
    sha256: Optional[str] = None
    is_duplicate: bool = False
    duplicate_of: Optional[str] = None
    is_junk: bool = False
    is_already_compressed: bool = False
    recommended_action: str = "keep"
    action_taken: str = "pending"
    shrink_potential: str = "unknown"


@dataclass
class ArchiveProfile:
    source_path: str
    archive_sha256: str
    original_size: int
    file_count: int
    folder_count: int
    uncompressed_size: int
    compressed_payload_size: int
    type_counts: Dict[str, int]
    largest_files: List[Dict[str, Any]]
    duplicate_groups: List[Dict[str, Any]]
    files: List[FileProfile]
    warnings: List[str] = field(default_factory=list)


@dataclass
class ResizeResult:
    input_zip: str
    output_zip: str
    report_json: str
    report_markdown: str
    original_size: int
    output_size: int
    bytes_saved: int
    compression_ratio: float
    files_before: int
    files_after: int
    duplicates_removed: int
    junk_removed: int
    transformed_files: int
    verified: bool
    verification_error: Optional[str]
    qyvaria_proof_seal: bool
    warnings: List[str]


SAFE_SHRINK_RECIPE = {
    "name": "Safe Shrink",
    "remove_duplicates": True,
    "remove_junk": True,
    "junk_patterns": DEFAULT_JUNK_PATTERNS,
    "normalize_text": False,
    "strip_zip_extra_metadata": True,
    "compression": "deflated",
    "compression_level": 9,
    "store_already_compressed_when_wise": True,
    "preserve_timestamps": True,
    "maximum_single_file_mb_for_text_transform": 128,
    "add_manifest": False,
    "add_report_to_zip": False,
}


MAXIMUM_SHRINK_RECIPE = {
    **SAFE_SHRINK_RECIPE,
    "name": "Maximum Shrink",
    "normalize_text": True,
    "remove_junk": True,
    "compression_level": 9,
    "preserve_timestamps": False,
    "maximum_single_file_mb_for_text_transform": 256,
}


DEVELOPER_PACKAGE_RECIPE = {
    **SAFE_SHRINK_RECIPE,
    "name": "Developer Package",
    "normalize_text": True,
    "junk_patterns": DEFAULT_JUNK_PATTERNS + [
        "dist/*", "*/dist/*", "build/*", "*/build/*", ".mypy_cache/*", "*/.mypy_cache/*",
        ".ruff_cache/*", "*/.ruff_cache/*", ".venv/*", "*/.venv/*", "venv/*", "*/venv/*"
    ],
}


DATA_ARCHIVE_RECIPE = {
    **SAFE_SHRINK_RECIPE,
    "name": "Data Archive",
    "normalize_text": False,
    "compression_level": 9,
    "store_already_compressed_when_wise": False,
}


DOCUMENT_ARCHIVE_RECIPE = {
    **SAFE_SHRINK_RECIPE,
    "name": "Document Archive",
    "remove_duplicates": True,
    "remove_junk": True,
    "normalize_text": False,
    "strip_zip_extra_metadata": True,
    "store_already_compressed_when_wise": True,
    "preserve_timestamps": True,
    "add_manifest": True,
    "add_report_to_zip": False,
}

WEB_DELIVERY_RECIPE = {
    **SAFE_SHRINK_RECIPE,
    "name": "Web Delivery",
    "remove_duplicates": True,
    "remove_junk": True,
    "normalize_text": True,
    "strip_zip_extra_metadata": True,
    "store_already_compressed_when_wise": True,
    "preserve_timestamps": False,
    "add_manifest": False,
    "add_report_to_zip": False,
    "maximum_single_file_mb_for_text_transform": 256,
}

PROOF_ARCHIVE_RECIPE = {
    **SAFE_SHRINK_RECIPE,
    "name": "Proof Archive",
    "remove_duplicates": True,
    "remove_junk": False,
    "normalize_text": False,
    "strip_zip_extra_metadata": True,
    "store_already_compressed_when_wise": True,
    "preserve_timestamps": True,
    "add_manifest": True,
    "add_report_to_zip": True,
}


PRESETS = {
    "safe": SAFE_SHRINK_RECIPE,
    "maximum": MAXIMUM_SHRINK_RECIPE,
    "developer": DEVELOPER_PACKAGE_RECIPE,
    "data": DATA_ARCHIVE_RECIPE,
    "document": DOCUMENT_ARCHIVE_RECIPE,
    "web": WEB_DELIVERY_RECIPE,
    "proof": PROOF_ARCHIVE_RECIPE,
}


def load_recipe(recipe: Optional[str | Path | Dict[str, Any]] = None) -> Dict[str, Any]:
    if recipe is None:
        return dict(SAFE_SHRINK_RECIPE)
    if isinstance(recipe, dict):
        merged = dict(SAFE_SHRINK_RECIPE)
        merged.update(recipe)
        return merged
    recipe_str = str(recipe)
    if recipe_str in PRESETS:
        return dict(PRESETS[recipe_str])
    p = Path(recipe_str)
    with p.open("r", encoding="utf-8") as f:
        user_recipe = json.load(f)
    merged = dict(SAFE_SHRINK_RECIPE)
    merged.update(user_recipe)
    return merged


def _hash_member(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> str:
    h = hashlib.sha256()
    with zf.open(info, "r") as src:
        for chunk in iter(lambda: src.read(CHUNK_SIZE), b""):
            h.update(chunk)
    return h.hexdigest()


def analyze_zip(zip_path: str | Path, recipe: Optional[Dict[str, Any]] = None,
                progress: Optional[Callable[[str], None]] = None) -> ArchiveProfile:
    path = Path(zip_path)
    if not path.exists():
        raise FileNotFoundError(path)
    if not zipfile.is_zipfile(path):
        raise ValueError(f"Not a valid ZIP file: {path}")

    recipe = load_recipe(recipe)
    patterns = recipe.get("junk_patterns", DEFAULT_JUNK_PATTERNS)
    files: List[FileProfile] = []
    type_counts: Dict[str, int] = {}
    folder_count = 0
    uncompressed_size = 0
    compressed_payload_size = 0
    duplicate_map: Dict[str, FileProfile] = {}
    duplicate_groups_map: Dict[str, List[FileProfile]] = {}
    warnings: List[str] = []

    if progress:
        progress("Scanning ZIP central directory")

    with zipfile.ZipFile(path, "r") as zf:
        infos = zf.infolist()
        for idx, info in enumerate(infos, start=1):
            if info.is_dir():
                folder_count += 1
                continue

            member_path = safe_zip_path(info.filename)
            ext = extension_of(member_path)
            ftype = classify_file(member_path)
            type_counts[ftype] = type_counts.get(ftype, 0) + 1
            uncompressed_size += info.file_size
            compressed_payload_size += info.compress_size

            profile = FileProfile(
                path=member_path,
                original_size=info.file_size,
                compressed_size=info.compress_size,
                extension=ext,
                file_type=ftype,
                is_junk=looks_junk(member_path, patterns),
                is_already_compressed=ext in ALREADY_COMPRESSED_EXTENSIONS,
            )

            if profile.is_junk:
                profile.recommended_action = "remove_junk"
                profile.shrink_potential = "high"
            elif profile.is_already_compressed:
                profile.recommended_action = "keep_or_store"
                profile.shrink_potential = "low"
            elif ftype == "text_code_log":
                profile.recommended_action = "deflate_strongly"
                profile.shrink_potential = "high"
            else:
                profile.recommended_action = "deflate"
                profile.shrink_potential = "medium"

            # Hash all files for exact duplicate detection. This streams data, not extraction.
            profile.sha256 = _hash_member(zf, info)
            if profile.sha256 in duplicate_map:
                profile.is_duplicate = True
                profile.duplicate_of = duplicate_map[profile.sha256].path
                profile.recommended_action = "remove_duplicate"
                profile.shrink_potential = "high"
                duplicate_groups_map.setdefault(profile.sha256, [duplicate_map[profile.sha256]]).append(profile)
            else:
                duplicate_map[profile.sha256] = profile

            files.append(profile)
            if progress and (idx % 50 == 0 or idx == len(infos)):
                progress(f"Scanned {idx}/{len(infos)} entries")

    largest_files = [
        {
            "path": f.path,
            "size": f.original_size,
            "compressed_size": f.compressed_size,
            "file_type": f.file_type,
            "shrink_potential": f.shrink_potential,
        }
        for f in sorted(files, key=lambda x: x.original_size, reverse=True)[:20]
    ]
    duplicate_groups = [
        {
            "sha256": sha,
            "count": len(group),
            "kept": group[0].path,
            "duplicates": [x.path for x in group[1:]],
            "duplicate_bytes": sum(x.original_size for x in group[1:]),
        }
        for sha, group in duplicate_groups_map.items()
    ]

    if any(f.is_already_compressed for f in files):
        warnings.append("Some files are already compressed media/documents/archives and may not shrink much.")
    if any(f.extension in {".zip", ".7z", ".rar"} for f in files):
        warnings.append("Nested archives were found. This MVP reports them but does not recursively recompress nested archives.")

    return ArchiveProfile(
        source_path=str(path),
        archive_sha256=sha256_file(path),
        original_size=path.stat().st_size,
        file_count=len(files),
        folder_count=folder_count,
        uncompressed_size=uncompressed_size,
        compressed_payload_size=compressed_payload_size,
        type_counts=type_counts,
        largest_files=largest_files,
        duplicate_groups=duplicate_groups,
        files=files,
        warnings=warnings,
    )


def _clone_zipinfo(src: zipfile.ZipInfo, new_name: str, recipe: Dict[str, Any], compress_type: int) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(new_name)
    if recipe.get("preserve_timestamps", True):
        info.date_time = src.date_time
    else:
        info.date_time = time.gmtime()[:6]
    info.comment = b""
    info.extra = b"" if recipe.get("strip_zip_extra_metadata", True) else src.extra
    info.internal_attr = src.internal_attr
    info.external_attr = src.external_attr
    info.create_system = src.create_system
    info.compress_type = compress_type
    return info


def _compression_type_for_member(file_profile: FileProfile, recipe: Dict[str, Any]) -> int:
    method = recipe.get("compression", "deflated").lower()
    if method == "stored":
        return zipfile.ZIP_STORED
    if method == "bzip2":
        return zipfile.ZIP_BZIP2
    if method == "lzma":
        return zipfile.ZIP_LZMA

    # Standard ZIP compatibility.
    if recipe.get("store_already_compressed_when_wise", True) and file_profile.is_already_compressed:
        # If original deflate was not helping much, store raw bytes to avoid wasting CPU/overhead.
        if file_profile.original_size == 0:
            return zipfile.ZIP_STORED
        original_ratio = file_profile.compressed_size / max(1, file_profile.original_size)
        if original_ratio >= 0.98:
            return zipfile.ZIP_STORED
    return zipfile.ZIP_DEFLATED


def _read_all_if_safe(zf: zipfile.ZipFile, info: zipfile.ZipInfo, max_mb: int) -> Optional[bytes]:
    max_bytes = max_mb * 1024 * 1024
    if info.file_size > max_bytes:
        return None
    with zf.open(info, "r") as src:
        return src.read()


def _normalize_text_bytes(data: bytes) -> Tuple[bytes, bool]:
    if not is_probably_text(data):
        return data, False
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return data, False
    original = text
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Remove trailing spaces while preserving line count.
    text = "\n".join(line.rstrip() for line in text.split("\n"))
    if text != original:
        return text.encode("utf-8"), True
    return data, False


def _stream_copy(src, dst):
    for chunk in iter(lambda: src.read(CHUNK_SIZE), b""):
        dst.write(chunk)


def resize_zip(input_zip: str | Path, output_zip: str | Path,
               recipe: Optional[str | Path | Dict[str, Any]] = None,
               report_dir: Optional[str | Path] = None,
               progress: Optional[Callable[[str], None]] = None) -> ResizeResult:
    input_path = Path(input_zip)
    output_path = Path(output_zip)
    recipe_data = load_recipe(recipe)
    report_path = Path(report_dir) if report_dir else output_path.parent
    report_path.mkdir(parents=True, exist_ok=True)

    if progress:
        progress("Analyzing archive")
    profile = analyze_zip(input_path, recipe_data, progress=progress)

    file_by_path = {f.path: f for f in profile.files}
    kept_files: List[Dict[str, Any]] = []
    removed_files: List[Dict[str, Any]] = []
    transformed_files: List[Dict[str, Any]] = []
    warnings = list(profile.warnings)
    duplicates_removed = 0
    junk_removed = 0
    transformed_count = 0

    if progress:
        progress("Repacking optimized ZIP")

    tmp_output = output_path.with_suffix(output_path.suffix + ".tmp")
    if tmp_output.exists():
        tmp_output.unlink()

    compression_level = int(recipe_data.get("compression_level", 9))

    # Track included paths to avoid collisions from path normalization.
    written_paths = set()

    with zipfile.ZipFile(input_path, "r") as zin, zipfile.ZipFile(tmp_output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=compression_level) as zout:
        for idx, info in enumerate(zin.infolist(), start=1):
            if info.is_dir():
                continue

            member_path = safe_zip_path(info.filename)
            profile_item = file_by_path[member_path]

            action = "kept"

            if recipe_data.get("remove_junk", True) and profile_item.is_junk:
                action = "removed_junk"
                junk_removed += 1
                profile_item.action_taken = action
                removed_files.append({
                    "path": member_path,
                    "reason": "junk_pattern",
                    "bytes": info.file_size,
                })
                continue

            if recipe_data.get("remove_duplicates", True) and profile_item.is_duplicate:
                action = "removed_duplicate"
                duplicates_removed += 1
                profile_item.action_taken = action
                removed_files.append({
                    "path": member_path,
                    "reason": "exact_duplicate",
                    "duplicate_of": profile_item.duplicate_of,
                    "bytes": info.file_size,
                    "sha256": profile_item.sha256,
                })
                continue

            # Ensure unique output path after normalization.
            out_name = member_path
            if out_name in written_paths:
                base, ext = posixpath.splitext(out_name)
                n = 2
                while f"{base}__{n}{ext}" in written_paths:
                    n += 1
                out_name = f"{base}__{n}{ext}"
                warnings.append(f"Renamed duplicate normalized path {member_path} -> {out_name}")
            written_paths.add(out_name)

            compress_type = _compression_type_for_member(profile_item, recipe_data)
            zinfo = _clone_zipinfo(info, out_name, recipe_data, compress_type)

            transformed = False
            new_hash = profile_item.sha256
            text_data: Optional[bytes] = None

            if recipe_data.get("normalize_text", False) and profile_item.file_type == "text_code_log":
                data = _read_all_if_safe(zin, info, int(recipe_data.get("maximum_single_file_mb_for_text_transform", 128)))
                if data is not None:
                    new_data, changed = _normalize_text_bytes(data)
                    if changed:
                        transformed = True
                        transformed_count += 1
                        new_hash = hashlib.sha256(new_data).hexdigest()
                        text_data = new_data
                        transformed_files.append({
                            "path": member_path,
                            "action": "normalized_text_line_endings_and_trailing_spaces",
                            "original_bytes": len(data),
                            "new_bytes": len(new_data),
                            "original_sha256": profile_item.sha256,
                            "new_sha256": new_hash,
                        })

            if text_data is not None:
                zout.writestr(zinfo, text_data)
            else:
                with zin.open(info, "r") as src, zout.open(zinfo, "w") as dst:
                    _stream_copy(src, dst)

            profile_item.action_taken = "kept_transformed" if transformed else "kept"
            kept_files.append({
                "path": out_name,
                "source_path": member_path,
                "action": profile_item.action_taken,
                "file_type": profile_item.file_type,
                "original_size": info.file_size,
                "original_compressed_size": info.compress_size,
                "sha256": new_hash,
                "compression_method": "stored" if compress_type == zipfile.ZIP_STORED else (
                    "deflated" if compress_type == zipfile.ZIP_DEFLATED else "advanced"
                ),
            })

            if progress and (idx % 50 == 0 or idx == len(zin.infolist())):
                progress(f"Repacked {idx}/{len(zin.infolist())} entries")

        # Add proof artifacts inside the ZIP, unless disabled.
        if recipe_data.get("add_manifest", True):
            manifest = {
                "generated_by": "Qyvaria Zip Resizer",
                "generated_at": now_iso(),
                "source_archive_sha256": profile.archive_sha256,
                "recipe": recipe_data,
                "kept_files": kept_files,
                "removed_files": removed_files,
                "note": "This manifest proves what was preserved, removed, deduplicated, or transformed.",
            }
            zout.writestr("QYVARIA_MANIFEST.json", json.dumps(manifest, indent=2, ensure_ascii=False))

    # Move only after write completed.
    if output_path.exists():
        output_path.unlink()
    tmp_output.replace(output_path)

    if progress:
        progress("Verifying output ZIP")
    verification_error = None
    verified = False
    try:
        with zipfile.ZipFile(output_path, "r") as zf:
            bad = zf.testzip()
            if bad:
                verification_error = f"Corrupt member: {bad}"
            else:
                verified = True
    except Exception as e:
        verification_error = str(e)

    output_sha = sha256_file(output_path)
    original_size = input_path.stat().st_size
    output_size = output_path.stat().st_size
    bytes_saved = original_size - output_size
    compression_ratio = output_size / original_size if original_size else 1.0

    proof_seal = verified and output_size <= original_size

    report = {
        "app": "Qyvaria Zip Resizer",
        "version": "0.2.0",
        "generated_at": now_iso(),
        "input_zip": str(input_path),
        "output_zip": str(output_path),
        "recipe": recipe_data,
        "source_archive_sha256": profile.archive_sha256,
        "output_archive_sha256": output_sha,
        "metrics": {
            "original_size": original_size,
            "output_size": output_size,
            "bytes_saved": bytes_saved,
            "compression_ratio": compression_ratio,
            "percent_saved": (bytes_saved / original_size * 100.0) if original_size else 0.0,
            "files_before": profile.file_count,
            "files_after": len(kept_files),
            "duplicates_removed": duplicates_removed,
            "junk_removed": junk_removed,
            "transformed_files": transformed_count,
        },
        "verification": {
            "verified": verified,
            "verification_error": verification_error,
            "qyvaria_proof_seal": proof_seal,
        },
        "archive_profile": {
            "type_counts": profile.type_counts,
            "largest_files": profile.largest_files,
            "duplicate_groups": profile.duplicate_groups,
            "warnings": profile.warnings,
        },
        "kept_files": kept_files,
        "removed_files": removed_files,
        "transformed_files": transformed_files,
        "warnings": warnings + ([] if proof_seal else ["Output was verified but did not become smaller, or verification failed."]),
    }

    report_json_path = report_path / f"{output_path.stem}_qyvaria_report.json"
    report_md_path = report_path / f"{output_path.stem}_qyvaria_report.md"
    report_json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    report_md_path.write_text(render_markdown_report(report), encoding="utf-8")

    if recipe_data.get("add_report_to_zip", True):
        # Append report after writing. This may slightly increase ZIP size but gives portable proof.
        with zipfile.ZipFile(output_path, "a", compression=zipfile.ZIP_DEFLATED, compresslevel=compression_level) as zout:
            zout.writestr("QYVARIA_REPORT.json", json.dumps(report, indent=2, ensure_ascii=False))
            zout.writestr("QYVARIA_REPORT.md", render_markdown_report(report))
        output_size = output_path.stat().st_size
        bytes_saved = original_size - output_size
        compression_ratio = output_size / original_size if original_size else 1.0
        proof_seal = verified and output_size <= original_size

    return ResizeResult(
        input_zip=str(input_path),
        output_zip=str(output_path),
        report_json=str(report_json_path),
        report_markdown=str(report_md_path),
        original_size=original_size,
        output_size=output_size,
        bytes_saved=bytes_saved,
        compression_ratio=compression_ratio,
        files_before=profile.file_count,
        files_after=len(kept_files),
        duplicates_removed=duplicates_removed,
        junk_removed=junk_removed,
        transformed_files=transformed_count,
        verified=verified,
        verification_error=verification_error,
        qyvaria_proof_seal=proof_seal,
        warnings=warnings,
    )


def render_markdown_report(report: Dict[str, Any]) -> str:
    metrics = report["metrics"]
    verification = report["verification"]
    lines = [
        "# Qyvaria Zip Resizer Report",
        "",
        f"Generated: `{report['generated_at']}`",
        "",
        "## Summary",
        "",
        f"- Input ZIP: `{report['input_zip']}`",
        f"- Output ZIP: `{report['output_zip']}`",
        f"- Original size: `{metrics['original_size']:,}` bytes",
        f"- Output size: `{metrics['output_size']:,}` bytes",
        f"- Bytes saved: `{metrics['bytes_saved']:,}` bytes",
        f"- Percent saved: `{metrics['percent_saved']:.2f}%`",
        f"- Compression ratio: `{metrics['compression_ratio']:.4f}`",
        f"- Files before: `{metrics['files_before']}`",
        f"- Files after: `{metrics['files_after']}`",
        f"- Duplicates removed: `{metrics['duplicates_removed']}`",
        f"- Junk files removed: `{metrics['junk_removed']}`",
        f"- Transformed files: `{metrics['transformed_files']}`",
        "",
        "## Verification",
        "",
        f"- Verified: `{verification['verified']}`",
        f"- Qyvaria Proof Seal: `{verification['qyvaria_proof_seal']}`",
        f"- Error: `{verification['verification_error']}`",
        "",
        "## Warnings",
        "",
    ]
    for warning in report.get("warnings", []):
        lines.append(f"- {warning}")
    lines += ["", "## Removed Files", ""]
    for item in report.get("removed_files", [])[:200]:
        reason = item.get("reason", "")
        dup = f" duplicate of `{item.get('duplicate_of')}`" if item.get("duplicate_of") else ""
        lines.append(f"- `{item.get('path')}` — {reason}{dup}")
    if len(report.get("removed_files", [])) > 200:
        lines.append("- More removed files exist in the JSON report.")
    lines += ["", "## Kept Files", ""]
    for item in report.get("kept_files", [])[:200]:
        lines.append(f"- `{item.get('path')}` — {item.get('action')} / {item.get('compression_method')}")
    if len(report.get("kept_files", [])) > 200:
        lines.append("- More kept files exist in the JSON report.")
    lines += [
        "",
        "## Proof Note",
        "",
        "Small ZIP output is a compressed delivery package. Keep the original archive when legal, scientific, or audit accuracy requires exact raw preservation.",
        "",
    ]
    return "\n".join(lines)


def human_size(num: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(num)
    for unit in units:
        if abs(value) < 1024.0 or unit == units[-1]:
            return f"{value:.2f} {unit}"
        value /= 1024.0
    return f"{num} B"
