$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Apps = @("ai_inspector_editor", "qtask_optimizer", "qyvaria_zip_resizer", "safespeed_optimizer")
foreach ($App in $Apps) {
    Write-Host ""
    Write-Host "=============================="
    Write-Host "Installing $App"
    Write-Host "=============================="
    $Script = Join-Path $Root "$App\scripts\install_windows.ps1"
    powershell -ExecutionPolicy Bypass -NoProfile -File $Script
}
Write-Host ""
Write-Host "All Qyvaria apps installed. Check Desktop and Start Menu > Qyvaria."
