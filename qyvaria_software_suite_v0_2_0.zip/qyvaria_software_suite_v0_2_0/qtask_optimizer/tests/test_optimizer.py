from pathlib import Path

from qtask_optimizer.optimizer import analyze_directory, delete_files


def test_analyze_directory(tmp_path: Path) -> None:
    a = tmp_path / "a.bin"
    b = tmp_path / "b.txt"
    a.write_bytes(b"x" * 1024)
    b.write_text("hello", encoding="utf-8")

    files, stats = analyze_directory(tmp_path, limit=10)

    assert files
    assert stats
    assert files[0].path.endswith("a.bin")


def test_delete_files_outside_temp_is_skipped(monkeypatch, tmp_path: Path) -> None:
    fake_temp = tmp_path / "fake_temp"
    fake_temp.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    p = outside / "keep.txt"
    p.write_text("keep", encoding="utf-8")
    monkeypatch.setattr("tempfile.gettempdir", lambda: str(fake_temp))

    deleted, freed, failures = delete_files([str(p)])

    assert deleted == 0
    assert freed == 0
    assert failures
    assert p.exists()
