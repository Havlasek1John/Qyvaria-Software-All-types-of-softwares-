from __future__ import annotations

import os
import platform
import queue
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import psutil

from .optimizer import (
    analyze_directory,
    delete_files,
    export_extension_stats,
    export_file_items,
    folder_breakdown,
    temp_candidates,
)
from .services import (
    NetworkConnection,
    ProcessInfo,
    ProcessService,
    StartupItem,
    list_startup_items,
    network_connections,
    system_snapshot,
)


COLORS = {
    "bg": "#090d14",
    "panel": "#111827",
    "panel_2": "#0f172a",
    "card": "#151f30",
    "card_2": "#1b2940",
    "text": "#e6edf7",
    "muted": "#9fb0c6",
    "accent": "#7c5cff",
    "accent_2": "#24d9c3",
    "danger": "#ff5570",
    "warning": "#ffc857",
    "line": "#263248",
    "table": "#0d1420",
    "select": "#283b61",
}


def open_path(path: str | os.PathLike[str]) -> None:
    target = str(path)
    system = platform.system()
    if system == "Windows":
        os.startfile(target)  # type: ignore[attr-defined]
    elif system == "Darwin":
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target])


class StatusBar(tk.Frame):
    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master, bg=COLORS["panel"])
        self.label = tk.Label(self, text="Ready", anchor="w", bg=COLORS["panel"], fg=COLORS["muted"])
        self.label.pack(fill="x", padx=14, pady=7)

    def set(self, text: str) -> None:
        self.label.config(text=text)


class MetricCard(tk.Frame):
    def __init__(self, master: tk.Misc, title: str, value: str = "--", subtitle: str = "", percent: float = 0) -> None:
        super().__init__(master, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        self.columnconfigure(0, weight=1)
        self.title_label = tk.Label(self, text=title, bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 10, "bold"))
        self.value_label = tk.Label(self, text=value, bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI", 20, "bold"))
        self.subtitle_label = tk.Label(self, text=subtitle, bg=COLORS["card"], fg=COLORS["muted"], font=("Segoe UI", 9))
        self.bar = tk.Canvas(self, height=7, bg=COLORS["card"], highlightthickness=0)
        self.title_label.grid(row=0, column=0, sticky="w", padx=16, pady=(14, 2))
        self.value_label.grid(row=1, column=0, sticky="w", padx=16)
        self.subtitle_label.grid(row=2, column=0, sticky="w", padx=16, pady=(0, 10))
        self.bar.grid(row=3, column=0, sticky="ew", padx=16, pady=(0, 14))
        self._percent = percent
        self.bind("<Configure>", lambda _event: self._draw_bar())

    def set(self, value: str, subtitle: str = "", percent: float | None = None) -> None:
        self.value_label.config(text=value)
        self.subtitle_label.config(text=subtitle)
        if percent is not None:
            self._percent = max(0, min(100, float(percent)))
        self._draw_bar()

    def _draw_bar(self) -> None:
        self.bar.delete("all")
        width = max(1, self.bar.winfo_width())
        height = 7
        self.bar.create_rectangle(0, 0, width, height, fill=COLORS["panel_2"], outline="")
        fill_width = int(width * (self._percent / 100))
        fill = COLORS["accent_2"] if self._percent < 75 else COLORS["warning"]
        if self._percent >= 90:
            fill = COLORS["danger"]
        self.bar.create_rectangle(0, 0, fill_width, height, fill=fill, outline="")


class QTaskOptimizerApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("QTask Optimizer — Qyvarian Edition")
        self.geometry("1360x820")
        self.minsize(1120, 700)
        self.configure(bg=COLORS["bg"])

        self.process_service = ProcessService()
        self.process_rows: list[ProcessInfo] = []
        self.file_rows = []
        self.ext_rows = []
        self.folder_rows = []
        self.temp_rows = []
        self.network_rows: list[NetworkConnection] = []
        self.startup_rows: list[StartupItem] = []

        self._queue: queue.Queue[tuple[str, object]] = queue.Queue()
        self._sort_column = "cpu_percent"
        self._sort_reverse = True
        self._refresh_job: str | None = None
        self.current_page = "Dashboard"

        self.auto_refresh = tk.BooleanVar(value=True)
        self.confirm_actions = tk.BooleanVar(value=True)
        self.heavy_only = tk.BooleanVar(value=False)
        self.hide_system = tk.BooleanVar(value=False)
        self.refresh_interval = tk.IntVar(value=2500)

        self._build_ui()
        self.refresh_processes()
        self.refresh_system()
        self.refresh_network()
        self.refresh_startup()
        self.after(200, self._poll_queue)

    def _build_ui(self) -> None:
        self._configure_styles()
        self._build_menu()
        self.bind("<F5>", lambda _e: self.refresh_all())
        self.bind("<Control-q>", lambda _e: self.destroy())
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        self.sidebar = tk.Frame(self, bg=COLORS["panel_2"], width=220)
        self.sidebar.grid(row=0, column=0, sticky="ns")
        self.sidebar.grid_propagate(False)

        logo = tk.Label(self.sidebar, text="Q", bg=COLORS["accent"], fg="white", font=("Segoe UI", 25, "bold"), width=2)
        logo.grid(row=0, column=0, padx=20, pady=(24, 6), sticky="w")
        tk.Label(self.sidebar, text="QTask Optimizer", bg=COLORS["panel_2"], fg=COLORS["text"], font=("Segoe UI", 14, "bold")).grid(row=1, column=0, sticky="w", padx=20)
        tk.Label(self.sidebar, text="Qyvarian Edition", bg=COLORS["panel_2"], fg=COLORS["accent_2"], font=("Segoe UI", 9, "bold")).grid(row=2, column=0, sticky="w", padx=20, pady=(0, 24))

        self.nav_buttons: dict[str, tk.Button] = {}
        pages = ["Dashboard", "Processes", "Optimizer", "Data Analyzer", "Network", "Startup", "Settings"]
        for row, name in enumerate(pages, start=3):
            btn = tk.Button(
                self.sidebar,
                text=name,
                anchor="w",
                relief="flat",
                bd=0,
                bg=COLORS["panel_2"],
                fg=COLORS["muted"],
                activebackground=COLORS["card_2"],
                activeforeground=COLORS["text"],
                font=("Segoe UI", 10, "bold"),
                command=lambda n=name: self.show_page(n),
            )
            btn.grid(row=row, column=0, sticky="ew", padx=12, pady=2, ipady=9)
            self.nav_buttons[name] = btn

        self.sidebar.rowconfigure(99, weight=1)
        tk.Label(
            self.sidebar,
            text="Safe optimizer\nNo registry hacks\nNo silent deletes",
            bg=COLORS["panel_2"],
            fg=COLORS["muted"],
            justify="left",
            font=("Segoe UI", 9),
        ).grid(row=99, column=0, sticky="sw", padx=20, pady=18)

        self.main = tk.Frame(self, bg=COLORS["bg"])
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.columnconfigure(0, weight=1)
        self.main.rowconfigure(1, weight=1)

        self.header = tk.Frame(self.main, bg=COLORS["bg"])
        self.header.grid(row=0, column=0, sticky="ew", padx=22, pady=(18, 8))
        self.header.columnconfigure(0, weight=1)
        self.page_title = tk.Label(self.header, text="Dashboard", bg=COLORS["bg"], fg=COLORS["text"], font=("Segoe UI", 22, "bold"))
        self.page_title.grid(row=0, column=0, sticky="w")
        self.page_subtitle = tk.Label(self.header, text="A modern cross-platform task manager and performance control center.", bg=COLORS["bg"], fg=COLORS["muted"], font=("Segoe UI", 10))
        self.page_subtitle.grid(row=1, column=0, sticky="w")
        ttk.Button(self.header, text="Refresh all", command=self.refresh_all, style="Accent.TButton").grid(row=0, column=1, rowspan=2, sticky="e", padx=(12, 0))

        self.content = tk.Frame(self.main, bg=COLORS["bg"])
        self.content.grid(row=1, column=0, sticky="nsew", padx=22, pady=(0, 10))
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=1)

        self.pages: dict[str, tk.Frame] = {}
        for page in pages:
            frame = tk.Frame(self.content, bg=COLORS["bg"])
            frame.grid(row=0, column=0, sticky="nsew")
            self.pages[page] = frame

        self.status = StatusBar(self.main)
        self.status.grid(row=2, column=0, sticky="ew")

        self._build_dashboard()
        self._build_process_page()
        self._build_optimizer_page()
        self._build_data_page()
        self._build_network_page()
        self._build_startup_page()
        self._build_settings_page()
        self.show_page("Dashboard")

    def _build_menu(self) -> None:
        """Clean Qyvarian menu layer for power users and desktop installs."""
        menubar = tk.Menu(self)
        file_menu = tk.Menu(menubar, tearoff=False)
        file_menu.add_command(label="Refresh All   F5", command=self.refresh_all)
        file_menu.add_separator()
        file_menu.add_command(label="Exit   Ctrl+Q", command=self.destroy)
        menubar.add_cascade(label="File", menu=file_menu)

        view_menu = tk.Menu(menubar, tearoff=False)
        for page in ["Dashboard", "Processes", "Optimizer", "Data Analyzer", "Network", "Startup", "Settings"]:
            view_menu.add_command(label=page, command=lambda p=page: self.show_page(p))
        menubar.add_cascade(label="View", menu=view_menu)

        tools_menu = tk.Menu(menubar, tearoff=False)
        tools_menu.add_command(label="Preview Cleanup", command=self.preview_temp_cleanup)
        tools_menu.add_command(label="Refresh Processes", command=self.refresh_processes)
        tools_menu.add_command(label="Refresh Network", command=self.refresh_network)
        tools_menu.add_command(label="Refresh Startup", command=self.refresh_startup)
        menubar.add_cascade(label="Tools", menu=tools_menu)

        help_menu = tk.Menu(menubar, tearoff=False)
        help_menu.add_command(
            label="About QTask Optimizer",
            command=lambda: messagebox.showinfo(
                "QTask Optimizer",
                "QTask Optimizer — Qyvarian Edition\n\n"
                "Cleaner v0.3 UI layer with safer menus, keyboard shortcuts, desktop install support, "
                "and diagnostics scripts."
            ),
        )
        menubar.add_cascade(label="Help", menu=help_menu)
        self.config(menu=menubar)

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("TFrame", background=COLORS["bg"])
        style.configure("Card.TFrame", background=COLORS["card"])
        style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"])
        style.configure("Muted.TLabel", background=COLORS["bg"], foreground=COLORS["muted"])
        style.configure("TButton", padding=(10, 7), background=COLORS["card_2"], foreground=COLORS["text"], borderwidth=0)
        style.map("TButton", background=[("active", COLORS["select"])])
        style.configure("Accent.TButton", background=COLORS["accent"], foreground="white")
        style.map("Accent.TButton", background=[("active", "#927bff")])
        style.configure("Danger.TButton", background=COLORS["danger"], foreground="white")
        style.configure("TCheckbutton", background=COLORS["bg"], foreground=COLORS["text"])
        style.configure("TEntry", fieldbackground=COLORS["panel"], foreground=COLORS["text"], insertcolor=COLORS["text"], bordercolor=COLORS["line"])
        style.configure("TCombobox", fieldbackground=COLORS["panel"], foreground=COLORS["text"], arrowcolor=COLORS["text"])
        style.configure("Treeview", background=COLORS["table"], fieldbackground=COLORS["table"], foreground=COLORS["text"], rowheight=28, borderwidth=0)
        style.configure("Treeview.Heading", background=COLORS["card_2"], foreground=COLORS["text"], padding=(6, 8), relief="flat")
        style.map("Treeview", background=[("selected", COLORS["select"])], foreground=[("selected", COLORS["text"])])
        style.map("Treeview.Heading", background=[("active", COLORS["select"])])

    def show_page(self, name: str) -> None:
        self.current_page = name
        self.page_title.config(text=name)
        subtitles = {
            "Dashboard": "Qyvarian overview: machine health, live resources, and quick actions.",
            "Processes": "Live tasks with priority, suspend/resume, details, path tools, and CSV export.",
            "Optimizer": "Safe cleanup controls with preview-first deletion and tunable scan options.",
            "Data Analyzer": "Find heavy files, bloated extensions, and large folders for faster workflows.",
            "Network": "Inspect active TCP/UDP endpoints and process ownership.",
            "Startup": "Review autostart items from Windows/Linux startup locations.",
            "Settings": "Tweak refresh behavior and safety confirmations.",
        }
        self.page_subtitle.config(text=subtitles.get(name, ""))
        self.pages[name].tkraise()
        for page, btn in self.nav_buttons.items():
            if page == name:
                btn.config(bg=COLORS["card_2"], fg=COLORS["text"])
            else:
                btn.config(bg=COLORS["panel_2"], fg=COLORS["muted"])

    def _card_grid(self, parent: tk.Frame, cards: list[MetricCard]) -> None:
        for idx, card in enumerate(cards):
            parent.columnconfigure(idx, weight=1)
            card.grid(row=0, column=idx, sticky="nsew", padx=(0 if idx == 0 else 10, 0), pady=0)

    def _build_dashboard(self) -> None:
        page = self.pages["Dashboard"]
        page.columnconfigure(0, weight=1)
        page.rowconfigure(2, weight=1)

        cards_frame = tk.Frame(page, bg=COLORS["bg"])
        cards_frame.grid(row=0, column=0, sticky="ew")
        self.dashboard_cpu = MetricCard(cards_frame, "CPU", "--")
        self.dashboard_mem = MetricCard(cards_frame, "Memory", "--")
        self.dashboard_disk = MetricCard(cards_frame, "Disk", "--")
        self.dashboard_net = MetricCard(cards_frame, "Network", "--")
        self._card_grid(cards_frame, [self.dashboard_cpu, self.dashboard_mem, self.dashboard_disk, self.dashboard_net])

        quick = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        quick.grid(row=1, column=0, sticky="ew", pady=14)
        for i in range(5):
            quick.columnconfigure(i, weight=1)
        tk.Label(quick, text="Quick controls", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI", 13, "bold")).grid(row=0, column=0, sticky="w", padx=16, pady=(14, 4), columnspan=5)
        ttk.Button(quick, text="Processes", command=lambda: self.show_page("Processes")).grid(row=1, column=0, sticky="ew", padx=16, pady=(4, 16))
        ttk.Button(quick, text="Preview temp cleanup", command=lambda: [self.show_page("Optimizer"), self.preview_temp_cleanup()]).grid(row=1, column=1, sticky="ew", padx=8, pady=(4, 16))
        ttk.Button(quick, text="Analyze home folder", command=self.analyze_home_folder).grid(row=1, column=2, sticky="ew", padx=8, pady=(4, 16))
        ttk.Button(quick, text="Network", command=lambda: [self.show_page("Network"), self.refresh_network()]).grid(row=1, column=3, sticky="ew", padx=8, pady=(4, 16))
        ttk.Button(quick, text="Startup", command=lambda: [self.show_page("Startup"), self.refresh_startup()]).grid(row=1, column=4, sticky="ew", padx=(8, 16), pady=(4, 16))

        lower = tk.Frame(page, bg=COLORS["bg"])
        lower.grid(row=2, column=0, sticky="nsew")
        lower.columnconfigure(0, weight=2)
        lower.columnconfigure(1, weight=1)
        lower.rowconfigure(0, weight=1)

        self.dashboard_heavy_tree = self._make_tree(lower, ("pid", "name", "cpu", "memory", "priority"), {"pid": "PID", "name": "Process", "cpu": "CPU %", "memory": "RAM MB", "priority": "Priority"})
        self._tree_container(self.dashboard_heavy_tree).grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        notes = tk.Text(lower, bg=COLORS["card"], fg=COLORS["text"], insertbackground=COLORS["text"], relief="flat", wrap="word", height=12)
        notes.grid(row=0, column=1, sticky="nsew")
        notes.insert(
            "1.0",
            "Qyvarian Mode\n\n"
            "• Monitor high CPU/RAM processes.\n"
            "• Use priority tools instead of unsafe system tweaks.\n"
            "• Clean only previewed temp files.\n"
            "• Analyze data folders before deleting anything.\n\n"
            "This app is designed for speed control without hidden destructive automation.",
        )
        notes.config(state="disabled")

    def _build_process_page(self) -> None:
        page = self.pages["Processes"]
        page.columnconfigure(0, weight=1)
        page.rowconfigure(1, weight=1)

        toolbar = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        toolbar.columnconfigure(1, weight=1)

        tk.Label(toolbar, text="Filter", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=0, column=0, padx=(14, 6), pady=12)
        self.filter_var = tk.StringVar()
        filter_entry = ttk.Entry(toolbar, textvariable=self.filter_var)
        filter_entry.grid(row=0, column=1, sticky="ew", padx=(0, 10), pady=12)
        filter_entry.bind("<KeyRelease>", lambda _event: self._render_processes())

        ttk.Checkbutton(toolbar, text="Heavy only", variable=self.heavy_only, command=self._render_processes).grid(row=0, column=2, padx=5)
        ttk.Checkbutton(toolbar, text="Auto", variable=self.auto_refresh, command=self._schedule_refresh).grid(row=0, column=3, padx=5)
        tk.Label(toolbar, text="Interval ms", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=0, column=4, padx=(8, 2))
        tk.Spinbox(toolbar, from_=1000, to=10000, increment=500, width=7, textvariable=self.refresh_interval, bg=COLORS["panel"], fg=COLORS["text"], insertbackground=COLORS["text"], relief="flat").grid(row=0, column=5, padx=5)
        ttk.Button(toolbar, text="Refresh", command=self.refresh_processes).grid(row=0, column=6, padx=5)
        ttk.Button(toolbar, text="Export CSV", command=self.export_process_csv).grid(row=0, column=7, padx=(5, 14))

        body = tk.Frame(page, bg=COLORS["bg"])
        body.grid(row=1, column=0, sticky="nsew")
        body.columnconfigure(0, weight=1)
        body.rowconfigure(0, weight=1)

        columns = ("pid", "name", "username", "status", "cpu_percent", "memory_mb", "read_mb", "write_mb", "threads", "priority", "exe")
        headings = {
            "pid": "PID",
            "name": "Name",
            "username": "User",
            "status": "Status",
            "cpu_percent": "CPU %",
            "memory_mb": "RAM MB",
            "read_mb": "Read MB",
            "write_mb": "Write MB",
            "threads": "Threads",
            "priority": "Priority",
            "exe": "Executable",
        }
        self.process_tree = self._make_tree(body, columns, headings)
        self._tree_container(self.process_tree).grid(row=0, column=0, sticky="nsew")
        for col in columns:
            self.process_tree.heading(col, text=headings[col], command=lambda c=col: self._sort_processes(c))
            if col == "exe":
                self.process_tree.column(col, width=330)
            elif col in {"name", "username"}:
                self.process_tree.column(col, width=150)
            else:
                self.process_tree.column(col, width=80)

        actions = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        actions.grid(row=2, column=0, sticky="ew", pady=(12, 0))
        for i in range(10):
            actions.columnconfigure(i, weight=1)

        buttons = [
            ("Details", self.show_process_details, "TButton"),
            ("Open location", self.open_selected_location, "TButton"),
            ("Copy PID", self.copy_selected_pid, "TButton"),
            ("Suspend", self.suspend_selected, "TButton"),
            ("Resume", self.resume_selected, "TButton"),
            ("Priority Low", lambda: self.set_selected_priority("low"), "TButton"),
            ("Priority Normal", lambda: self.set_selected_priority("normal"), "TButton"),
            ("Priority High", lambda: self.set_selected_priority("high"), "Accent.TButton"),
            ("Terminate", self.terminate_selected, "TButton"),
            ("Kill", self.kill_selected, "Danger.TButton"),
        ]
        for i, (text, command, style) in enumerate(buttons):
            ttk.Button(actions, text=text, command=command, style=style).grid(row=0, column=i, sticky="ew", padx=5 if i else 14, pady=12)

    def _build_optimizer_page(self) -> None:
        page = self.pages["Optimizer"]
        page.columnconfigure(0, weight=1)
        page.rowconfigure(2, weight=1)

        cards = tk.Frame(page, bg=COLORS["bg"])
        cards.grid(row=0, column=0, sticky="ew")
        self.opt_cpu = MetricCard(cards, "CPU", "--")
        self.opt_mem = MetricCard(cards, "RAM", "--")
        self.opt_swap = MetricCard(cards, "Swap", "--")
        self.opt_proc = MetricCard(cards, "Processes", "--")
        self._card_grid(cards, [self.opt_cpu, self.opt_mem, self.opt_swap, self.opt_proc])

        controls = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        controls.grid(row=1, column=0, sticky="ew", pady=14)
        for i in range(8):
            controls.columnconfigure(i, weight=1)

        tk.Label(controls, text="Temp cleanup options", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w", padx=16, pady=(14, 4), columnspan=8)
        tk.Label(controls, text="Min age days", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=1, column=0, padx=(16, 4), pady=(4, 14), sticky="e")
        self.temp_age = tk.IntVar(value=3)
        tk.Spinbox(controls, from_=0, to=365, width=6, textvariable=self.temp_age, bg=COLORS["panel"], fg=COLORS["text"], relief="flat").grid(row=1, column=1, sticky="w", padx=4, pady=(4, 14))
        tk.Label(controls, text="Min size MB", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=1, column=2, padx=4, pady=(4, 14), sticky="e")
        self.temp_min_size = tk.DoubleVar(value=0.0)
        tk.Spinbox(controls, from_=0, to=4096, increment=1, width=8, textvariable=self.temp_min_size, bg=COLORS["panel"], fg=COLORS["text"], relief="flat").grid(row=1, column=3, sticky="w", padx=4, pady=(4, 14))
        tk.Label(controls, text="Max files", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=1, column=4, padx=4, pady=(4, 14), sticky="e")
        self.temp_limit = tk.IntVar(value=500)
        tk.Spinbox(controls, from_=50, to=5000, increment=50, width=8, textvariable=self.temp_limit, bg=COLORS["panel"], fg=COLORS["text"], relief="flat").grid(row=1, column=5, sticky="w", padx=4, pady=(4, 14))
        ttk.Button(controls, text="Preview", command=self.preview_temp_cleanup, style="Accent.TButton").grid(row=1, column=6, sticky="ew", padx=5, pady=(4, 14))
        ttk.Button(controls, text="Delete previewed", command=self.delete_previewed_temp, style="Danger.TButton").grid(row=1, column=7, sticky="ew", padx=(5, 16), pady=(4, 14))

        lower = tk.Frame(page, bg=COLORS["bg"])
        lower.grid(row=2, column=0, sticky="nsew")
        lower.columnconfigure(0, weight=3)
        lower.columnconfigure(1, weight=2)
        lower.rowconfigure(0, weight=1)

        temp_cols = ("size_mb", "modified", "path")
        self.temp_tree = self._make_tree(lower, temp_cols, {"size_mb": "Size MB", "modified": "Modified", "path": "Temp file"})
        self.temp_tree.column("path", width=620)
        self._tree_container(self.temp_tree).grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        right = tk.Frame(lower, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)
        tk.Label(right, text="Optimization log", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI", 13, "bold")).grid(row=0, column=0, sticky="w", padx=14, pady=(14, 6))
        self.optimize_text = tk.Text(right, bg=COLORS["table"], fg=COLORS["text"], insertbackground=COLORS["text"], relief="flat", wrap="word")
        self.optimize_text.grid(row=1, column=0, sticky="nsew", padx=14, pady=(0, 14))
        self.optimize_text.insert(
            "1.0",
            "Optimizer notes:\n"
            "• Preview first, delete second.\n"
            "• Tune age, size, and file limit before scanning.\n"
            "• Boost priority only for trusted foreground work.\n"
            "• Lower priority for noisy background jobs.\n",
        )
        self.optimize_text.config(state="disabled")

    def _build_data_page(self) -> None:
        page = self.pages["Data Analyzer"]
        page.columnconfigure(0, weight=1)
        page.rowconfigure(2, weight=1)

        toolbar = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        toolbar.columnconfigure(1, weight=1)

        tk.Label(toolbar, text="Folder", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=0, column=0, padx=(14, 6), pady=12)
        self.folder_var = tk.StringVar(value=str(Path.home()))
        ttk.Entry(toolbar, textvariable=self.folder_var).grid(row=0, column=1, sticky="ew", padx=(0, 6), pady=12)
        ttk.Button(toolbar, text="Browse", command=self.choose_folder).grid(row=0, column=2, padx=4)
        tk.Label(toolbar, text="Min MB", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=0, column=3, padx=(8, 4))
        self.file_min_size = tk.DoubleVar(value=0.0)
        tk.Spinbox(toolbar, from_=0, to=50000, increment=10, width=8, textvariable=self.file_min_size, bg=COLORS["panel"], fg=COLORS["text"], relief="flat").grid(row=0, column=4, padx=4)
        tk.Label(toolbar, text="Limit", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=0, column=5, padx=(8, 4))
        self.file_limit = tk.IntVar(value=200)
        tk.Spinbox(toolbar, from_=25, to=5000, increment=25, width=8, textvariable=self.file_limit, bg=COLORS["panel"], fg=COLORS["text"], relief="flat").grid(row=0, column=6, padx=4)
        ttk.Button(toolbar, text="Analyze", command=self.analyze_folder, style="Accent.TButton").grid(row=0, column=7, padx=4)
        ttk.Button(toolbar, text="Export files", command=self.export_file_csv).grid(row=0, column=8, padx=4)
        ttk.Button(toolbar, text="Export types", command=self.export_ext_csv).grid(row=0, column=9, padx=(4, 14))

        self.data_summary = tk.StringVar(value="Choose a folder and click Analyze.")
        tk.Label(page, textvariable=self.data_summary, bg=COLORS["bg"], fg=COLORS["muted"], anchor="w").grid(row=1, column=0, sticky="ew", pady=(0, 8))

        panes = tk.PanedWindow(page, orient="horizontal", bg=COLORS["bg"], sashwidth=8, bd=0)
        panes.grid(row=2, column=0, sticky="nsew")

        left = tk.Frame(panes, bg=COLORS["bg"])
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        file_cols = ("size_mb", "modified", "path")
        self.file_tree = self._make_tree(left, file_cols, {"size_mb": "Size MB", "modified": "Modified", "path": "Path"})
        self.file_tree.column("path", width=680)
        self._tree_container(self.file_tree).grid(row=0, column=0, sticky="nsew")
        file_actions = tk.Frame(left, bg=COLORS["bg"])
        file_actions.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        ttk.Button(file_actions, text="Open selected location", command=self.open_selected_file_location).pack(side="left")
        ttk.Button(file_actions, text="Copy selected path", command=self.copy_selected_file_path).pack(side="left", padx=8)

        right = tk.Frame(panes, bg=COLORS["bg"])
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)
        self.ext_tree = self._make_tree(right, ("extension", "count", "size_mb"), {"extension": "Type", "count": "Count", "size_mb": "MB"})
        self._tree_container(self.ext_tree).grid(row=0, column=0, sticky="nsew", pady=(0, 8))
        self.folder_tree = self._make_tree(right, ("size_mb", "files", "path"), {"size_mb": "MB", "files": "Files", "path": "Folder"})
        self.folder_tree.column("path", width=360)
        self._tree_container(self.folder_tree).grid(row=1, column=0, sticky="nsew")

        panes.add(left, minsize=620)
        panes.add(right, minsize=360)

    def _build_network_page(self) -> None:
        page = self.pages["Network"]
        page.columnconfigure(0, weight=1)
        page.rowconfigure(1, weight=1)

        toolbar = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        toolbar.columnconfigure(1, weight=1)
        tk.Label(toolbar, text="Active endpoints", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w", padx=14, pady=12)
        self.net_summary = tk.StringVar(value="Network data not loaded yet.")
        tk.Label(toolbar, textvariable=self.net_summary, bg=COLORS["card"], fg=COLORS["muted"]).grid(row=0, column=1, sticky="w", padx=14, pady=12)
        ttk.Button(toolbar, text="Refresh network", command=self.refresh_network, style="Accent.TButton").grid(row=0, column=2, sticky="e", padx=14, pady=12)

        cols = ("pid", "process", "local", "remote", "status")
        self.network_tree = self._make_tree(page, cols, {"pid": "PID", "process": "Process", "local": "Local", "remote": "Remote", "status": "Status"})
        self._tree_container(self.network_tree).grid(row=1, column=0, sticky="nsew")
        self.network_tree.column("local", width=260)
        self.network_tree.column("remote", width=260)

    def _build_startup_page(self) -> None:
        page = self.pages["Startup"]
        page.columnconfigure(0, weight=1)
        page.rowconfigure(1, weight=1)

        toolbar = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        toolbar.columnconfigure(1, weight=1)
        tk.Label(toolbar, text="Startup review", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w", padx=14, pady=12)
        tk.Label(toolbar, text="View autostart entries. Editing is intentionally manual for safety.", bg=COLORS["card"], fg=COLORS["muted"]).grid(row=0, column=1, sticky="w", padx=14, pady=12)
        ttk.Button(toolbar, text="Refresh", command=self.refresh_startup, style="Accent.TButton").grid(row=0, column=2, padx=6, pady=12)
        ttk.Button(toolbar, text="Open startup folder", command=self.open_startup_folder).grid(row=0, column=3, padx=(6, 14), pady=12)

        cols = ("name", "source", "enabled", "command")
        self.startup_tree = self._make_tree(page, cols, {"name": "Name", "source": "Source", "enabled": "Enabled", "command": "Command"})
        self._tree_container(self.startup_tree).grid(row=1, column=0, sticky="nsew")
        self.startup_tree.column("command", width=620)

    def _build_settings_page(self) -> None:
        page = self.pages["Settings"]
        page.columnconfigure(0, weight=1)
        page.rowconfigure(1, weight=1)

        panel = tk.Frame(page, bg=COLORS["card"], highlightbackground=COLORS["line"], highlightthickness=1)
        panel.grid(row=0, column=0, sticky="ew")
        for i in range(4):
            panel.columnconfigure(i, weight=1)
        tk.Label(panel, text="Qyvarian options", bg=COLORS["card"], fg=COLORS["text"], font=("Segoe UI", 14, "bold")).grid(row=0, column=0, sticky="w", padx=16, pady=(16, 4), columnspan=4)
        ttk.Checkbutton(panel, text="Auto-refresh processes", variable=self.auto_refresh, command=self._schedule_refresh).grid(row=1, column=0, sticky="w", padx=16, pady=12)
        ttk.Checkbutton(panel, text="Confirm risky actions", variable=self.confirm_actions).grid(row=1, column=1, sticky="w", padx=16, pady=12)
        ttk.Checkbutton(panel, text="Show heavy processes only", variable=self.heavy_only, command=self._render_processes).grid(row=1, column=2, sticky="w", padx=16, pady=12)
        ttk.Button(panel, text="Open temp folder", command=lambda: open_path(Path(os.getenv("TMPDIR") or os.getenv("TEMP") or os.getenv("TMP") or Path.home()))).grid(row=1, column=3, sticky="ew", padx=16, pady=12)

        about = tk.Text(page, bg=COLORS["card"], fg=COLORS["text"], insertbackground=COLORS["text"], relief="flat", wrap="word")
        about.grid(row=1, column=0, sticky="nsew", pady=(14, 0))
        about.insert(
            "1.0",
            "QTask Optimizer — Qyvarian Edition\n\n"
            "New UI:\n"
            "• Dark Qyvarian sidebar layout\n"
            "• Resource cards with live meters\n"
            "• Cleaner tables and action bars\n\n"
            "Added options:\n"
            "• Process details, open executable location, copy PID/path\n"
            "• Suspend/resume process controls\n"
            "• Tunable refresh interval and heavy-only filter\n"
            "• Temp cleanup age/size/limit controls with preview table\n"
            "• Data analyzer extension and folder breakdowns\n"
            "• Network endpoint viewer\n"
            "• Startup item review\n\n"
            "Safety model:\n"
            "No hidden registry edits, no silent service disabling, and no automatic deletion outside the OS temp directory.",
        )
        about.config(state="disabled")

    def _make_tree(self, parent: tk.Misc, columns: tuple[str, ...], headings: dict[str, str]) -> ttk.Treeview:
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        for col in columns:
            tree.heading(col, text=headings.get(col, col))
            tree.column(col, width=120, minwidth=60, anchor="w")
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        xscroll = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        tree._container = frame  # type: ignore[attr-defined]
        frame.grid_propagate(True)
        return tree

    def _tree_container(self, tree: ttk.Treeview) -> tk.Frame:
        return tree._container  # type: ignore[attr-defined,no-any-return]

    def _poll_queue(self) -> None:
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "processes":
                    self.process_rows = payload  # type: ignore[assignment]
                    self._render_processes()
                    self._render_dashboard_heavy()
                    self._schedule_refresh()
                elif kind == "system":
                    self._render_system(payload)
                elif kind == "temp":
                    self.temp_rows = payload  # type: ignore[assignment]
                    self._render_temp_rows()
                    total = sum(item.size_mb for item in self.temp_rows)
                    self._write_optimizer_log(f"Temp cleanup preview: {len(self.temp_rows)} files, about {total:.2f} MB.")
                elif kind == "analysis":
                    largest, stats, folders = payload  # type: ignore[misc]
                    self.file_rows = largest
                    self.ext_rows = stats
                    self.folder_rows = folders
                    self._render_files()
                    self._render_extension_stats()
                    self._render_folder_stats()
                    total = sum(item.size_mb for item in largest)
                    top_ext = ", ".join(f"{row.extension}: {row.size_mb:.1f} MB" for row in stats[:5])
                    self.data_summary.set(f"Previewed {len(largest)} large files; preview total {total:.2f} MB. Top types: {top_ext or 'none'}.")
                elif kind == "network":
                    self.network_rows = payload  # type: ignore[assignment]
                    self._render_network_rows()
                elif kind == "startup":
                    self.startup_rows = payload  # type: ignore[assignment]
                    self._render_startup_rows()
                elif kind == "error":
                    messagebox.showerror("QTask Optimizer", str(payload))
                    self.status.set("Error")
        except queue.Empty:
            pass
        self.after(200, self._poll_queue)

    def _run_worker(self, func, done_kind: str) -> None:
        def runner() -> None:
            try:
                result = func()
                self._queue.put((done_kind, result))
            except Exception as exc:  # noqa: BLE001 - route errors to UI.
                self._queue.put(("error", exc))

        threading.Thread(target=runner, daemon=True).start()

    def refresh_all(self) -> None:
        self.refresh_processes()
        self.refresh_system()
        self.refresh_network()
        self.refresh_startup()

    def refresh_processes(self) -> None:
        self.status.set("Refreshing processes...")
        self._run_worker(self.process_service.list_processes, "processes")

    def _schedule_refresh(self) -> None:
        if self._refresh_job:
            self.after_cancel(self._refresh_job)
            self._refresh_job = None
        if self.auto_refresh.get():
            interval = max(1000, int(self.refresh_interval.get() or 2500))
            self._refresh_job = self.after(interval, self.refresh_processes)

    def _sort_processes(self, column: str) -> None:
        if self._sort_column == column:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_column = column
            self._sort_reverse = column in {"cpu_percent", "memory_mb", "read_mb", "write_mb", "threads", "pid"}
        self._render_processes()

    def _process_filter(self, rows: list[ProcessInfo]) -> list[ProcessInfo]:
        query = self.filter_var.get().lower().strip() if hasattr(self, "filter_var") else ""
        if query:
            rows = [row for row in rows if query in row.name.lower() or query in str(row.pid) or query in row.username.lower() or query in row.exe.lower()]
        if self.heavy_only.get():
            rows = [row for row in rows if row.cpu_percent >= 5 or row.memory_mb >= 400]
        return rows

    def _render_processes(self) -> None:
        if not hasattr(self, "process_tree"):
            return
        rows = self._process_filter(list(self.process_rows))
        rows = sorted(rows, key=lambda item: getattr(item, self._sort_column), reverse=self._sort_reverse)

        for item in self.process_tree.get_children():
            self.process_tree.delete(item)

        for row in rows:
            self.process_tree.insert(
                "",
                "end",
                iid=str(row.pid),
                values=(
                    row.pid,
                    row.name,
                    row.username,
                    row.status,
                    f"{row.cpu_percent:.1f}",
                    f"{row.memory_mb:.1f}",
                    f"{row.read_mb:.1f}",
                    f"{row.write_mb:.1f}",
                    row.threads,
                    row.priority,
                    row.exe,
                ),
            )
        self.status.set(f"Showing {len(rows)} of {len(self.process_rows)} processes")

    def _render_dashboard_heavy(self) -> None:
        if not hasattr(self, "dashboard_heavy_tree"):
            return
        for item in self.dashboard_heavy_tree.get_children():
            self.dashboard_heavy_tree.delete(item)
        rows = sorted(self.process_rows, key=lambda row: (row.cpu_percent, row.memory_mb), reverse=True)[:12]
        for row in rows:
            self.dashboard_heavy_tree.insert("", "end", values=(row.pid, row.name, f"{row.cpu_percent:.1f}", f"{row.memory_mb:.1f}", row.priority))

    def selected_pid(self) -> int | None:
        selected = self.process_tree.selection()
        if not selected:
            messagebox.showinfo("QTask Optimizer", "Select a process first.")
            return None
        return int(selected[0])

    def _selected_process_row(self) -> ProcessInfo | None:
        pid = self.selected_pid()
        if pid is None:
            return None
        for row in self.process_rows:
            if row.pid == pid:
                return row
        return None

    def show_process_details(self) -> None:
        pid = self.selected_pid()
        if pid is None:
            return
        try:
            details = self.process_service.details(pid)
        except Exception as exc:
            messagebox.showerror("Details failed", str(exc))
            return
        win = tk.Toplevel(self)
        win.title(f"Process details — PID {pid}")
        win.geometry("760x560")
        win.configure(bg=COLORS["bg"])
        text = tk.Text(win, bg=COLORS["table"], fg=COLORS["text"], insertbackground=COLORS["text"], relief="flat", wrap="word")
        text.pack(fill="both", expand=True, padx=14, pady=14)
        for key, value in details.items():
            text.insert("end", f"{key}: {value}\n\n")
        text.config(state="disabled")

    def copy_selected_pid(self) -> None:
        pid = self.selected_pid()
        if pid is None:
            return
        self.clipboard_clear()
        self.clipboard_append(str(pid))
        self.status.set(f"Copied PID {pid}")

    def open_selected_location(self) -> None:
        row = self._selected_process_row()
        if row is None:
            return
        if not row.exe:
            messagebox.showinfo("QTask Optimizer", "Executable path is unavailable for this process.")
            return
        try:
            open_path(Path(row.exe).parent)
        except Exception as exc:
            messagebox.showerror("Open location failed", str(exc))

    def terminate_selected(self) -> None:
        pid = self.selected_pid()
        if pid is None:
            return
        if self.confirm_actions.get() and not messagebox.askyesno("Terminate process", f"Terminate process {pid}? Unsaved work may be lost."):
            return
        try:
            self.process_service.terminate(pid)
            self.status.set(f"Terminated PID {pid}")
            self.refresh_processes()
        except Exception as exc:
            messagebox.showerror("Terminate failed", str(exc))

    def kill_selected(self) -> None:
        pid = self.selected_pid()
        if pid is None:
            return
        if self.confirm_actions.get() and not messagebox.askyesno("Kill process", f"Force kill process {pid}? This is stronger than terminate."):
            return
        try:
            self.process_service.kill(pid)
            self.status.set(f"Killed PID {pid}")
            self.refresh_processes()
        except Exception as exc:
            messagebox.showerror("Kill failed", str(exc))

    def suspend_selected(self) -> None:
        pid = self.selected_pid()
        if pid is None:
            return
        if self.confirm_actions.get() and not messagebox.askyesno("Suspend process", f"Suspend PID {pid}? Suspended apps stop running until resumed."):
            return
        try:
            self.process_service.suspend(pid)
            self.status.set(f"Suspended PID {pid}")
            self.refresh_processes()
        except Exception as exc:
            messagebox.showerror("Suspend failed", str(exc))

    def resume_selected(self) -> None:
        pid = self.selected_pid()
        if pid is None:
            return
        try:
            self.process_service.resume(pid)
            self.status.set(f"Resumed PID {pid}")
            self.refresh_processes()
        except Exception as exc:
            messagebox.showerror("Resume failed", str(exc))

    def set_selected_priority(self, level: str) -> None:
        pid = self.selected_pid()
        if pid is None:
            return
        if level in {"above_normal", "high"} and self.confirm_actions.get() and not messagebox.askyesno("Boost priority", f"Boost PID {pid}? This may require admin/root rights."):
            return
        try:
            self.process_service.set_priority(pid, level)  # type: ignore[arg-type]
            self.status.set(f"Set PID {pid} priority to {level}")
            self.refresh_processes()
        except (psutil.AccessDenied, PermissionError) as exc:
            messagebox.showerror("Permission denied", f"Permission denied. Try running as administrator/root.\n\n{exc}")
        except Exception as exc:
            messagebox.showerror("Priority failed", str(exc))

    def export_process_csv(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Export process snapshot",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            ProcessService.export_csv(self.process_rows, path)
            self.status.set(f"Exported {path}")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def refresh_system(self) -> None:
        self._run_worker(system_snapshot, "system")

    def _render_system(self, snapshot) -> None:
        if hasattr(self, "dashboard_cpu"):
            self.dashboard_cpu.set(f"{snapshot.cpu_percent:.1f}%", f"{snapshot.cpu_count} logical cores • load {snapshot.load_average}", snapshot.cpu_percent)
            self.dashboard_mem.set(f"{snapshot.memory_percent:.1f}%", f"{snapshot.memory_used_gb}/{snapshot.memory_total_gb} GB", snapshot.memory_percent)
            self.dashboard_disk.set(f"{snapshot.disk_percent:.1f}%", f"{snapshot.disk_used_gb}/{snapshot.disk_total_gb} GB home disk", snapshot.disk_percent)
            self.dashboard_net.set(f"{snapshot.net_recv_mb:.0f} MB", f"received • sent {snapshot.net_sent_mb:.0f} MB", 30)
        if hasattr(self, "opt_cpu"):
            self.opt_cpu.set(f"{snapshot.cpu_percent:.1f}%", f"{snapshot.cpu_count} logical CPUs", snapshot.cpu_percent)
            self.opt_mem.set(f"{snapshot.memory_percent:.1f}%", f"{snapshot.memory_used_gb}/{snapshot.memory_total_gb} GB", snapshot.memory_percent)
            self.opt_swap.set(f"{snapshot.swap_percent:.1f}%", f"{snapshot.swap_used_gb}/{snapshot.swap_total_gb} GB", snapshot.swap_percent)
            self.opt_proc.set(str(snapshot.process_count), f"{snapshot.thread_count} threads", min(100, snapshot.process_count / 4))
        self.status.set(f"System refreshed. Boot: {snapshot.boot_time}")

    def preview_temp_cleanup(self) -> None:
        self.status.set("Scanning temp files...")
        self._run_worker(
            lambda: temp_candidates(
                min_age_days=max(0, int(self.temp_age.get())),
                limit=max(1, int(self.temp_limit.get())),
                min_size_mb=max(0.0, float(self.temp_min_size.get())),
            ),
            "temp",
        )

    def _render_temp_rows(self) -> None:
        for item in self.temp_tree.get_children():
            self.temp_tree.delete(item)
        for row in self.temp_rows:
            self.temp_tree.insert("", "end", values=(f"{row.size_mb:.2f}", row.modified, row.path))

    def delete_previewed_temp(self) -> None:
        if not self.temp_rows:
            messagebox.showinfo("QTask Optimizer", "Run Preview first.")
            return
        total = sum(item.size_mb for item in self.temp_rows)
        if self.confirm_actions.get() and not messagebox.askyesno("Delete temp files", f"Delete {len(self.temp_rows)} temp files and free about {total:.2f} MB?"):
            return
        deleted, freed, failures = delete_files(item.path for item in self.temp_rows)
        self.temp_rows = []
        self._render_temp_rows()
        self._write_optimizer_log(f"Deleted {deleted} temp files, freed {freed:.2f} MB.")
        if failures:
            self._write_optimizer_log("Some files could not be deleted:\n" + "\n".join(failures[:20]))
        self.refresh_system()

    def _write_optimizer_log(self, text: str) -> None:
        self.optimize_text.config(state="normal")
        self.optimize_text.insert("end", "\n" + text + "\n")
        self.optimize_text.see("end")
        self.optimize_text.config(state="disabled")

    def choose_folder(self) -> None:
        folder = filedialog.askdirectory(initialdir=self.folder_var.get() or str(Path.home()))
        if folder:
            self.folder_var.set(folder)

    def analyze_home_folder(self) -> None:
        self.folder_var.set(str(Path.home()))
        self.show_page("Data Analyzer")
        self.analyze_folder()

    def analyze_folder(self) -> None:
        folder = self.folder_var.get().strip()
        if not folder:
            return
        self.status.set(f"Analyzing {folder}...")
        limit = max(1, int(self.file_limit.get()))
        min_size = max(0.0, float(self.file_min_size.get()))
        self._run_worker(lambda: (*analyze_directory(folder, limit=limit, min_size_mb=min_size), folder_breakdown(folder, limit=80)), "analysis")

    def _render_files(self) -> None:
        for item in self.file_tree.get_children():
            self.file_tree.delete(item)
        for idx, row in enumerate(self.file_rows):
            self.file_tree.insert("", "end", iid=str(idx), values=(f"{row.size_mb:.2f}", row.modified, row.path))
        self.status.set(f"Analyzed {len(self.file_rows)} large files")

    def _render_extension_stats(self) -> None:
        for item in self.ext_tree.get_children():
            self.ext_tree.delete(item)
        for row in self.ext_rows:
            self.ext_tree.insert("", "end", values=(row.extension, row.count, f"{row.size_mb:.2f}"))

    def _render_folder_stats(self) -> None:
        for item in self.folder_tree.get_children():
            self.folder_tree.delete(item)
        for row in self.folder_rows:
            self.folder_tree.insert("", "end", values=(f"{row.size_mb:.2f}", row.files, row.path))

    def _selected_file_path(self) -> str | None:
        selected = self.file_tree.selection()
        if not selected:
            messagebox.showinfo("QTask Optimizer", "Select a file first.")
            return None
        idx = int(selected[0])
        if idx < 0 or idx >= len(self.file_rows):
            return None
        return self.file_rows[idx].path

    def open_selected_file_location(self) -> None:
        path = self._selected_file_path()
        if not path:
            return
        try:
            open_path(Path(path).parent)
        except Exception as exc:
            messagebox.showerror("Open location failed", str(exc))

    def copy_selected_file_path(self) -> None:
        path = self._selected_file_path()
        if not path:
            return
        self.clipboard_clear()
        self.clipboard_append(path)
        self.status.set("Copied file path")

    def export_file_csv(self) -> None:
        if not self.file_rows:
            messagebox.showinfo("QTask Optimizer", "Analyze a folder first.")
            return
        path = filedialog.asksaveasfilename(title="Export file analysis", defaultextension=".csv", filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        try:
            export_file_items(self.file_rows, path)
            self.status.set(f"Exported {path}")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def export_ext_csv(self) -> None:
        if not self.ext_rows:
            messagebox.showinfo("QTask Optimizer", "Analyze a folder first.")
            return
        path = filedialog.asksaveasfilename(title="Export extension analysis", defaultextension=".csv", filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        try:
            export_extension_stats(self.ext_rows, path)
            self.status.set(f"Exported {path}")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def refresh_network(self) -> None:
        self.status.set("Refreshing network endpoints...")
        self._run_worker(lambda: network_connections(limit=600), "network")

    def _render_network_rows(self) -> None:
        for item in self.network_tree.get_children():
            self.network_tree.delete(item)
        for row in self.network_rows:
            self.network_tree.insert("", "end", values=(row.pid or "", row.process, row.local, row.remote, row.status))
        self.net_summary.set(f"{len(self.network_rows)} endpoints shown. Some process names may require admin/root permissions.")
        self.status.set("Network refreshed")

    def refresh_startup(self) -> None:
        self.status.set("Refreshing startup entries...")
        self._run_worker(list_startup_items, "startup")

    def _render_startup_rows(self) -> None:
        for item in self.startup_tree.get_children():
            self.startup_tree.delete(item)
        for row in self.startup_rows:
            self.startup_tree.insert("", "end", values=(row.name, row.source, row.enabled, row.command))
        self.status.set(f"Startup review: {len(self.startup_rows)} entries")

    def open_startup_folder(self) -> None:
        paths: list[Path] = []
        if platform.system() == "Windows":
            appdata = os.environ.get("APPDATA")
            if appdata:
                paths.append(Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")
        else:
            paths.append(Path.home() / ".config" / "autostart")
        try:
            path = paths[0]
            path.mkdir(parents=True, exist_ok=True)
            open_path(path)
        except Exception as exc:
            messagebox.showerror("Open startup folder failed", str(exc))
