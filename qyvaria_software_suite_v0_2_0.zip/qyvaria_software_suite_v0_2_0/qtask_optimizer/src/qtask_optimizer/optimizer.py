from __future__ import annotations

import csv
import os
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(slots=True)
class FileItem:
    path: str
    size_mb: float
    modified: str


@dataclass(slots=True)
class ExtensionStat:
    extension: str
    count: int
    size_mb: float


@dataclass(slots=True)
class FolderStat:
    path: str
    files: int
    size_mb: float


def _safe_walk(root: Path) -> Iterable[Path]:
    for current, dirs, files in os.walk(root, topdown=True):
        # Avoid common virtual/system mount traps.
        dirs[:] = [d for d in dirs if d not in {".git", "node_modules", "__pycache__", "proc", "sys", "dev"}]
        for name in files:
            yield Path(current) / name


def analyze_directory(
    root: str | os.PathLike[str],
    limit: int = 100,
    min_size_mb: float = 0.0,
) -> tuple[list[FileItem], list[ExtensionStat]]:
    root_path = Path(root).expanduser().resolve()
    if not root_path.exists() or not root_path.is_dir():
        raise ValueError(f"Not a directory: {root}")

    largest: list[FileItem] = []
    stats: dict[str, list[float]] = {}

    for path in _safe_walk(root_path):
        try:
            st = path.stat()
        except (OSError, PermissionError):
            continue

        ext = path.suffix.lower() or "[no extension]"
        size_mb = st.st_size / (1024 * 1024)
        if ext not in stats:
            stats[ext] = [0, 0.0]
        stats[ext][0] += 1
        stats[ext][1] += size_mb

        if size_mb < min_size_mb:
            continue

        largest.append(
            FileItem(
                path=str(path),
                size_mb=round(size_mb, 2),
                modified=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime)),
            )
        )
        if len(largest) > limit * 4:
            largest.sort(key=lambda item: item.size_mb, reverse=True)
            largest = largest[:limit]

    largest.sort(key=lambda item: item.size_mb, reverse=True)
    ext_rows = [
        ExtensionStat(extension=ext, count=int(values[0]), size_mb=round(values[1], 2))
        for ext, values in stats.items()
    ]
    ext_rows.sort(key=lambda item: item.size_mb, reverse=True)
    return largest[:limit], ext_rows[:limit]


def folder_breakdown(root: str | os.PathLike[str], limit: int = 50) -> list[FolderStat]:
    root_path = Path(root).expanduser().resolve()
    if not root_path.exists() or not root_path.is_dir():
        raise ValueError(f"Not a directory: {root}")

    stats: dict[str, list[float]] = {}
    for path in _safe_walk(root_path):
        try:
            st = path.stat()
        except (OSError, PermissionError):
            continue

        parent = str(path.parent)
        if parent not in stats:
            stats[parent] = [0, 0.0]
        stats[parent][0] += 1
        stats[parent][1] += st.st_size / (1024 * 1024)

    rows = [FolderStat(path=path, files=int(values[0]), size_mb=round(values[1], 2)) for path, values in stats.items()]
    rows.sort(key=lambda item: item.size_mb, reverse=True)
    return rows[:limit]


def temp_candidates(min_age_days: int = 3, limit: int = 500, min_size_mb: float = 0.0) -> list[FileItem]:
    """Return old files from the OS temp folder only. Does not delete anything."""
    temp_root = Path(tempfile.gettempdir()).resolve()
    cutoff = time.time() - (min_age_days * 86400)
    items: list[FileItem] = []

    for path in _safe_walk(temp_root):
        try:
            st = path.stat()
            if st.st_mtime > cutoff:
                continue
            size_mb = st.st_size / (1024 * 1024)
            if size_mb < min_size_mb:
                continue
        except (OSError, PermissionError):
            continue

        items.append(
            FileItem(
                path=str(path),
                size_mb=round(size_mb, 2),
                modified=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime)),
            )
        )
        if len(items) >= limit:
            break

    items.sort(key=lambda item: item.size_mb, reverse=True)
    return items


def delete_files(paths: Iterable[str]) -> tuple[int, float, list[str]]:
    """Delete explicit files only. Returns deleted count, freed MB, and failures."""
    deleted = 0
    freed = 0.0
    failures: list[str] = []
    temp_root = Path(tempfile.gettempdir()).resolve()

    for raw in paths:
        try:
            path = Path(raw).resolve()
            # Safety guard: temp cleanup only deletes files inside temp root.
            if temp_root not in path.parents and path != temp_root:
                failures.append(f"Skipped outside temp: {raw}")
                continue
            if not path.is_file():
                failures.append(f"Skipped not a file: {raw}")
                continue
            size = path.stat().st_size / (1024 * 1024)
            path.unlink()
            deleted += 1
            freed += size
        except Exception as exc:  # noqa: BLE001 - user-facing utility should continue.
            failures.append(f"{raw}: {exc}")

    return deleted, round(freed, 2), failures


def export_file_items(rows: Iterable[FileItem], path: str | os.PathLike[str]) -> None:
    rows = list(rows)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()) if rows else list(FileItem.__dataclass_fields__))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def export_extension_stats(rows: Iterable[ExtensionStat], path: str | os.PathLike[str]) -> None:
    rows = list(rows)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(rows[0]).keys()) if rows else list(ExtensionStat.__dataclass_fields__))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))
