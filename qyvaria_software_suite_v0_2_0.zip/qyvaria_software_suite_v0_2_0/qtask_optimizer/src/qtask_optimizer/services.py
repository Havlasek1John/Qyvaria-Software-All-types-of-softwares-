from __future__ import annotations

import csv
import os
import platform
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Literal

import psutil

PriorityLevel = Literal["idle", "low", "normal", "above_normal", "high"]


@dataclass(slots=True)
class ProcessInfo:
    pid: int
    name: str
    username: str
    status: str
    cpu_percent: float
    memory_mb: float
    read_mb: float
    write_mb: float
    threads: int
    priority: str
    exe: str


@dataclass(slots=True)
class DiskInfo:
    mountpoint: str
    device: str
    fstype: str
    percent: float
    used_gb: float
    total_gb: float


@dataclass(slots=True)
class NetworkConnection:
    pid: int | None
    process: str
    local: str
    remote: str
    status: str


@dataclass(slots=True)
class StartupItem:
    name: str
    source: str
    command: str
    enabled: str


@dataclass(slots=True)
class SystemSnapshot:
    cpu_percent: float
    cpu_count: int
    memory_percent: float
    memory_used_gb: float
    memory_total_gb: float
    swap_percent: float
    swap_used_gb: float
    swap_total_gb: float
    disk_percent: float
    disk_used_gb: float
    disk_total_gb: float
    boot_time: str
    process_count: int
    thread_count: int
    net_sent_mb: float
    net_recv_mb: float
    load_average: str
    disks: list[DiskInfo]


def _format_addr(addr: object) -> str:
    if not addr:
        return ""
    try:
        ip = getattr(addr, "ip", "")
        port = getattr(addr, "port", "")
        if ip and port:
            return f"{ip}:{port}"
        return str(addr)
    except Exception:
        return str(addr)


class ProcessService:
    """Small wrapper around psutil with safe exception handling."""

    def __init__(self) -> None:
        self._seen: dict[int, psutil.Process] = {}
        # Warm counters so subsequent process cpu_percent values become useful.
        psutil.cpu_percent(interval=None)

    @staticmethod
    def _priority_label(proc: psutil.Process) -> str:
        try:
            value = proc.nice()
            if platform.system() == "Windows":
                mapping = {
                    getattr(psutil, "IDLE_PRIORITY_CLASS", None): "idle",
                    getattr(psutil, "BELOW_NORMAL_PRIORITY_CLASS", None): "low",
                    getattr(psutil, "NORMAL_PRIORITY_CLASS", None): "normal",
                    getattr(psutil, "ABOVE_NORMAL_PRIORITY_CLASS", None): "above normal",
                    getattr(psutil, "HIGH_PRIORITY_CLASS", None): "high",
                    getattr(psutil, "REALTIME_PRIORITY_CLASS", None): "realtime",
                }
                return mapping.get(value, str(value))
            return f"nice {value}"
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return "unknown"

    def list_processes(self) -> list[ProcessInfo]:
        rows: list[ProcessInfo] = []
        alive_pids: set[int] = set()
        attrs = ["pid", "name", "username", "status", "num_threads", "exe"]

        for proc in psutil.process_iter(attrs):
            try:
                pid = int(proc.info.get("pid") or proc.pid)
                alive_pids.add(pid)
                cached = self._seen.get(pid)
                if cached is None:
                    cached = proc
                    self._seen[pid] = cached
                    cached.cpu_percent(interval=None)

                mem = cached.memory_info().rss / (1024 * 1024)
                cpu = cached.cpu_percent(interval=None)
                try:
                    io = cached.io_counters()
                    read_mb = io.read_bytes / (1024 * 1024)
                    write_mb = io.write_bytes / (1024 * 1024)
                except (psutil.AccessDenied, AttributeError, NotImplementedError):
                    read_mb = 0.0
                    write_mb = 0.0

                rows.append(
                    ProcessInfo(
                        pid=pid,
                        name=proc.info.get("name") or "",
                        username=proc.info.get("username") or "",
                        status=proc.info.get("status") or "",
                        cpu_percent=round(cpu, 1),
                        memory_mb=round(mem, 1),
                        read_mb=round(read_mb, 1),
                        write_mb=round(write_mb, 1),
                        threads=int(proc.info.get("num_threads") or 0),
                        priority=self._priority_label(cached),
                        exe=proc.info.get("exe") or "",
                    )
                )
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        for pid in list(self._seen):
            if pid not in alive_pids:
                self._seen.pop(pid, None)

        rows.sort(key=lambda item: item.cpu_percent, reverse=True)
        return rows

    @staticmethod
    def get(pid: int) -> psutil.Process:
        return psutil.Process(pid)

    @staticmethod
    def details(pid: int) -> dict[str, object]:
        proc = psutil.Process(pid)
        with proc.oneshot():
            try:
                cmdline = " ".join(proc.cmdline())
            except (psutil.AccessDenied, psutil.ZombieProcess):
                cmdline = "Access denied"
            try:
                cwd = proc.cwd()
            except (psutil.AccessDenied, psutil.ZombieProcess, FileNotFoundError):
                cwd = "Unavailable"
            try:
                exe = proc.exe()
            except (psutil.AccessDenied, psutil.ZombieProcess, FileNotFoundError):
                exe = "Unavailable"
            try:
                open_files = len(proc.open_files())
            except (psutil.AccessDenied, psutil.ZombieProcess):
                open_files = 0
            try:
                conns = len(proc.net_connections(kind="inet"))
            except Exception:
                conns = 0

            mem = proc.memory_info()
            return {
                "PID": proc.pid,
                "Name": proc.name(),
                "Status": proc.status(),
                "User": proc.username(),
                "Priority": ProcessService._priority_label(proc),
                "Created": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(proc.create_time())),
                "CPU %": proc.cpu_percent(interval=0.05),
                "RSS Memory MB": round(mem.rss / (1024 * 1024), 2),
                "Virtual Memory MB": round(mem.vms / (1024 * 1024), 2),
                "Threads": proc.num_threads(),
                "Open files": open_files,
                "Network connections": conns,
                "Executable": exe,
                "Working directory": cwd,
                "Command line": cmdline,
            }

    @staticmethod
    def terminate(pid: int, timeout: float = 3.0) -> None:
        proc = psutil.Process(pid)
        proc.terminate()
        try:
            proc.wait(timeout=timeout)
        except psutil.TimeoutExpired:
            raise TimeoutError(f"Process {pid} did not exit within {timeout} seconds.")

    @staticmethod
    def kill(pid: int) -> None:
        psutil.Process(pid).kill()

    @staticmethod
    def suspend(pid: int) -> None:
        psutil.Process(pid).suspend()

    @staticmethod
    def resume(pid: int) -> None:
        psutil.Process(pid).resume()

    @staticmethod
    def set_priority(pid: int, level: PriorityLevel) -> None:
        proc = psutil.Process(pid)
        system = platform.system()

        if system == "Windows":
            mapping = {
                "idle": psutil.IDLE_PRIORITY_CLASS,
                "low": psutil.BELOW_NORMAL_PRIORITY_CLASS,
                "normal": psutil.NORMAL_PRIORITY_CLASS,
                "above_normal": psutil.ABOVE_NORMAL_PRIORITY_CLASS,
                "high": psutil.HIGH_PRIORITY_CLASS,
            }
            proc.nice(mapping[level])
            return

        # Linux/macOS/BSD nice values. Lower means higher priority.
        mapping = {"idle": 19, "low": 10, "normal": 0, "above_normal": -2, "high": -5}
        proc.nice(mapping[level])

    @staticmethod
    def export_csv(rows: Iterable[ProcessInfo], path: str | os.PathLike[str]) -> None:
        rows = list(rows)
        fieldnames = list(asdict(rows[0]).keys()) if rows else list(ProcessInfo.__dataclass_fields__)
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(asdict(row))


def system_snapshot(path: str | os.PathLike[str] | None = None) -> SystemSnapshot:
    mem = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk = psutil.disk_usage(str(path or Path.home()))
    counters = psutil.net_io_counters()
    disks: list[DiskInfo] = []

    for part in psutil.disk_partitions(all=False):
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except (PermissionError, OSError):
            continue
        disks.append(
            DiskInfo(
                mountpoint=part.mountpoint,
                device=part.device,
                fstype=part.fstype,
                percent=round(usage.percent, 1),
                used_gb=round(usage.used / (1024 ** 3), 2),
                total_gb=round(usage.total / (1024 ** 3), 2),
            )
        )

    load_average = "Unavailable"
    if hasattr(os, "getloadavg"):
        try:
            load_average = ", ".join(f"{value:.2f}" for value in os.getloadavg())
        except OSError:
            load_average = "Unavailable"

    thread_count = 0
    process_count = 0
    for proc in psutil.process_iter(["num_threads"]):
        try:
            process_count += 1
            thread_count += int(proc.info.get("num_threads") or 0)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    return SystemSnapshot(
        cpu_percent=round(psutil.cpu_percent(interval=0.2), 1),
        cpu_count=psutil.cpu_count(logical=True) or 0,
        memory_percent=round(mem.percent, 1),
        memory_used_gb=round(mem.used / (1024 ** 3), 2),
        memory_total_gb=round(mem.total / (1024 ** 3), 2),
        swap_percent=round(swap.percent, 1),
        swap_used_gb=round(swap.used / (1024 ** 3), 2),
        swap_total_gb=round(swap.total / (1024 ** 3), 2),
        disk_percent=round(disk.percent, 1),
        disk_used_gb=round(disk.used / (1024 ** 3), 2),
        disk_total_gb=round(disk.total / (1024 ** 3), 2),
        boot_time=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(psutil.boot_time())),
        process_count=process_count,
        thread_count=thread_count,
        net_sent_mb=round(counters.bytes_sent / (1024 * 1024), 1),
        net_recv_mb=round(counters.bytes_recv / (1024 * 1024), 1),
        load_average=load_average,
        disks=disks,
    )


def network_connections(limit: int = 400) -> list[NetworkConnection]:
    rows: list[NetworkConnection] = []
    name_cache: dict[int, str] = {}
    try:
        connections = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError):
        connections = []

    for conn in connections[:limit]:
        pid = conn.pid
        process_name = ""
        if pid:
            if pid not in name_cache:
                try:
                    name_cache[pid] = psutil.Process(pid).name()
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    name_cache[pid] = ""
            process_name = name_cache[pid]
        rows.append(
            NetworkConnection(
                pid=pid,
                process=process_name,
                local=_format_addr(conn.laddr),
                remote=_format_addr(conn.raddr),
                status=conn.status or "",
            )
        )
    rows.sort(key=lambda item: (item.status, item.process, item.pid or -1))
    return rows


def list_startup_items() -> list[StartupItem]:
    items: list[StartupItem] = []
    system = platform.system()

    if system == "Windows":
        try:
            import winreg  # type: ignore[import-not-found]

            keys = [
                (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU Run"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKLM Run"),
            ]
            for root, path, source in keys:
                try:
                    with winreg.OpenKey(root, path) as key:
                        index = 0
                        while True:
                            try:
                                name, value, _ = winreg.EnumValue(key, index)
                                items.append(StartupItem(name=name, source=source, command=str(value), enabled="yes"))
                                index += 1
                            except OSError:
                                break
                except OSError:
                    continue
        except Exception:
            pass

        for folder_env, source in [("APPDATA", "User Startup folder"), ("PROGRAMDATA", "All Users Startup folder")]:
            base = os.environ.get(folder_env)
            if not base:
                continue
            folder = Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
            if folder.exists():
                for path in folder.iterdir():
                    if path.is_file():
                        items.append(StartupItem(name=path.name, source=source, command=str(path), enabled="yes"))

    else:
        folders = [
            (Path.home() / ".config" / "autostart", "User autostart"),
            (Path("/etc/xdg/autostart"), "System autostart"),
            (Path.home() / ".config" / "systemd" / "user", "User systemd"),
        ]
        for folder, source in folders:
            if not folder.exists():
                continue
            for path in sorted(folder.glob("*")):
                if path.suffix.lower() not in {".desktop", ".service"}:
                    continue
                name = path.stem
                command = str(path)
                enabled = "yes"
                try:
                    text = path.read_text(encoding="utf-8", errors="ignore")
                    for line in text.splitlines():
                        if line.startswith("Name="):
                            name = line.split("=", 1)[1].strip() or name
                        elif line.startswith("Exec="):
                            command = line.split("=", 1)[1].strip() or command
                        elif line.startswith("Hidden=true") or line.startswith("X-GNOME-Autostart-enabled=false"):
                            enabled = "no"
                except OSError:
                    pass
                items.append(StartupItem(name=name, source=source, command=command, enabled=enabled))

    items.sort(key=lambda item: (item.source.lower(), item.name.lower()))
    return items
