from .app import QTaskOptimizerApp

def main() -> None:
    app = QTaskOptimizerApp()
    app.mainloop()

if __name__ == "__main__":
    main()
