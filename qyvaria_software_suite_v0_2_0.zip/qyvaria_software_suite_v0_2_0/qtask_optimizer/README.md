# QTask Optimizer — Qyvarian Edition

A safe cross-platform task manager and optimizer for Windows and Linux, redesigned with a modern Qyvarian dark UI.

QTask Optimizer is designed to be better than a basic task manager without using risky "one-click booster" tricks. It monitors processes, lets you sort and filter them, exports process data, safely changes priority, and includes optimizer tools for cache/temp cleanup, network review, startup review, and large-file analysis.

## What's new in the Qyvarian UI

- Modern dark sidebar layout with dashboard cards
- Live CPU, memory, disk, swap, network, process, and thread overview
- Cleaner action bars and dark tables
- Process details window with command line, memory, path, priority, open files, and network count
- Open executable location, copy PID, suspend, resume, terminate, kill
- Tunable process auto-refresh interval and heavy-process filter
- Optimizer cleanup controls for temp-file age, minimum size, and scan limit
- Temp cleanup preview table before deletion
- Data Analyzer with largest files, extension breakdown, and folder breakdown
- Open selected file location and copy selected path
- Network endpoint viewer with PID/process ownership
- Startup item review for Windows Run keys/startup folders and Linux autostart/systemd user entries
- Settings page for safety confirmations and refresh behavior

## Safety notes

This app does **not** silently delete system files, modify the registry, disable services, or kill processes automatically.

Optimization actions are explicit and user-confirmed. Temp cleanup only deletes files inside the operating system temp directory after preview. Priority boosting, suspend/resume, and killing protected processes can require administrator/root permissions.

## Install from source

### Windows

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m qtask_optimizer
```

### Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m qtask_optimizer
```

On some Linux distributions, Tkinter must be installed separately:

```bash
sudo apt install python3-tk
```

## Build standalone app

> Build scripts now automatically switch to the project root, so they work even if launched from a file manager or another terminal directory.

### Windows EXE

```powershell
.\scripts\build_windows.ps1
```

The executable will be under `dist\QTaskOptimizer\`.

### Linux binary

```bash
chmod +x scripts/build_linux.sh
./scripts/build_linux.sh
```

The binary will be under `dist/QTaskOptimizer/`.

## Development

```bash
pip install -r requirements-dev.txt
python -m qtask_optimizer
python -m pytest
```

## Project structure

```text
src/qtask_optimizer/
  __main__.py
  app.py
  services.py
  optimizer.py
scripts/
  build_windows.ps1
  build_linux.sh
tests/
```


---

## Qyvaria Stable Setup v0.3.0

This package includes installers for both Windows and Linux.

### Linux

```bash
chmod +x scripts/install_linux.sh
./scripts/install_linux.sh
```

This installs the app into `~/.local/share/qyvaria/qtask-optimizer`, adds a launcher in `~/.local/bin`, creates a desktop icon, and adds the app to your Linux app menu.

### Windows

Double-click:

```text
scripts\install_windows.bat
```

This installs the app into `%LOCALAPPDATA%\Qyvaria\qtask-optimizer`, creates a Desktop shortcut, and adds the app to Start Menu > Qyvaria.

### Doctor test

```bash
python scripts/doctor.py
```
