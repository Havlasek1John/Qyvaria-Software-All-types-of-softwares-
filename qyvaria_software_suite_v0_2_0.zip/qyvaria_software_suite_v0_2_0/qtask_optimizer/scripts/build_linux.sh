#!/usr/bin/env bash
set -Eeuo pipefail
APP_NAME="QTask Optimizer"
SLUG="qtask-optimizer"
GUI_MODULE="qtask_optimizer"
CLI_MODULE="qtask_optimizer"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v python3 >/dev/null 2>&1 || { echo "python3 is required"; exit 1; }
python3 -m venv .venv-build
. .venv-build/bin/activate
python -m pip install --upgrade pip setuptools wheel pyinstaller
if [[ -f requirements.txt ]]; then python -m pip install -r requirements.txt; fi
python -m pip install -e .

rm -rf build dist
python -m PyInstaller --noconfirm --clean --name "$SLUG" --windowed --icon assets/qyvaria_icon.ico -m "$GUI_MODULE"
python -m PyInstaller --noconfirm --clean --name "$SLUG-cli" --console -m "$CLI_MODULE"

echo
echo "Build complete:"
echo "  dist/$SLUG/$SLUG"
echo "  dist/$SLUG-cli/$SLUG-cli"
