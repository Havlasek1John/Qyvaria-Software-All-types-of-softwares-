# Qyvaria UX + Installer Upgrade

This build adds the Qyvaria stable installer layer:

- Linux installer with local virtual environment under `~/.local/share/qyvaria/qtask-optimizer`.
- Windows installer with local virtual environment under `%LOCALAPPDATA%\Qyvaria\qtask-optimizer`.
- Desktop icon creation.
- Linux application-menu `.desktop` entry.
- Windows Start Menu shortcut under `Qyvaria`.
- Self-contained doctor script for import and Tkinter checks.
- Cleaner icon assets and consistent Qyvarian branding.

## Linux install

```bash
chmod +x scripts/install_linux.sh
./scripts/install_linux.sh
```

## Windows install

Double-click:

```text
scripts\install_windows.bat
```

Or run PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\install_windows.ps1
```

## Diagnostics

```bash
python scripts/doctor.py
```
