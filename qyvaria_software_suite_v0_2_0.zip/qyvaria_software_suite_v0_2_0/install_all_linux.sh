#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for app in ai_inspector_editor qtask_optimizer qyvaria_zip_resizer safespeed_optimizer; do
  echo
  echo "=============================="
  echo "Installing $app"
  echo "=============================="
  chmod +x "$ROOT/$app/scripts/install_linux.sh"
  "$ROOT/$app/scripts/install_linux.sh"
done
echo
echo "All Qyvaria apps installed. Check your app menu or desktop icons."
