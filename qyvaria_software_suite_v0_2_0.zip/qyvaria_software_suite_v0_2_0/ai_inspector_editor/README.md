# AI Inspector Editor Modern

A polished cross-platform app for analyzing AI software and safely editing its text-based AI modules, agents, prompts, manifests, and configs.

The new **Modern UI** is a local browser dashboard. It feels like a product UI, but it still runs completely on your machine and only binds to `127.0.0.1` by default.

## What is new in this UI upgrade

- Modern dashboard with sidebar navigation, polished cards, risk gauge, findings, and recommendations.
- Guided scan panel with profile cards: Quick, Standard, Deep, and Forensic.
- Native folder/file picker when available, plus manual path input.
- Advanced scan toggles for hashes, secrets, prompts, AST metrics, dependency inventory, binary fingerprints, and text samples.
- Clear views for Dashboard, Agents, Modules, Prompts, Editor, and Raw Report.
- Agent table with search/filtering and detail modal.
- Module graph overview and module detail cards.
- Prompt inventory cards with one-click opening in the safe editor.
- File inventory browser with search and editable file detection.
- Modern safe editor with validate, diff, save-with-backup, backup listing, JSON patching, and new agent manifest creation.
- JSON and Markdown report downloads from the UI.
- Dark and light theme toggle.
- Keyboard shortcuts:
  - `Ctrl/Cmd + Enter`: run scan
  - `Ctrl/Cmd + S`: save the open editor file

## Safety design

AI Inspector Editor does **not** execute target AI software during analysis. It statically reads metadata, parses text, fingerprints binaries, and uses Python AST parsing where needed. The editor refuses to directly edit model weight/binary artifacts such as `.safetensors`, `.bin`, `.pt`, `.onnx`, `.gguf`, and similar files.

## Run on Linux

```bash
cd ai_inspector_editor
python3 -m ai_inspector_editor.app_modern
```

Or:

```bash
./run_linux.sh
```


## Linux note: Python 3.12 / externally-managed-environment

If your system shows `error: externally-managed-environment`, use the updated scripts in this package. They create local virtual environments and do **not** install packages into system Python.

```bash
cd ai_inspector_editor
chmod +x run_linux.sh scripts/build_linux.sh
./run_linux.sh
```

For standalone builds:

```bash
./scripts/build_linux.sh
```

If `python3 -m venv` is missing, install:

```bash
sudo apt update
sudo apt install python3-venv python3-full
```


## Run on Windows

```powershell
cd ai_inspector_editor
py -m ai_inspector_editor.app_modern
```

Or double-click:

```text
run_windows.bat
```

You can also install the package locally and use the console launcher:

```bash
python -m pip install -e .
ai-inspector-editor-ui
```

## CLI still works

```bash
python -m ai_inspector_editor.app_cli analyze examples/sample_ai --profile standard --summary
python -m ai_inspector_editor.app_cli analyze examples/sample_ai --profile deep --out report.json
python -m ai_inspector_editor.app_cli export-md examples/sample_ai --out report.md
python -m ai_inspector_editor.app_cli modern-ui
```

## Build standalone executables

Linux:

```bash
scripts/build_linux.sh
```

Windows PowerShell:

```powershell
scripts\build_windows.ps1
```

The build scripts use PyInstaller and include the modern web UI files.

## Classic GUI

The older Tkinter UI is still included as a fallback:

```bash
python -m ai_inspector_editor.app_cli gui
```

## Project layout

```text
ai_inspector_editor/
  app_modern.py              # new local browser UI server
  web/
    index.html               # modern UI structure
    app.css                  # responsive dark/light dashboard styling
    app.js                   # scan/editor/report interactions
  app_cli.py                 # CLI and launchers
  app_gui.py                 # classic Tkinter fallback UI
  core/
    analyzer.py              # safe static analyzer
    editor.py                # safe text editor with backups
    module_graph.py
    profiles.py
    report.py
examples/sample_ai/          # sample AI project for testing
```

## Smoke test

```bash
python scripts/smoke_test.py
```


---

## Qyvaria Stable Setup v0.5.0

This package includes installers for both Windows and Linux.

### Linux

```bash
chmod +x scripts/install_linux.sh
./scripts/install_linux.sh
```

This installs the app into `~/.local/share/qyvaria/ai-inspector-editor`, adds a launcher in `~/.local/bin`, creates a desktop icon, and adds the app to your Linux app menu.

### Windows

Double-click:

```text
scripts\install_windows.bat
```

This installs the app into `%LOCALAPPDATA%\Qyvaria\ai-inspector-editor`, creates a Desktop shortcut, and adds the app to Start Menu > Qyvaria.

### Doctor test

```bash
python scripts/doctor.py
```
