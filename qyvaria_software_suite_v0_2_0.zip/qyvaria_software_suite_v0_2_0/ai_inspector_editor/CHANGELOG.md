# Changelog

## 0.5.0 — Qyvaria Stable Desktop Upgrade

- Added Linux installer with venv setup, dependency install, desktop icon, app menu entry, and CLI launcher.
- Added Windows installer with venv setup, dependency install, desktop shortcut, and Start Menu entry.
- Added uninstall scripts for Windows and Linux.
- Added doctor diagnostics script.
- Added Qyvaria icon assets.
- Rebuilt build scripts to install PyInstaller automatically in a local build venv.
- Improved Qyvarian UI consistency and desktop behavior.
- Refined modern web UI surfaces and focus states for a cleaner cockpit look.


# Changelog

## 0.4.0 — Modern UI

- Added local browser dashboard UI.
- Added polished responsive dark/light interface.
- Added dashboard cards, risk gauge, findings, artifacts, recommendations, agents, modules, prompts, inventory, safe editor, raw report, and exports.
- Added native folder/file picker endpoint.
- Added report download as JSON/Markdown.
- Added keyboard shortcuts and toast notifications.
- Kept classic Tkinter GUI as fallback.
