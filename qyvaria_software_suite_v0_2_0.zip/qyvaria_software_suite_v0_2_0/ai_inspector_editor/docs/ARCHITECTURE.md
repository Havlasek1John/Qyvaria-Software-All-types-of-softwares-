# Architecture

## Components

### 1. Analyzer Core

`ai_inspector_editor.core.analyzer.AIAnalyzer`

The analyzer walks a file or directory and builds a static report. It never imports or executes analyzed code. It performs:

- file inventory and extension counts
- model artifact fingerprinting
- safetensors header inspection
- lightweight ONNX and GGUF sniffing
- model config/tokenizer/model-card summary
- Python AST parsing
- agent/tool/module/planner/memory detection
- dependency inventory
- prompt inventory
- secret pattern detection
- heuristic risk scoring
- recommended edits

### 2. Scan Profiles

`ai_inspector_editor.core.profiles`

Profiles tune speed and depth:

- `quick`: fast overview
- `standard`: balanced default
- `deep`: broader and more detailed
- `forensic`: maximum local detail, still static-only

### 3. Module Graph

`ai_inspector_editor.core.module_graph`

Parses Python source with `ast` and extracts:

- imports
- classes
- functions and async functions
- call targets
- risky calls
- framework hints
- agent/tool/planner/memory hints
- approximate complexity

### 4. Safe Editor

`ai_inspector_editor.core.editor.SafeEditor`

The editor provides controlled text-asset editing:

- refuses to edit binary model weights
- validates JSON/Python/TOML/INI/basic YAML
- creates backups
- restores backups
- previews diffs
- patches JSON keys
- creates and updates agent manifests

### 5. Desktop UI

`ai_inspector_editor.app_gui`

Tkinter/ttk GUI with no heavy dependencies:

- Dashboard
- Findings
- Agents + Graph
- AI Editor
- Report JSON

### 6. CLI

`ai_inspector_editor.app_cli`

Automation interface for Linux, Windows, CI, and scripted workflows.

## Security model

The tool is safe-by-design:

- no import of target code
- no execution of target scripts
- no pickle/torch deserialization
- no model weights rewriting
- bounded file reads
- optional hash limits
- secret snippets are redacted
- backups are created before editing

## What “edit the AI” means here

This tool safely edits **text-controlled behavior and structure**:

- prompts
- system instructions
- generation configs
- agent manifests
- module code
- routing configs
- tool permissions
- model cards
- deployment metadata

It intentionally does not directly rewrite raw neural weights. To change learned behavior, use fine-tuning, LoRA/adapters, quantization, conversion, or training tools, then re-run the analyzer.
