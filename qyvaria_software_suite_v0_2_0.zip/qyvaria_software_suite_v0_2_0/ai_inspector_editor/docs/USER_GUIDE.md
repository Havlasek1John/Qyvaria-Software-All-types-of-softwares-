# User Guide

## Recommended workflow

1. Choose an AI project folder or model artifact.
2. Run a `quick` or `standard` scan.
3. Review Dashboard risk, findings, agents, and model artifacts.
4. Export JSON or Markdown for records.
5. Open text assets in the editor:
   - configs
   - prompts
   - agent manifests
   - module code
   - model card / README
6. Preview diffs and validate before saving.
7. Save with backup.
8. Re-run analysis and compare reports.

## Scan profile guidance

- Use `quick` when you only need an overview.
- Use `standard` as the normal default.
- Use `deep` when you need prompt samples, more source details, and broader coverage.
- Use `forensic` for high-detail offline review of large projects.

## Agent editing

Create a new agent manifest from the GUI or CLI. The default manifest includes explicit permissions:

```json
{
  "network": false,
  "filesystem_read": true,
  "filesystem_write": false,
  "shell": false,
  "human_approval_required": true
}
```

Keep dangerous permissions disabled unless you have a strong reason and a sandbox.

## Model weights

Model weights such as `.safetensors`, `.pt`, `.bin`, `.onnx`, `.gguf`, and `.ckpt` are not edited directly. The analyzer fingerprints or inspects metadata only.


## Modern UI

Launch the new UI with:

```bash
python -m ai_inspector_editor.app_modern
```

Or through the CLI:

```bash
python -m ai_inspector_editor.app_cli modern-ui
```

Use the dashboard to scan an AI project, review risk/findings/agents/modules/prompts, and edit safe text assets with validation, diff preview, JSON patching, and automatic backups.
