# Modern UI Guide

## Main workflow

1. Launch the UI with `python -m ai_inspector_editor.app_modern`.
2. Paste or choose a target AI project folder.
3. Pick a scan profile.
4. Run Scan.
5. Review Dashboard, Agents, Modules, Prompts, and Raw Report.
6. Open editable files from Inventory.
7. Use Validate and Diff before saving.
8. Save with automatic backup.

## UI sections

### Dashboard

Shows risk, file count, framework guess, agents, prompts, total size, findings, safety notes, model artifacts, and recommended edits.

### Agents

Lists detected agents, tools, memory components, planners, and orchestrators. You can also create a new JSON agent manifest.

### Modules

Shows detected Python modules and a lightweight graph overview.

### Prompts

Lists prompt-like assets and opens editable prompt files directly in the safe editor.

### Editor

Supports editable text assets only. It refuses binary model files and creates backups before saving.

### Raw Report

Shows the full JSON report with search.

## Local server

The modern UI is served on localhost by default:

```bash
python -m ai_inspector_editor.app_modern --host 127.0.0.1 --port 8765
```

Remote access is disabled unless you explicitly pass `--allow-remote`.
