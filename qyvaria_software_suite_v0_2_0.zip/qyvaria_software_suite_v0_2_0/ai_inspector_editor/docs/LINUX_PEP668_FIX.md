# Linux PEP 668 / externally-managed-environment fix

Some newer Debian/Ubuntu/Python 3.12 systems block system-wide `pip install` commands and show:

```text
error: externally-managed-environment
```

This is expected. It protects the operating system Python.

## What changed

The Linux scripts now use local virtual environments:

- `run_linux.sh` creates `.venv` for app runs.
- `scripts/build_linux.sh` creates `.venv-build` for PyInstaller builds.

Nothing is installed into the system Python.

## Run the app

```bash
cd ai_inspector_editor
chmod +x run_linux.sh scripts/build_linux.sh
./run_linux.sh
```

Because the app has no required third-party dependencies, you can also run directly:

```bash
python3 -m ai_inspector_editor.app_modern
```

## Build the standalone Linux executable

```bash
cd ai_inspector_editor
chmod +x scripts/build_linux.sh
./scripts/build_linux.sh
```

The output will be created at:

```text
dist/AI-Inspector-Editor-Modern/AI-Inspector-Editor-Modern
```

## If venv is missing

Install Python venv support:

```bash
sudo apt update
sudo apt install python3-venv python3-full
```

Then run the script again.

## Do not use this unless you understand the risk

Avoid this workaround:

```bash
python3 -m pip install --break-system-packages ...
```

The project scripts no longer need it.
