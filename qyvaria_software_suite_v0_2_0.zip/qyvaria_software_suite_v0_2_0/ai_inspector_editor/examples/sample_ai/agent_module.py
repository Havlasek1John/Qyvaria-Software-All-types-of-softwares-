from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass
class ToolPermission:
    name: str
    allow_network: bool = False
    allow_write: bool = False


class ResearchAgent:
    """Demo agent class used by the analyzer sample."""

    def __init__(self, tools: Iterable[ToolPermission]):
        self.tools = list(tools)
        self.memory_enabled = False

    def plan(self, goal: str) -> list[str]:
        if not goal.strip():
            return ["Ask user for a clearer goal"]
        return [
            "Inspect local README and configs",
            "Summarize modules",
            "Return safe recommendations",
        ]

    def run_tool(self, tool_name: str, query: str) -> str:
        allowed = {tool.name for tool in self.tools}
        if tool_name not in allowed:
            raise PermissionError(f"Tool not allowed: {tool_name}")
        return f"Would run {tool_name} with query={query!r} in a real implementation."


def build_research_agent() -> ResearchAgent:
    return ResearchAgent([ToolPermission("search_local_docs"), ToolPermission("summarize_module")])
