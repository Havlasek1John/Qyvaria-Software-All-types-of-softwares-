from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ai_inspector_editor.core.analyzer import AIAnalyzer
from ai_inspector_editor.core.editor import SafeEditor
from ai_inspector_editor.core.report import human_summary, to_markdown


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    sample = root / "examples" / "sample_ai"
    report = AIAnalyzer(profile="standard").analyze(sample)
    assert report["total_files"] >= 1
    assert "risk" in report
    assert "agents" in report
    assert "module_graph" in report
    print(human_summary(report))

    tmp = sample / "tmp_agent_manifest.json"
    editor = SafeEditor()
    editor.create_agent_manifest_file(tmp, "tmp_agent", "temporary smoke-test agent")
    editor.patch_json_key(tmp, "permissions.filesystem_write", False)
    assert editor.validate_content(tmp, editor.read_text(tmp))["valid"]
    tmp.unlink()
    print("Smoke test passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
