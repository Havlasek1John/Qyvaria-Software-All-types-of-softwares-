@echo off
setlocal
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0build_windows.ps1"
echo.
echo Done. Press Enter to close...
pause >nul
