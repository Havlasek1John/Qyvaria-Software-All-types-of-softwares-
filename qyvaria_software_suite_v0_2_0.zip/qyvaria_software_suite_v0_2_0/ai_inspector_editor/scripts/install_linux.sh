#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME="AI Inspector Editor"
SLUG="ai-inspector-editor"
GUI_MODULE="ai_inspector_editor.app_modern"
CLI_MODULE="ai_inspector_editor.app_cli"
INSTALL_ROOT="${XDG_DATA_HOME:-$HOME/.local/share}/qyvaria/$SLUG"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
DESKTOP_DIR="${XDG_DESKTOP_DIR:-$HOME/Desktop}"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "Installing $APP_NAME to $INSTALL_ROOT"
command -v python3 >/dev/null 2>&1 || { echo "python3 is required."; exit 1; }
python3 - <<'PYTK'
try:
    import tkinter
except Exception as exc:
    raise SystemExit("Tkinter is missing. Install it first, for example: sudo apt install python3-tk")
PYTK

mkdir -p "$INSTALL_ROOT" "$BIN_DIR" "$APPS_DIR" "$DESKTOP_DIR"
rsync -a --delete --exclude '.venv' --exclude '.venv-build' --exclude 'dist' --exclude 'build' "$SOURCE_DIR/" "$INSTALL_ROOT/" 2>/dev/null || {
  rm -rf "$INSTALL_ROOT"
  mkdir -p "$INSTALL_ROOT"
  cp -R "$SOURCE_DIR"/. "$INSTALL_ROOT"/
}

cd "$INSTALL_ROOT"
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
if [[ -f requirements.txt ]]; then python -m pip install -r requirements.txt; fi
if [[ -f requirements-dev.txt ]]; then python -m pip install -r requirements-dev.txt || true; fi
python -m pip install -e .

cat > "$INSTALL_ROOT/$SLUG-gui.sh" <<EOF
#!/usr/bin/env bash
cd "$INSTALL_ROOT"
. "$INSTALL_ROOT/.venv/bin/activate"
exec python -m "$GUI_MODULE" "\$@"
EOF
chmod +x "$INSTALL_ROOT/$SLUG-gui.sh"

cat > "$INSTALL_ROOT/$SLUG-cli.sh" <<EOF
#!/usr/bin/env bash
cd "$INSTALL_ROOT"
. "$INSTALL_ROOT/.venv/bin/activate"
exec python -m "$CLI_MODULE" "\$@"
EOF
chmod +x "$INSTALL_ROOT/$SLUG-cli.sh"

ln -sf "$INSTALL_ROOT/$SLUG-gui.sh" "$BIN_DIR/$SLUG"
ln -sf "$INSTALL_ROOT/$SLUG-cli.sh" "$BIN_DIR/$SLUG-cli"

cat > "$APPS_DIR/$SLUG.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=$APP_NAME
Comment=Modern AI software analyzer and safe module editor.
Exec=$INSTALL_ROOT/$SLUG-gui.sh
Icon=$INSTALL_ROOT/assets/qyvaria_icon.png
Terminal=false
Categories=Development;Utility;
StartupNotify=true
EOF
chmod +x "$APPS_DIR/$SLUG.desktop"

cp "$APPS_DIR/$SLUG.desktop" "$DESKTOP_DIR/$SLUG.desktop" 2>/dev/null || true
chmod +x "$DESKTOP_DIR/$SLUG.desktop" 2>/dev/null || true
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS_DIR" || true

echo
echo "$APP_NAME installed."
echo "Launch from your app menu, desktop icon, or command:"
echo "  $SLUG"
