#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

PYTHON_BIN="${PYTHON_BIN:-python3}"
VENV_DIR="${VENV_DIR:-.venv}"

if [ "${AI_INSPECTOR_NO_VENV:-0}" = "1" ]; then
  exec "$PYTHON_BIN" -m ai_inspector_editor.app_modern
fi

if [ ! -d "$VENV_DIR" ]; then
  echo "Creating local app virtual environment: $VENV_DIR"
  if ! "$PYTHON_BIN" -m venv "$VENV_DIR"; then
    echo
    echo "ERROR: Python venv support is missing."
    echo "On Debian/Ubuntu, install it with:"
    echo "  sudo apt update && sudo apt install python3-venv python3-full"
    echo
    echo "Alternative, run without venv because this app has no required third-party deps:"
    echo "  AI_INSPECTOR_NO_VENV=1 ./run_linux.sh"
    exit 1
  fi
fi

# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

# The app currently has no required third-party dependencies.
# Install editable package locally only if desired by setting AI_INSPECTOR_INSTALL=1.
if [ "${AI_INSPECTOR_INSTALL:-0}" = "1" ]; then
  python -m pip install --upgrade pip
  python -m pip install -e .
fi

exec python -m ai_inspector_editor.app_modern
