from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from .core.analyzer import AIAnalyzer
from .core.editor import AGENT_SCHEMA_KEYS, SafeEditor
from .core.profiles import SCAN_PROFILES
from .core.report import human_summary, save_report, to_markdown, to_pretty_json


class AIInspectorEditorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AI Inspector Editor Advanced")
        self.geometry("1320x860")
        self.minsize(1050, 680)
        self.editor = SafeEditor()
        self.current_file: Path | None = None
        self.last_report = None
        self._theme = tk.StringVar(value="dark")
        self._build_style()
        self._build_ui()

    def _build_style(self):
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.colors = {
            "dark": {
                "bg": "#111827", "panel": "#1f2937", "panel2": "#273449", "text": "#e5e7eb",
                "muted": "#9ca3af", "accent": "#7c3aed", "ok": "#10b981", "warn": "#f59e0b", "bad": "#ef4444",
                "entry": "#0b1220",
            },
            "light": {
                "bg": "#f3f4f6", "panel": "#ffffff", "panel2": "#e5e7eb", "text": "#111827",
                "muted": "#4b5563", "accent": "#6d28d9", "ok": "#047857", "warn": "#b45309", "bad": "#b91c1c",
                "entry": "#ffffff",
            },
        }
        self._apply_theme()

    def _apply_theme(self):
        c = self.colors[self._theme.get()]
        self.configure(bg=c["bg"])
        self.style.configure(".", background=c["bg"], foreground=c["text"], fieldbackground=c["entry"], bordercolor=c["panel2"])
        self.style.configure("TFrame", background=c["bg"])
        self.style.configure("Panel.TFrame", background=c["panel"])
        self.style.configure("TLabel", background=c["bg"], foreground=c["text"])
        self.style.configure("Muted.TLabel", background=c["bg"], foreground=c["muted"])
        self.style.configure("Panel.TLabel", background=c["panel"], foreground=c["text"])
        self.style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), background=c["bg"], foreground=c["text"])
        self.style.configure("Card.TLabel", font=("Segoe UI", 10, "bold"), background=c["panel"], foreground=c["text"])
        self.style.configure("Value.TLabel", font=("Segoe UI", 16, "bold"), background=c["panel"], foreground=c["accent"])
        self.style.configure("TButton", padding=7)
        self.style.configure("Accent.TButton", padding=8)
        self.style.configure("TNotebook", background=c["bg"], borderwidth=0)
        self.style.configure("TNotebook.Tab", padding=(14, 8))
        self.style.configure("Treeview", background=c["entry"], fieldbackground=c["entry"], foreground=c["text"], rowheight=26)
        self.style.configure("Treeview.Heading", background=c["panel2"], foreground=c["text"], font=("Segoe UI", 9, "bold"))

    def _build_ui(self):
        self.columnconfigure(0, weight=0)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

        header = ttk.Frame(self, style="TFrame")
        header.grid(row=0, column=0, columnspan=2, sticky="ew", padx=16, pady=(14, 8))
        ttk.Label(header, text="AI Inspector Editor Advanced", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="Static AI analyzer + safe agent/module editor", style="Muted.TLabel").pack(side="left", padx=16)
        ttk.Button(header, text="Toggle Theme", command=self.toggle_theme).pack(side="right")

        sidebar = ttk.Frame(self, style="Panel.TFrame", width=260)
        sidebar.grid(row=1, column=0, sticky="nsw", padx=(16, 8), pady=(0, 16))
        sidebar.grid_propagate(False)
        self._build_sidebar(sidebar)

        self.notebook = ttk.Notebook(self)
        self.notebook.grid(row=1, column=1, sticky="nsew", padx=(0, 16), pady=(0, 16))

        self.tab_dashboard = ttk.Frame(self.notebook)
        self.tab_findings = ttk.Frame(self.notebook)
        self.tab_graph = ttk.Frame(self.notebook)
        self.tab_editor = ttk.Frame(self.notebook)
        self.tab_json = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_dashboard, text="Dashboard")
        self.notebook.add(self.tab_findings, text="Findings")
        self.notebook.add(self.tab_graph, text="Agents + Graph")
        self.notebook.add(self.tab_editor, text="AI Editor")
        self.notebook.add(self.tab_json, text="Report JSON")

        self._build_dashboard_tab()
        self._build_findings_tab()
        self._build_graph_tab()
        self._build_editor_tab()
        self._build_json_tab()

    def _build_sidebar(self, parent):
        c = self.colors[self._theme.get()]
        ttk.Label(parent, text="Scan Target", style="Panel.TLabel", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=14, pady=(14, 4))
        self.path_var = tk.StringVar()
        path_entry = ttk.Entry(parent, textvariable=self.path_var)
        path_entry.pack(fill="x", padx=14, pady=4)
        ttk.Button(parent, text="Choose File", command=self.choose_file).pack(fill="x", padx=14, pady=3)
        ttk.Button(parent, text="Choose Folder", command=self.choose_folder).pack(fill="x", padx=14, pady=3)

        ttk.Separator(parent).pack(fill="x", padx=14, pady=14)
        ttk.Label(parent, text="Scan Options", style="Panel.TLabel", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=14, pady=(4, 4))

        self.profile_var = tk.StringVar(value="standard")
        profile = ttk.Combobox(parent, textvariable=self.profile_var, values=list(SCAN_PROFILES.keys()), state="readonly")
        profile.pack(fill="x", padx=14, pady=4)

        self.hashes_var = tk.BooleanVar(value=True)
        self.secrets_var = tk.BooleanVar(value=True)
        self.prompts_var = tk.BooleanVar(value=True)
        self.samples_var = tk.BooleanVar(value=False)
        for text, var in [
            ("Include SHA-256 hashes", self.hashes_var),
            ("Secret/API key scan", self.secrets_var),
            ("Prompt inventory", self.prompts_var),
            ("Redacted text samples", self.samples_var),
        ]:
            ttk.Checkbutton(parent, text=text, variable=var).pack(anchor="w", padx=14, pady=2)

        ttk.Button(parent, text="Analyze", style="Accent.TButton", command=self.run_analysis).pack(fill="x", padx=14, pady=(14, 3))
        ttk.Button(parent, text="Export JSON", command=self.export_json).pack(fill="x", padx=14, pady=3)
        ttk.Button(parent, text="Export Markdown", command=self.export_markdown).pack(fill="x", padx=14, pady=3)

        ttk.Separator(parent).pack(fill="x", padx=14, pady=14)
        ttk.Label(parent, text="Editor Shortcuts", style="Panel.TLabel", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=14, pady=(4, 4))
        ttk.Button(parent, text="Open Text Asset", command=self.open_text_asset).pack(fill="x", padx=14, pady=3)
        ttk.Button(parent, text="New Agent Manifest", command=self.new_agent_manifest).pack(fill="x", padx=14, pady=3)
        ttk.Button(parent, text="Validate Current File", command=self.validate_text_asset).pack(fill="x", padx=14, pady=3)

        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(parent, textvariable=self.status_var, style="Panel.TLabel", wraplength=220).pack(side="bottom", anchor="w", padx=14, pady=14)

    def _build_dashboard_tab(self):
        outer = ttk.Frame(self.tab_dashboard)
        outer.pack(fill="both", expand=True, padx=14, pady=14)

        cards = ttk.Frame(outer)
        cards.pack(fill="x")
        self.card_vars = {
            "risk": tk.StringVar(value="—"),
            "files": tk.StringVar(value="—"),
            "agents": tk.StringVar(value="—"),
            "models": tk.StringVar(value="—"),
            "framework": tk.StringVar(value="—"),
        }
        for label, key in [("Risk", "risk"), ("Files", "files"), ("Agents", "agents"), ("Models", "models"), ("Framework", "framework")]:
            card = ttk.Frame(cards, style="Panel.TFrame", padding=14)
            card.pack(side="left", fill="x", expand=True, padx=5)
            ttk.Label(card, text=label, style="Card.TLabel").pack(anchor="w")
            ttk.Label(card, textvariable=self.card_vars[key], style="Value.TLabel", wraplength=190).pack(anchor="w", pady=(6, 0))

        panes = ttk.Panedwindow(outer, orient="horizontal")
        panes.pack(fill="both", expand=True, pady=(14, 0))
        left = ttk.Frame(panes)
        right = ttk.Frame(panes)
        panes.add(left, weight=3)
        panes.add(right, weight=2)

        ttk.Label(left, text="Human Summary", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.summary_text = tk.Text(left, wrap="word", height=20, undo=False)
        self.summary_text.pack(fill="both", expand=True, pady=(6, 0))

        ttk.Label(right, text="Recommended Next Edits", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.recommend_tree = ttk.Treeview(right, columns=("area", "action", "why"), show="headings", height=14)
        for col, width in [("area", 90), ("action", 180), ("why", 310)]:
            self.recommend_tree.heading(col, text=col.title())
            self.recommend_tree.column(col, width=width, anchor="w")
        self.recommend_tree.pack(fill="both", expand=True, pady=(6, 0))

    def _build_findings_tab(self):
        outer = ttk.Frame(self.tab_findings)
        outer.pack(fill="both", expand=True, padx=14, pady=14)
        filterbar = ttk.Frame(outer)
        filterbar.pack(fill="x")
        ttk.Label(filterbar, text="Filter:").pack(side="left")
        self.finding_filter_var = tk.StringVar()
        self.finding_filter_var.trace_add("write", lambda *_: self.populate_findings())
        ttk.Entry(filterbar, textvariable=self.finding_filter_var).pack(side="left", fill="x", expand=True, padx=8)

        self.findings_tree = ttk.Treeview(outer, columns=("type", "message"), show="headings")
        self.findings_tree.heading("type", text="Type")
        self.findings_tree.heading("message", text="Message")
        self.findings_tree.column("type", width=130, anchor="w")
        self.findings_tree.column("message", width=900, anchor="w")
        self.findings_tree.pack(fill="both", expand=True, pady=(8, 0))

    def _build_graph_tab(self):
        outer = ttk.Frame(self.tab_graph)
        outer.pack(fill="both", expand=True, padx=14, pady=14)
        panes = ttk.Panedwindow(outer, orient="horizontal")
        panes.pack(fill="both", expand=True)

        left = ttk.Frame(panes)
        right = ttk.Frame(panes)
        panes.add(left, weight=1)
        panes.add(right, weight=2)

        ttk.Label(left, text="Detected Agents / Tools / Modules", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.agent_tree = ttk.Treeview(left, columns=("name", "type", "source", "reason"), show="headings")
        for col, width in [("name", 160), ("type", 100), ("source", 210), ("reason", 240)]:
            self.agent_tree.heading(col, text=col.title())
            self.agent_tree.column(col, width=width, anchor="w")
        self.agent_tree.pack(fill="both", expand=True, pady=(6, 0))
        self.agent_tree.bind("<Double-1>", self.open_agent_source)

        ttk.Label(right, text="Module Graph / Inventory", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.graph_tree = ttk.Treeview(right, columns=("id", "type", "target"), show="headings")
        for col, width in [("id", 350), ("type", 110), ("target", 350)]:
            self.graph_tree.heading(col, text=col.title())
            self.graph_tree.column(col, width=width, anchor="w")
        self.graph_tree.pack(fill="both", expand=True, pady=(6, 0))

    def _build_editor_tab(self):
        outer = ttk.Frame(self.tab_editor)
        outer.pack(fill="both", expand=True, padx=14, pady=14)
        top = ttk.Frame(outer)
        top.pack(fill="x")
        ttk.Button(top, text="Open", command=self.open_text_asset).pack(side="left", padx=3)
        ttk.Button(top, text="Save With Backup", command=self.save_text_asset).pack(side="left", padx=3)
        ttk.Button(top, text="Validate", command=self.validate_text_asset).pack(side="left", padx=3)
        ttk.Button(top, text="Preview Diff", command=self.preview_diff).pack(side="left", padx=3)
        ttk.Button(top, text="JSON Patch", command=self.patch_json_dialog).pack(side="left", padx=3)
        ttk.Button(top, text="Agent Field", command=self.agent_field_dialog).pack(side="left", padx=3)
        ttk.Button(top, text="List Backups", command=self.show_backups).pack(side="left", padx=3)
        self.file_label = ttk.Label(top, text="No file open")
        self.file_label.pack(side="left", padx=12)

        body = ttk.Panedwindow(outer, orient="vertical")
        body.pack(fill="both", expand=True, pady=(8, 0))
        edit_frame = ttk.Frame(body)
        output_frame = ttk.Frame(body)
        body.add(edit_frame, weight=4)
        body.add(output_frame, weight=1)

        self.edit_text = tk.Text(edit_frame, wrap="none", undo=True, maxundo=500)
        ybar = ttk.Scrollbar(edit_frame, orient="vertical", command=self.edit_text.yview)
        xbar = ttk.Scrollbar(edit_frame, orient="horizontal", command=self.edit_text.xview)
        self.edit_text.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        self.edit_text.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        edit_frame.rowconfigure(0, weight=1)
        edit_frame.columnconfigure(0, weight=1)

        ttk.Label(output_frame, text="Validation / Diff Output").pack(anchor="w")
        self.editor_output = tk.Text(output_frame, wrap="none", height=8)
        self.editor_output.pack(fill="both", expand=True, pady=(4, 0))

    def _build_json_tab(self):
        outer = ttk.Frame(self.tab_json)
        outer.pack(fill="both", expand=True, padx=14, pady=14)
        top = ttk.Frame(outer)
        top.pack(fill="x")
        ttk.Button(top, text="Copy JSON", command=self.copy_json).pack(side="left", padx=3)
        ttk.Button(top, text="Save JSON", command=self.export_json).pack(side="left", padx=3)
        self.report_text = tk.Text(outer, wrap="none")
        self.report_text.pack(fill="both", expand=True, pady=(8, 0))

    def toggle_theme(self):
        self._theme.set("light" if self._theme.get() == "dark" else "dark")
        self._apply_theme()
        self.status_var.set(f"Theme switched to {self._theme.get()}.")

    def choose_file(self):
        path = filedialog.askopenfilename()
        if path:
            self.path_var.set(path)

    def choose_folder(self):
        path = filedialog.askdirectory()
        if path:
            self.path_var.set(path)

    def run_analysis(self):
        path = self.path_var.get().strip()
        if not path:
            messagebox.showwarning("Missing path", "Choose a file or folder first.")
            return
        try:
            self.status_var.set("Analyzing safely; target code is not executed.")
            self.update_idletasks()
            analyzer = AIAnalyzer(
                profile=self.profile_var.get(),
                include_hashes=self.hashes_var.get(),
                include_text_samples=self.samples_var.get(),
                secret_scan=self.secrets_var.get(),
                include_prompt_inventory=self.prompts_var.get(),
            )
            report = analyzer.analyze(path)
            self.last_report = report
            self.refresh_report_views()
            self.notebook.select(self.tab_dashboard)
            self.status_var.set("Analysis complete.")
        except Exception as exc:
            self.status_var.set("Analysis failed.")
            messagebox.showerror("Analysis failed", f"{type(exc).__name__}: {exc}")

    def refresh_report_views(self):
        report = self.last_report or {}
        risk = report.get("risk", {})
        self.card_vars["risk"].set(f"{risk.get('level', '—').upper()} {risk.get('score', '—')}/100")
        self.card_vars["files"].set(str(report.get("total_files", 1)))
        self.card_vars["agents"].set(str(len(report.get("agents", []))))
        self.card_vars["models"].set(str(len(report.get("model_artifacts", []))))
        self.card_vars["framework"].set(str(report.get("framework_guess", "—"))[:34])

        self.summary_text.delete("1.0", "end")
        self.summary_text.insert("1.0", human_summary(report))

        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", to_pretty_json(report))

        for tree in (self.recommend_tree, self.findings_tree, self.agent_tree, self.graph_tree):
            for item in tree.get_children():
                tree.delete(item)

        for rec in report.get("edit_recommendations", []):
            self.recommend_tree.insert("", "end", values=(rec.get("area"), rec.get("action"), rec.get("why")))

        self.populate_findings()
        self.populate_agents_and_graph()

    def populate_findings(self):
        for item in self.findings_tree.get_children():
            self.findings_tree.delete(item)
        report = self.last_report or {}
        needle = self.finding_filter_var.get().lower().strip()
        rows = []
        for item in report.get("findings", []):
            rows.append(("Finding", item))
        for item in report.get("safety_notes", []):
            rows.append(("Safety", item))
        for r in report.get("risk", {}).get("reasons", []):
            rows.append(("Risk", r))
        for area in ("metadata", "capabilities"):
            val = report.get(area)
            if val:
                rows.append((area.title(), json.dumps(val, ensure_ascii=False)[:600]))
        for typ, msg in rows:
            if not needle or needle in typ.lower() or needle in msg.lower():
                self.findings_tree.insert("", "end", values=(typ, msg))

    def populate_agents_and_graph(self):
        report = self.last_report or {}
        for a in report.get("agents", []):
            self.agent_tree.insert("", "end", values=(a.get("name"), a.get("type"), a.get("source"), a.get("reason")))

        graph = report.get("module_graph", {})
        for n in graph.get("nodes", [])[:1000]:
            self.graph_tree.insert("", "end", values=(n.get("id"), n.get("type"), ""))
        for e in graph.get("edges", [])[:2000]:
            self.graph_tree.insert("", "end", values=(e.get("from"), e.get("type"), e.get("to")))

    def open_agent_source(self, event=None):
        sel = self.agent_tree.selection()
        if not sel or not self.last_report:
            return
        values = self.agent_tree.item(sel[0], "values")
        if len(values) < 3:
            return
        source = values[2]
        root = Path(self.last_report.get("target", {}).get("path", ""))
        p = root / source if root.is_dir() else root.parent / source
        if p.exists() and p.is_file() and p.suffix.lower() in {".py", ".json", ".md", ".txt", ".yaml", ".yml", ".toml", ".prompt"}:
            self.open_file_path(p)

    def open_text_asset(self):
        path = filedialog.askopenfilename(filetypes=[
            ("AI text assets", "*.py *.json *.md *.txt *.yaml *.yml *.toml *.ini *.cfg *.prompt *.jinja *.j2 *.rst *.csv"),
            ("All files", "*.*"),
        ])
        if path:
            self.open_file_path(Path(path))

    def open_file_path(self, path: Path):
        try:
            text = self.editor.read_text(path)
            self.current_file = path
            self.edit_text.delete("1.0", "end")
            self.edit_text.insert("1.0", text)
            self.file_label.configure(text=str(path))
            self.editor_output.delete("1.0", "end")
            self.editor_output.insert("1.0", f"Opened {path}\n")
            self.notebook.select(self.tab_editor)
        except Exception as exc:
            messagebox.showerror("Open failed", f"{type(exc).__name__}: {exc}")

    def save_text_asset(self):
        if not self.current_file:
            messagebox.showwarning("No file", "Open a text asset first.")
            return
        try:
            content = self.edit_text.get("1.0", "end-1c")
            result = self.editor.save_text(self.current_file, content, validate=True, backup=True)
            self.editor_output.delete("1.0", "end")
            self.editor_output.insert("1.0", json.dumps(result, indent=2))
            self.status_var.set("Saved with backup.")
        except Exception as exc:
            messagebox.showerror("Save failed", f"{type(exc).__name__}: {exc}")

    def validate_text_asset(self):
        if not self.current_file:
            messagebox.showwarning("No file", "Open a text asset first.")
            return
        try:
            content = self.edit_text.get("1.0", "end-1c")
            result = self.editor.validate_content(self.current_file, content)
            self.editor_output.delete("1.0", "end")
            self.editor_output.insert("1.0", json.dumps(result, indent=2))
        except Exception as exc:
            self.editor_output.delete("1.0", "end")
            self.editor_output.insert("1.0", f"{type(exc).__name__}: {exc}")
            messagebox.showerror("Validation failed", f"{type(exc).__name__}: {exc}")

    def preview_diff(self):
        if not self.current_file:
            messagebox.showwarning("No file", "Open a text asset first.")
            return
        content = self.edit_text.get("1.0", "end-1c")
        try:
            diff = self.editor.diff_text(self.current_file, content)
            self.editor_output.delete("1.0", "end")
            self.editor_output.insert("1.0", diff or "No changes.")
        except Exception as exc:
            messagebox.showerror("Diff failed", f"{type(exc).__name__}: {exc}")

    def patch_json_dialog(self):
        if not self.current_file:
            messagebox.showwarning("No file", "Open a JSON file first.")
            return
        if self.current_file.suffix.lower() != ".json":
            messagebox.showwarning("Not JSON", "JSON patch is for .json files only.")
            return
        key = simpledialog.askstring("Patch JSON", "Dotted key, e.g. generation.temperature or agents[0].name")
        if not key:
            return
        value_text = simpledialog.askstring("Patch JSON", "New value as JSON or plain text")
        if value_text is None:
            return
        try:
            value = json.loads(value_text)
        except json.JSONDecodeError:
            value = value_text
        try:
            self.editor.patch_json_key(self.current_file, key, value)
            self.open_file_path(self.current_file)
            self.editor_output.insert("end", f"\nPatched {key}\n")
        except Exception as exc:
            messagebox.showerror("Patch failed", f"{type(exc).__name__}: {exc}")

    def agent_field_dialog(self):
        if not self.current_file:
            messagebox.showwarning("No file", "Open or create an agent manifest first.")
            return
        if self.current_file.suffix.lower() != ".json":
            messagebox.showwarning("Not JSON", "Agent manifests are JSON files.")
            return
        field = simpledialog.askstring("Update Agent Field", "Field: " + ", ".join(AGENT_SCHEMA_KEYS.keys()))
        if not field:
            return
        if field not in AGENT_SCHEMA_KEYS:
            messagebox.showwarning("Unknown field", f"Valid fields: {', '.join(AGENT_SCHEMA_KEYS.keys())}")
            return
        value_text = simpledialog.askstring("Update Agent Field", "New value as JSON or plain text")
        if value_text is None:
            return
        try:
            value = json.loads(value_text)
        except json.JSONDecodeError:
            value = value_text
        try:
            self.editor.update_agent_manifest(self.current_file, field, value)
            self.open_file_path(self.current_file)
            self.editor_output.insert("end", f"\nUpdated agent field {field}\n")
        except Exception as exc:
            messagebox.showerror("Agent update failed", f"{type(exc).__name__}: {exc}")

    def show_backups(self):
        if not self.current_file:
            messagebox.showwarning("No file", "Open a text asset first.")
            return
        rows = self.editor.list_backups(self.current_file)
        self.editor_output.delete("1.0", "end")
        self.editor_output.insert("1.0", json.dumps(rows, indent=2))

    def new_agent_manifest(self):
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON Agent Manifest", "*.json")])
        if not path:
            return
        name = simpledialog.askstring("Agent Name", "Agent name", initialvalue=Path(path).stem) or Path(path).stem
        desc = simpledialog.askstring("Description", "What does this agent do?", initialvalue="") or ""
        try:
            self.editor.create_agent_manifest_file(path, name, desc)
            self.open_file_path(Path(path))
        except Exception as exc:
            messagebox.showerror("Create agent failed", f"{type(exc).__name__}: {exc}")

    def export_json(self):
        if not self.last_report:
            messagebox.showwarning("No report", "Run analysis first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON report", "*.json")])
        if path:
            save_report(self.last_report, path, fmt="json")
            self.status_var.set(f"Saved JSON report: {path}")

    def export_markdown(self):
        if not self.last_report:
            messagebox.showwarning("No report", "Run analysis first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".md", filetypes=[("Markdown report", "*.md")])
        if path:
            save_report(self.last_report, path, fmt="md")
            self.status_var.set(f"Saved Markdown report: {path}")

    def copy_json(self):
        text = self.report_text.get("1.0", "end-1c")
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status_var.set("Copied JSON to clipboard.")


def main():
    app = AIInspectorEditorApp()
    app.mainloop()


if __name__ == "__main__":
    main()
