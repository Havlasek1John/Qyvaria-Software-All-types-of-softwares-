from __future__ import annotations

import configparser
import hashlib
import json
import os
import re
import struct
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .module_graph import build_graph, parse_python_module
from .profiles import ScanProfile, get_profile


MODEL_EXTENSIONS = {".safetensors", ".bin", ".pt", ".pth", ".ckpt", ".onnx", ".gguf", ".ggml", ".tflite", ".pb", ".h5", ".keras"}
TEXT_EXTENSIONS = {".json", ".md", ".txt", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".py", ".prompt", ".jinja", ".j2", ".rst", ".csv"}
PROMPT_EXTENSIONS = {".prompt", ".txt", ".md", ".jinja", ".j2", ".yaml", ".yml", ".json"}
SKIP_DIRS = {".git", ".hg", ".svn", "__pycache__", ".venv", "venv", "env", "node_modules", "dist", "build", ".mypy_cache", ".pytest_cache"}
SECRET_PATTERNS = [
    ("Generic credential assignment", re.compile(r"(?i)(api[_-]?key|secret|token|password|client[_-]?secret)\s*[:=]\s*['\"]?([A-Za-z0-9_\-./+=]{16,})")),
    ("OpenAI-style key", re.compile(r"sk-[A-Za-z0-9_\-]{20,}")),
    ("AWS access key", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("Private key block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |)PRIVATE KEY-----")),
]
DATASET_RE = re.compile(r"(?im)^\s*(datasets?|training data|data)\s*[:\-]\s*(.+)$")
LICENSE_RE = re.compile(r"(?im)^\s*license\s*[:\-]\s*(.+)$")
TASK_RE = re.compile(r"(?im)^\s*(tasks?|pipeline_tag|tags?)\s*[:\-]\s*(.+)$")
PROMPT_HINT_RE = re.compile(r"(?i)(system prompt|developer prompt|instruction|role\s*:\s*system|you are an ai|assistant|agent)")


class AIAnalyzer:
    """Safe static analyzer for AI software, models, agents, and module projects.

    The analyzer never imports or executes analyzed code. It only parses text,
    reads metadata, fingerprints binary artifacts, and creates a report.
    """

    def __init__(
        self,
        profile: str | ScanProfile = "standard",
        max_files: int | None = None,
        max_text_bytes: int | None = None,
        max_hash_bytes: int | None = None,
        include_hashes: bool | None = None,
        include_text_samples: bool | None = None,
        include_dependency_inventory: bool | None = None,
        include_ast_metrics: bool | None = None,
        include_prompt_inventory: bool | None = None,
        include_binary_fingerprints: bool | None = None,
        secret_scan: bool | None = None,
    ):
        base = profile if isinstance(profile, ScanProfile) else get_profile(profile)
        self.profile = base
        self.max_files = max_files if max_files is not None else base.max_files
        self.max_text_bytes = max_text_bytes if max_text_bytes is not None else base.max_text_bytes
        self.max_hash_bytes = max_hash_bytes if max_hash_bytes is not None else base.max_hash_bytes
        self.include_hashes = include_hashes if include_hashes is not None else base.include_hashes
        self.include_text_samples = include_text_samples if include_text_samples is not None else base.include_text_samples
        self.include_dependency_inventory = include_dependency_inventory if include_dependency_inventory is not None else base.include_dependency_inventory
        self.include_ast_metrics = include_ast_metrics if include_ast_metrics is not None else base.include_ast_metrics
        self.include_prompt_inventory = include_prompt_inventory if include_prompt_inventory is not None else base.include_prompt_inventory
        self.include_binary_fingerprints = include_binary_fingerprints if include_binary_fingerprints is not None else base.include_binary_fingerprints
        self.secret_scan = secret_scan if secret_scan is not None else base.secret_scan

    def analyze(self, target: str | Path) -> Dict[str, Any]:
        root = Path(target).expanduser().resolve()
        if not root.exists():
            raise FileNotFoundError(str(root))

        started = time.time()
        if root.is_file():
            report = self._analyze_file(root)
        else:
            report = self._analyze_directory(root)

        report["analysis"] = {
            "created_unix": int(time.time()),
            "duration_seconds": round(time.time() - started, 3),
            "profile": self.profile.to_dict(),
            "effective_options": {
                "max_files": self.max_files,
                "max_text_bytes": self.max_text_bytes,
                "max_hash_bytes": self.max_hash_bytes,
                "include_hashes": self.include_hashes,
                "include_text_samples": self.include_text_samples,
                "include_dependency_inventory": self.include_dependency_inventory,
                "include_ast_metrics": self.include_ast_metrics,
                "include_prompt_inventory": self.include_prompt_inventory,
                "include_binary_fingerprints": self.include_binary_fingerprints,
                "secret_scan": self.secret_scan,
            },
            "execution_policy": "Target code is parsed or fingerprinted only; it is not imported, deserialized, or executed.",
            "safe_mode": True,
        }
        return report

    def _analyze_file(self, path: Path) -> Dict[str, Any]:
        suffix = path.suffix.lower()
        stat = path.stat()
        base = {
            "target": {"path": str(path), "kind": "file", "name": path.name, "extension": suffix or "<none>", "size_bytes": stat.st_size},
            "framework_guess": _artifact_framework_guess(path),
            "findings": [],
            "safety_notes": [],
            "risk": {},
            "edit_recommendations": [],
        }
        if suffix in MODEL_EXTENSIONS:
            artifact = self._model_artifact(path, path.parent)
            base["model_artifacts"] = [artifact]
            base["findings"].append(f"Detected model artifact: {path.name} ({artifact.get('framework_hint')})")
        elif suffix == ".py":
            mod = parse_python_module(path, path.parent, include_metrics=self.include_ast_metrics)
            base["modules"] = [mod]
            base["module_graph"] = build_graph([mod])
            base["framework_guess"] = _guess_from_modules([mod]) or "Python AI/software module"
        elif suffix in TEXT_EXTENSIONS:
            text = self._read_text(path)
            base["text_asset"] = self._summarize_text_asset(path, text)
            if self.secret_scan:
                secrets = self._secret_hits(text)
                if secrets:
                    base["safety_notes"].extend(f"{path.name}: possible {hit['type']}" for hit in secrets[:8])
        base["risk"] = self._score_risk(base)
        base["edit_recommendations"] = self._recommend_edits(base)
        return base

    def _analyze_directory(self, root: Path) -> Dict[str, Any]:
        files = list(self._walk_files(root))
        truncated = len(files) > self.max_files
        files = files[: self.max_files]

        ext_counts: Dict[str, int] = {}
        total_bytes = 0
        py_modules: List[Dict[str, Any]] = []
        model_artifacts: List[Dict[str, Any]] = []
        metadata: Dict[str, Any] = {}
        findings: List[str] = []
        safety_notes: List[str] = []
        agents: List[Dict[str, str]] = []
        prompts: List[Dict[str, Any]] = []
        configs: List[Dict[str, Any]] = []
        dependencies: Dict[str, Any] = {"files": [], "packages": {}, "frameworks": []}
        file_inventory: List[Dict[str, Any]] = []
        text_bytes_read = 0

        for path in files:
            rel = _safe_rel(path, root)
            suffix = path.suffix.lower()
            try:
                size = path.stat().st_size
            except OSError:
                continue
            total_bytes += size
            ext_counts[suffix or "<none>"] = ext_counts.get(suffix or "<none>", 0) + 1
            inv_item = {"path": rel, "extension": suffix or "<none>", "size_bytes": size}
            if self.include_hashes and size <= self.max_hash_bytes:
                inv_item["sha256"] = self._sha256(path)
            file_inventory.append(inv_item)

            low_name = path.name.lower()

            if low_name in {"config.json", "generation_config.json", "adapter_config.json"}:
                cfg = self._read_json(path)
                if isinstance(cfg, dict):
                    summary = self._summarize_config(cfg, rel)
                    configs.append(summary)
                    metadata.setdefault("configs", []).append(summary)
                    pe = self._estimate_transformer_params(cfg)
                    if pe and "parameter_estimate" not in metadata:
                        metadata["parameter_estimate"] = pe
                    agent_cfgs = self._agents_from_config(cfg, rel)
                    agents.extend(agent_cfgs)
            elif low_name in {"tokenizer.json", "tokenizer_config.json", "special_tokens_map.json"}:
                tok = self._read_json(path)
                if tok:
                    metadata.setdefault("tokenizers", []).append(self._summarize_tokenizer(path.name, tok, rel))
            elif low_name in {"readme.md", "modelcard.md", "model_card.md"}:
                card = self._read_text(path)
                text_bytes_read += len(card.encode("utf-8", errors="ignore"))
                metadata["model_card"] = self._summarize_model_card(card)
                if not metadata["model_card"].get("license"):
                    safety_notes.append(f"{rel}: model card found but no clear license line detected")
            elif suffix == ".py":
                mod = parse_python_module(path, root, include_metrics=self.include_ast_metrics)
                py_modules.append(mod)
                for hint in mod.get("agent_hints", []):
                    agents.append({"name": hint.get("name", "<unknown>"), "source": rel, "type": hint.get("type", "code"), "reason": hint.get("reason", "")})
                if mod.get("suspicious_calls"):
                    safety_notes.append(f"{rel}: risky calls detected: {', '.join(mod['suspicious_calls'][:10])}")
                for fw in mod.get("framework_hints", []):
                    if fw not in dependencies["frameworks"]:
                        dependencies["frameworks"].append(fw)
                if self.secret_scan and size <= self.max_text_bytes:
                    text = self._read_text(path)
                    text_bytes_read += len(text.encode("utf-8", errors="ignore"))
                    for hit in self._secret_hits(text)[:8]:
                        safety_notes.append(f"{rel}: possible {hit['type']} near line {hit['line']}")
            elif suffix in MODEL_EXTENSIONS:
                model_artifacts.append(self._model_artifact(path, root))
            elif self.include_dependency_inventory and low_name in {"requirements.txt", "pyproject.toml", "environment.yml", "environment.yaml", "conda.yml", "package.json", "setup.py"}:
                dep = self._dependency_file(path, root)
                dependencies["files"].append(dep)
                for pkg, spec in dep.get("packages", {}).items():
                    dependencies["packages"].setdefault(pkg, []).append({"source": rel, "spec": spec})
            elif suffix in TEXT_EXTENSIONS:
                if self.secret_scan and size <= self.max_text_bytes:
                    text = self._read_text(path)
                    text_bytes_read += len(text.encode("utf-8", errors="ignore"))
                    for hit in self._secret_hits(text)[:5]:
                        safety_notes.append(f"{rel}: possible {hit['type']} near line {hit['line']}")
                if self.include_prompt_inventory and self._looks_like_prompt_file(path):
                    text = self._read_text(path)
                    prompts.append(self._summarize_prompt(path, root, text))
                if any(key in low_name for key in ("agent", "module", "tool", "workflow", "crew")) and suffix in {".json", ".yaml", ".yml", ".toml", ".md", ".txt"}:
                    agents.append({"name": path.stem, "source": rel, "type": "manifest/file", "reason": "agent-like filename"})

        if truncated:
            findings.append(f"Scan reached max_files={self.max_files}; some files were not scanned.")
        if model_artifacts:
            findings.append(f"Detected {len(model_artifacts)} model/checkpoint artifact(s).")
        if py_modules:
            findings.append(f"Parsed {len(py_modules)} Python module(s) without executing them.")
        if agents:
            findings.append(f"Detected {len(_unique_agents(agents))} possible agent/module/tool component(s).")
        if prompts:
            findings.append(f"Indexed {len(prompts)} prompt/instruction asset(s).")
        if dependencies.get("frameworks"):
            findings.append("Framework/import hints: " + ", ".join(sorted(dependencies["frameworks"])[:12]))
        if not any(path.name.lower() in {"readme.md", "modelcard.md", "model_card.md"} for path in files):
            safety_notes.append("No README/model card detected; provenance, task, license, and usage constraints may be unclear.")
        if not any(path.name.lower().startswith("license") for path in files):
            safety_notes.append("No LICENSE file detected.")

        framework_guess = self._guess_framework(files, py_modules, model_artifacts, dependencies)

        report: Dict[str, Any] = {
            "target": {"path": str(root), "kind": "directory", "name": root.name},
            "total_files": len(files),
            "truncated": truncated,
            "total_size_bytes": total_bytes,
            "extensions": dict(sorted(ext_counts.items(), key=lambda kv: (-kv[1], kv[0]))),
            "framework_guess": framework_guess,
            "metadata": metadata,
            "configs": configs,
            "model_artifacts": model_artifacts,
            "modules": py_modules,
            "module_graph": build_graph(py_modules, max_edges=6000),
            "agents": _unique_agents(agents),
            "prompts": prompts,
            "dependencies": dependencies if self.include_dependency_inventory else {},
            "inventory": file_inventory,
            "findings": _unique(findings),
            "safety_notes": _unique(safety_notes),
            "capabilities": self._capability_map(py_modules, model_artifacts, prompts, dependencies),
            "text_bytes_read": text_bytes_read,
        }
        report["risk"] = self._score_risk(report)
        report["edit_recommendations"] = self._recommend_edits(report)
        return report

    def _walk_files(self, root: Path) -> Iterable[Path]:
        count = 0
        for cur, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".cache")]
            for name in sorted(files):
                if count >= self.max_files * 2:
                    return
                path = Path(cur) / name
                try:
                    if path.is_file():
                        count += 1
                        yield path
                except OSError:
                    continue

    def _read_text(self, path: Path) -> str:
        try:
            data = path.read_bytes()
        except OSError:
            return ""
        if len(data) > self.max_text_bytes:
            data = data[: self.max_text_bytes]
        return data.decode("utf-8", errors="replace")

    def _read_json(self, path: Path) -> Any:
        try:
            return json.loads(self._read_text(path))
        except Exception:
            return None

    def _model_artifact(self, path: Path, root: Path) -> Dict[str, Any]:
        stat = path.stat()
        suffix = path.suffix.lower()
        info: Dict[str, Any] = {
            "path": _safe_rel(path, root),
            "name": path.name,
            "extension": suffix,
            "size_bytes": stat.st_size,
            "size_human": _human_bytes(stat.st_size),
            "framework_hint": _artifact_framework_guess(path),
            "safety": "Fingerprint only; artifact was not deserialized or loaded.",
        }
        if self.include_hashes and stat.st_size <= self.max_hash_bytes:
            info["sha256"] = self._sha256(path)
        if self.include_binary_fingerprints:
            if suffix == ".safetensors":
                info.update(self._safetensors_header(path))
            elif suffix == ".onnx":
                info.update(self._onnx_light_metadata(path))
            elif suffix == ".gguf":
                info.update(self._gguf_light_metadata(path))
        return info

    def _safetensors_header(self, path: Path) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        try:
            with path.open("rb") as f:
                raw = f.read(8)
                if len(raw) != 8:
                    return {"header_error": "too small for safetensors header"}
                (header_len,) = struct.unpack("<Q", raw)
                if header_len > 50_000_000:
                    return {"header_error": f"header too large: {header_len}"}
                header = f.read(header_len)
            data = json.loads(header.decode("utf-8"))
            tensors = {k: v for k, v in data.items() if k != "__metadata__" and isinstance(v, dict)}
            dtypes: Dict[str, int] = {}
            shape_examples = []
            total_elements = 0
            for name, meta in list(tensors.items())[:50000]:
                dtype = str(meta.get("dtype", "unknown"))
                dtypes[dtype] = dtypes.get(dtype, 0) + 1
                shape = meta.get("shape")
                if isinstance(shape, list):
                    elems = 1
                    for dim in shape:
                        if isinstance(dim, int) and dim >= 0:
                            elems *= dim
                    total_elements += elems
                    if len(shape_examples) < 10:
                        shape_examples.append({"name": name, "dtype": dtype, "shape": shape})
            out.update({
                "safetensors": {
                    "tensor_count": len(tensors),
                    "metadata": data.get("__metadata__", {}),
                    "dtypes": dtypes,
                    "shape_examples": shape_examples,
                    "total_elements_estimate": total_elements,
                    "parameters_human": _human_count(total_elements) if total_elements else None,
                }
            })
        except Exception as exc:
            out["header_error"] = f"safetensors header read failed: {type(exc).__name__}: {exc}"
        return out

    def _onnx_light_metadata(self, path: Path) -> Dict[str, Any]:
        try:
            data = path.read_bytes()[:2_000_000]
            strings = sorted(set(s.decode("utf-8", errors="ignore") for s in re.findall(rb"[A-Za-z_][A-Za-z0-9_./:-]{3,80}", data)))
            likely_ops = [s for s in strings if s in {"Conv", "Gemm", "MatMul", "Attention", "LayerNormalization", "Relu", "Gelu", "Softmax", "Add", "Mul"}]
            return {"onnx_light": {"strings_sample": strings[:80], "possible_ops": likely_ops[:40], "note": "Lightweight scan only; install optional onnx for full graph parsing."}}
        except Exception as exc:
            return {"onnx_light_error": str(exc)}

    def _gguf_light_metadata(self, path: Path) -> Dict[str, Any]:
        try:
            with path.open("rb") as f:
                magic = f.read(4)
                version = struct.unpack("<I", f.read(4))[0] if magic == b"GGUF" else None
            return {"gguf_light": {"magic": magic.decode("latin1", errors="replace"), "version": version}}
        except Exception as exc:
            return {"gguf_light_error": str(exc)}

    def _summarize_config(self, cfg: Dict[str, Any], source: str = "config.json") -> Dict[str, Any]:
        keys = [
            "model_type", "architectures", "hidden_size", "num_hidden_layers",
            "num_attention_heads", "intermediate_size", "vocab_size",
            "max_position_embeddings", "torch_dtype", "quantization_config",
            "task_specific_params", "bos_token_id", "eos_token_id",
        ]
        return {"source": source, "selected": {k: cfg.get(k) for k in keys if k in cfg}, "key_count": len(cfg)}

    def _estimate_transformer_params(self, cfg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        hidden = _first_int(cfg, ["hidden_size", "n_embd", "d_model"])
        layers = _first_int(cfg, ["num_hidden_layers", "n_layer", "num_layers"])
        vocab = _first_int(cfg, ["vocab_size", "n_vocab"])
        intermediate = _first_int(cfg, ["intermediate_size", "n_inner", "ffn_dim"]) or (4 * hidden if hidden else None)
        if not (hidden and layers and vocab and intermediate):
            return None
        # Coarse decoder/encoder transformer estimate. Good for sizing only, not exact accounting.
        embedding = vocab * hidden
        per_layer = (4 * hidden * hidden) + (2 * hidden * intermediate)
        total = embedding + layers * per_layer
        return {
            "params": int(total),
            "params_human": _human_count(total),
            "method": "coarse transformer estimate from config; excludes some heads/adapters/tied embeddings",
            "inputs": {"hidden": hidden, "layers": layers, "vocab": vocab, "intermediate": intermediate},
        }

    def _summarize_tokenizer(self, name: str, tok: Any, source: str) -> Dict[str, Any]:
        summary: Dict[str, Any] = {"name": name, "source": source}
        if isinstance(tok, dict):
            model = tok.get("model") if isinstance(tok.get("model"), dict) else {}
            vocab = model.get("vocab") if isinstance(model, dict) else None
            summary.update({
                "type": model.get("type") if isinstance(model, dict) else tok.get("tokenizer_class"),
                "vocab_size": len(vocab) if isinstance(vocab, dict) else tok.get("vocab_size"),
                "special_tokens": list((tok.get("added_tokens") or [])[:10]) if isinstance(tok.get("added_tokens"), list) else None,
            })
        return summary

    def _summarize_model_card(self, text: str) -> Dict[str, Any]:
        return {
            "present": bool(text),
            "license": _first_match(LICENSE_RE, text),
            "datasets": _first_match(DATASET_RE, text),
            "tasks": _first_match(TASK_RE, text),
            "length_chars": len(text),
            "mentions_safety": bool(re.search(r"(?i)safety|bias|limitations|risks|intended use|misuse", text or "")),
        }

    def _summarize_prompt(self, path: Path, root: Path, text: str) -> Dict[str, Any]:
        sample = _redact(text[:1000]) if self.include_text_samples else None
        return {
            "path": _safe_rel(path, root),
            "name": path.name,
            "size_bytes": path.stat().st_size,
            "prompt_like": bool(PROMPT_HINT_RE.search(text)),
            "roles": sorted(set(re.findall(r"(?im)^\s*(system|developer|user|assistant|tool)\s*:", text))),
            "sample": sample,
        }

    def _summarize_text_asset(self, path: Path, text: str) -> Dict[str, Any]:
        return {
            "path": str(path),
            "size_bytes": path.stat().st_size,
            "extension": path.suffix.lower(),
            "prompt_like": bool(PROMPT_HINT_RE.search(text)),
            "secret_hits": self._secret_hits(text)[:10] if self.secret_scan else [],
            "sample": _redact(text[:1200]) if self.include_text_samples else None,
        }

    def _agents_from_config(self, cfg: Dict[str, Any], source: str) -> List[Dict[str, str]]:
        out: List[Dict[str, str]] = []
        def visit(obj: Any, prefix: str = "") -> None:
            if isinstance(obj, dict):
                for key, value in obj.items():
                    lower = str(key).lower()
                    path = f"{prefix}.{key}" if prefix else str(key)
                    if any(k in lower for k in ("agent", "tool", "planner", "memory", "orchestrator", "chain")):
                        out.append({"name": str(key), "source": source, "type": "config", "reason": f"key path {path}"})
                    visit(value, path)
            elif isinstance(obj, list):
                for idx, value in enumerate(obj[:50]):
                    visit(value, f"{prefix}[{idx}]")
        visit(cfg)
        return out

    def _looks_like_prompt_file(self, path: Path) -> bool:
        name = path.name.lower()
        return path.suffix.lower() in PROMPT_EXTENSIONS and any(k in name for k in ("prompt", "system", "instruction", "agent", "role", "template", "chain"))

    def _dependency_file(self, path: Path, root: Path) -> Dict[str, Any]:
        rel = _safe_rel(path, root)
        text = self._read_text(path)
        packages: Dict[str, str] = {}
        low = path.name.lower()
        if low == "requirements.txt":
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                name = re.split(r"[<>=!~;\[]", line, maxsplit=1)[0].strip()
                if name:
                    packages[name] = line
        elif low == "pyproject.toml":
            for match in re.finditer(r'["\']([A-Za-z0-9_.-]+(?:\[[^\]]+\])?(?:[<>=!~]=?.*)?)["\']', text):
                spec = match.group(1)
                name = re.split(r"[<>=!~;\[]", spec, maxsplit=1)[0].strip()
                if name and len(name) > 1:
                    packages.setdefault(name, spec)
        elif low in {"environment.yml", "environment.yaml", "conda.yml"}:
            for line in text.splitlines():
                line = line.strip()
                if line.startswith("- "):
                    spec = line[2:].strip()
                    name = re.split(r"[<>=!~;\[]", spec, maxsplit=1)[0].strip()
                    if name and name not in {"pip"}:
                        packages[name] = spec
        elif low == "package.json":
            data = self._read_json(path)
            if isinstance(data, dict):
                for section in ("dependencies", "devDependencies", "peerDependencies"):
                    for name, spec in (data.get(section) or {}).items():
                        packages[name] = str(spec)
        return {"path": rel, "packages": packages, "package_count": len(packages)}

    def _secret_hits(self, text: str) -> List[Dict[str, Any]]:
        hits = []
        if not text:
            return hits
        for label, pattern in SECRET_PATTERNS:
            for match in pattern.finditer(text):
                line = text.count("\n", 0, match.start()) + 1
                snippet = _redact(match.group(0))[:160]
                hits.append({"type": label, "line": line, "snippet": snippet})
        return hits

    def _sha256(self, path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def _guess_framework(self, files: List[Path], modules: List[Dict[str, Any]], artifacts: List[Dict[str, Any]], deps: Dict[str, Any]) -> str:
        suffixes = {p.suffix.lower() for p in files}
        names = {p.name.lower() for p in files}
        frameworks = sorted(set(deps.get("frameworks") or []))
        if frameworks:
            return " / ".join(frameworks[:4])
        module_guess = _guess_from_modules(modules)
        if module_guess:
            return module_guess
        if "config.json" in names and any(s in suffixes for s in {".safetensors", ".bin"}):
            return "Hugging Face/Transformers-style model"
        if ".gguf" in suffixes or ".ggml" in suffixes:
            return "GGUF/GGML local LLM artifact"
        if ".onnx" in suffixes:
            return "ONNX model artifact/project"
        if ".tflite" in suffixes or ".pb" in suffixes:
            return "TensorFlow/TFLite model artifact/project"
        if any("agent" in p.name.lower() or "workflow" in p.name.lower() for p in files):
            return "Agentic AI software project"
        return artifacts[0]["framework_hint"] if artifacts else "Unknown/custom AI software"

    def _capability_map(self, modules: List[Dict[str, Any]], artifacts: List[Dict[str, Any]], prompts: List[Dict[str, Any]], deps: Dict[str, Any]) -> Dict[str, Any]:
        frameworks = set(deps.get("frameworks") or [])
        imports = {imp for m in modules for imp in m.get("imports", [])}
        return {
            "training_or_finetuning": any(x in frameworks for x in {"PyTorch", "TensorFlow", "Keras", "Transformers", "PEFT/LoRA", "Accelerate"}),
            "inference_serving": any(x in frameworks for x in {"vLLM", "ONNX Runtime", "llama.cpp", "Transformers"}) or bool(artifacts),
            "agent_orchestration": any(x in frameworks for x in {"LangChain", "LangGraph", "CrewAI", "AutoGen"}) or any(m.get("agent_hints") for m in modules),
            "vector_search": any(x in frameworks for x in {"ChromaDB", "FAISS", "Pinecone", "Weaviate", "Qdrant"}) or any("faiss" in i or "chromadb" in i for i in imports),
            "prompt_driven": bool(prompts),
            "binary_model_assets": len(artifacts),
        }

    def _score_risk(self, report: Dict[str, Any]) -> Dict[str, Any]:
        notes = report.get("safety_notes", [])
        artifacts = report.get("model_artifacts", [])
        modules = report.get("modules", [])
        score = 0
        reasons: List[str] = []

        for note in notes:
            low = note.lower()
            if "secret" in low or "key" in low or "token" in low:
                score += 25; reasons.append("Possible embedded secret")
            elif "risky call" in low or "suspicious" in low:
                score += 18; reasons.append("Risky code call")
            elif "no license" in low:
                score += 8; reasons.append("License missing")
            elif "no readme" in low or "model card" in low:
                score += 6; reasons.append("Documentation/model card issue")
        if any(a.get("extension") in {".pt", ".pth", ".ckpt", ".bin"} for a in artifacts):
            score += 14; reasons.append("Pickle-capable or opaque binary weights")
        if any(m.get("syntax_error") for m in modules):
            score += 6; reasons.append("Python syntax/read errors")
        if not report.get("metadata", {}).get("model_card") and report.get("target", {}).get("kind") == "directory":
            score += 5; reasons.append("No model card metadata")
        score = min(score, 100)
        level = "low"
        if score >= 70:
            level = "high"
        elif score >= 35:
            level = "medium"
        elif score >= 12:
            level = "watch"
        return {"score": score, "level": level, "reasons": _unique(reasons), "note": "Static heuristic risk score. Review manually before deployment."}

    def _recommend_edits(self, report: Dict[str, Any]) -> List[Dict[str, str]]:
        recs: List[Dict[str, str]] = []
        if any("No README" in n for n in report.get("safety_notes", [])):
            recs.append({"area": "documentation", "action": "Create README/model card", "why": "Add task, intended use, limits, license, training data, and safety notes."})
        if any("No LICENSE" in n for n in report.get("safety_notes", [])):
            recs.append({"area": "legal", "action": "Add LICENSE or usage policy", "why": "Clarifies whether the AI software can be used, modified, or shipped."})
        if any("secret" in n.lower() or "token" in n.lower() for n in report.get("safety_notes", [])):
            recs.append({"area": "security", "action": "Move secrets to environment variables", "why": "Avoid shipping API keys or credentials inside AI modules/configs."})
        if report.get("agents"):
            recs.append({"area": "agents", "action": "Review agent manifests and tool permissions", "why": "Agent tools, memory, and external actions should have explicit permissions."})
        if report.get("model_artifacts"):
            recs.append({"area": "models", "action": "Record model provenance and checksum", "why": "Track exact artifacts before editing adapters, configs, or deployment modules."})
        if not recs:
            recs.append({"area": "general", "action": "Use the editor to tune text configs/prompts only", "why": "Raw weights are intentionally protected from direct edits."})
        return recs


def _artifact_framework_guess(path: Path) -> str:
    return {
        ".safetensors": "safetensors model weights",
        ".bin": "binary model weights; often PyTorch/Hugging Face",
        ".pt": "PyTorch serialized artifact; not loaded for safety",
        ".pth": "PyTorch serialized artifact; not loaded for safety",
        ".ckpt": "checkpoint artifact; not loaded for safety",
        ".onnx": "ONNX model artifact",
        ".gguf": "GGUF local LLM artifact",
        ".ggml": "GGML local LLM artifact",
        ".tflite": "TensorFlow Lite artifact",
        ".pb": "TensorFlow protobuf artifact",
        ".h5": "Keras/HDF5 model artifact",
        ".keras": "Keras model artifact",
    }.get(path.suffix.lower(), "AI/model/software artifact")


def _guess_from_modules(modules: List[Dict[str, Any]]) -> Optional[str]:
    frameworks = sorted({fw for m in modules for fw in m.get("framework_hints", [])})
    if frameworks:
        return " / ".join(frameworks[:4])
    return None


def _first_int(d: Dict[str, Any], keys: List[str]) -> Optional[int]:
    for key in keys:
        value = d.get(key)
        if isinstance(value, bool):
            continue
        if isinstance(value, int):
            return value
        if isinstance(value, str) and value.isdigit():
            return int(value)
    return None


def _first_match(pattern: re.Pattern[str], text: str) -> Optional[str]:
    if not text:
        return None
    m = pattern.search(text)
    if not m:
        return None
    if m.lastindex:
        return m.group(m.lastindex).strip()
    return m.group(0).strip()


def _human_count(n: int | float) -> str:
    n = float(n)
    for unit in ("", "K", "M", "B", "T"):
        if abs(n) < 1000:
            return f"{n:.2f}{unit}".rstrip("0").rstrip(".")
        n /= 1000
    return f"{n:.2f}P"


def _human_bytes(n: int | float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.2f} {unit}".replace(".00", "")
        n /= 1024
    return f"{n:.2f} PB"


def _unique(items: List[str]) -> List[str]:
    seen = set()
    out = []
    for item in items:
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return out


def _unique_agents(items: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    out = []
    for item in items:
        key = (item.get("name"), item.get("source"), item.get("type"), item.get("reason"))
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def _safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except Exception:
        return path.name


def _redact(text: str) -> str:
    out = text
    for label, pattern in SECRET_PATTERNS:
        out = pattern.sub(lambda m: f"[REDACTED {label}]", out)
    return out
