from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict


@dataclass(frozen=True)
class ScanProfile:
    name: str
    label: str
    max_files: int
    max_text_bytes: int
    max_hash_bytes: int
    include_hashes: bool
    include_text_samples: bool
    include_dependency_inventory: bool
    include_ast_metrics: bool
    include_prompt_inventory: bool
    include_binary_fingerprints: bool
    secret_scan: bool
    graph_depth: int
    description: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


SCAN_PROFILES: Dict[str, ScanProfile] = {
    "quick": ScanProfile(
        name="quick",
        label="Quick Scan",
        max_files=600,
        max_text_bytes=500_000,
        max_hash_bytes=64_000_000,
        include_hashes=False,
        include_text_samples=False,
        include_dependency_inventory=True,
        include_ast_metrics=False,
        include_prompt_inventory=True,
        include_binary_fingerprints=True,
        secret_scan=True,
        graph_depth=1,
        description="Fast project overview, framework detection, agents, configs, and obvious risk signals.",
    ),
    "standard": ScanProfile(
        name="standard",
        label="Standard Scan",
        max_files=2500,
        max_text_bytes=2_000_000,
        max_hash_bytes=512_000_000,
        include_hashes=True,
        include_text_samples=False,
        include_dependency_inventory=True,
        include_ast_metrics=True,
        include_prompt_inventory=True,
        include_binary_fingerprints=True,
        secret_scan=True,
        graph_depth=2,
        description="Balanced scan for most AI projects. Includes hashes, AST metrics, prompts, dependencies, and safety notes.",
    ),
    "deep": ScanProfile(
        name="deep",
        label="Deep Scan",
        max_files=9000,
        max_text_bytes=5_000_000,
        max_hash_bytes=2_000_000_000,
        include_hashes=True,
        include_text_samples=True,
        include_dependency_inventory=True,
        include_ast_metrics=True,
        include_prompt_inventory=True,
        include_binary_fingerprints=True,
        secret_scan=True,
        graph_depth=4,
        description="More complete local audit. Includes safe text samples and deeper source metrics.",
    ),
    "forensic": ScanProfile(
        name="forensic",
        label="Forensic Scan",
        max_files=25_000,
        max_text_bytes=10_000_000,
        max_hash_bytes=8_000_000_000,
        include_hashes=True,
        include_text_samples=True,
        include_dependency_inventory=True,
        include_ast_metrics=True,
        include_prompt_inventory=True,
        include_binary_fingerprints=True,
        secret_scan=True,
        graph_depth=8,
        description="Slowest profile for high-detail local review. Still never executes target code.",
    ),
}


def get_profile(name: str | None) -> ScanProfile:
    key = (name or "standard").strip().lower()
    if key not in SCAN_PROFILES:
        valid = ", ".join(SCAN_PROFILES)
        raise ValueError(f"Unknown scan profile: {name!r}. Valid profiles: {valid}")
    return SCAN_PROFILES[key]
