from __future__ import annotations

import ast
import difflib
import json
import os
import re
import shutil
import time
from pathlib import Path
from typing import Any, Dict, List


BINARY_MODEL_EXTENSIONS = {".safetensors", ".bin", ".pt", ".pth", ".ckpt", ".onnx", ".gguf", ".ggml", ".tflite", ".pb", ".h5", ".keras"}
TEXT_EXTENSIONS = {".json", ".md", ".txt", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".py", ".prompt", ".jinja", ".j2", ".rst", ".csv", ".env.example"}
AGENT_SCHEMA_KEYS = {
    "name": "string",
    "description": "string",
    "version": "string",
    "system_prompt": "string",
    "tools": "list",
    "memory": "object",
    "permissions": "object",
    "modules": "list",
}


class SafeEditor:
    """Safe editor for text-based AI modules, agents, prompts, and configs.

    It intentionally refuses to edit model weight artifacts directly.
    """

    def __init__(self, backup_dir_name: str = ".ai_inspector_backups"):
        self.backup_dir_name = backup_dir_name

    def read_text(self, path: str | Path) -> str:
        p = Path(path).expanduser().resolve()
        self._ensure_text_file(p)
        return p.read_text(encoding="utf-8", errors="replace")

    def save_text(self, path: str | Path, content: str, validate: bool = True, backup: bool = True) -> Dict[str, Any]:
        p = Path(path).expanduser().resolve()
        self._ensure_text_file(p)
        if validate:
            self.validate_content(p, content)

        backup_path = None
        if backup and p.exists():
            backup_path = self.create_backup(p)

        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return {
            "saved": str(p),
            "backup": str(backup_path) if backup_path else None,
            "bytes": len(content.encode("utf-8")),
            "validated": validate,
        }

    def create_backup(self, path: str | Path) -> Path:
        p = Path(path).expanduser().resolve()
        stamp = time.strftime("%Y%m%d_%H%M%S")
        backup_dir = p.parent / self.backup_dir_name
        backup_dir.mkdir(exist_ok=True)
        backup = backup_dir / f"{p.name}.bak_{stamp}"
        shutil.copy2(p, backup)
        return backup

    def list_backups(self, path: str | Path) -> List[Dict[str, Any]]:
        p = Path(path).expanduser().resolve()
        backup_dir = p.parent / self.backup_dir_name
        if not backup_dir.exists():
            return []
        rows = []
        for b in sorted(backup_dir.glob(f"{p.name}.bak_*"), key=lambda x: x.stat().st_mtime, reverse=True):
            rows.append({"path": str(b), "size_bytes": b.stat().st_size, "modified_unix": int(b.stat().st_mtime)})
        return rows

    def restore_backup(self, backup_path: str | Path, destination: str | Path) -> Dict[str, Any]:
        b = Path(backup_path).expanduser().resolve()
        dest = Path(destination).expanduser().resolve()
        self._ensure_text_file(dest)
        if not b.exists():
            raise FileNotFoundError(str(b))
        if dest.exists():
            current_backup = self.create_backup(dest)
        else:
            current_backup = None
        shutil.copy2(b, dest)
        return {"restored": str(dest), "from": str(b), "previous_version_backup": str(current_backup) if current_backup else None}

    def validate_content(self, path: str | Path, content: str) -> Dict[str, Any]:
        p = Path(path)
        suffix = p.suffix.lower()
        if suffix == ".json":
            json.loads(content)
            return {"valid": True, "type": "json"}
        if suffix == ".py":
            ast.parse(content, filename=str(p))
            return {"valid": True, "type": "python"}
        if suffix in {".toml"}:
            try:
                import tomllib  # Python 3.11+
                tomllib.loads(content)
            except ModuleNotFoundError:
                return {"valid": True, "type": "toml", "warning": "tomllib unavailable; syntax not checked"}
            return {"valid": True, "type": "toml"}
        if suffix in {".yaml", ".yml"}:
            return self._basic_yaml_validation(content)
        if suffix == ".ini" or suffix == ".cfg":
            import configparser
            parser = configparser.ConfigParser()
            parser.read_string(content)
            return {"valid": True, "type": "ini"}
        return {"valid": True, "type": "text"}

    def diff_text(self, path: str | Path, new_content: str, context: int = 3) -> str:
        p = Path(path).expanduser().resolve()
        old = self.read_text(p).splitlines(keepends=True) if p.exists() else []
        new = new_content.splitlines(keepends=True)
        return "".join(difflib.unified_diff(old, new, fromfile=str(p), tofile=str(p) + " (edited)", n=context))

    def patch_json_key(self, path: str | Path, dotted_key: str, value: Any) -> Dict[str, Any]:
        p = Path(path).expanduser().resolve()
        data = json.loads(self.read_text(p))
        cur = data
        parts = self._parse_dotted_key(dotted_key)
        for part in parts[:-1]:
            if isinstance(part, int):
                while len(cur) <= part:
                    cur.append({})
                cur = cur[part]
            else:
                if part not in cur or not isinstance(cur[part], (dict, list)):
                    cur[part] = {}
                cur = cur[part]
        last = parts[-1]
        if isinstance(last, int):
            while len(cur) <= last:
                cur.append(None)
            cur[last] = value
        else:
            cur[last] = value
        return self.save_text(p, json.dumps(data, indent=2, ensure_ascii=False) + "\n", validate=True)

    def update_agent_manifest(self, path: str | Path, field: str, value: Any) -> Dict[str, Any]:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            manifest = self.new_agent_manifest(name=p.stem)
        else:
            manifest = json.loads(self.read_text(p))
        if field not in AGENT_SCHEMA_KEYS:
            raise ValueError(f"Unknown agent field: {field}. Valid fields: {', '.join(AGENT_SCHEMA_KEYS)}")
        manifest[field] = value
        return self.save_text(p, json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", validate=True)

    def new_agent_manifest(self, name: str = "new_agent", description: str = "") -> Dict[str, Any]:
        return {
            "name": name,
            "description": description or "Describe what this agent does.",
            "version": "0.1.0",
            "system_prompt": "You are a focused AI agent. Follow tool permissions and ask for confirmation before irreversible actions.",
            "tools": [],
            "memory": {"enabled": False, "type": "none", "retention": "session"},
            "permissions": {
                "network": False,
                "filesystem_read": True,
                "filesystem_write": False,
                "shell": False,
                "human_approval_required": True,
            },
            "modules": [],
        }

    def create_agent_manifest_file(self, path: str | Path, name: str, description: str = "") -> Dict[str, Any]:
        p = Path(path).expanduser().resolve()
        if p.suffix.lower() != ".json":
            raise ValueError("Agent manifests are saved as JSON files.")
        manifest = self.new_agent_manifest(name=name, description=description)
        return self.save_text(p, json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", validate=True, backup=False)

    def _ensure_text_file(self, path: Path) -> None:
        if path.suffix.lower() in BINARY_MODEL_EXTENSIONS:
            raise ValueError(f"Refusing to edit binary model artifact directly: {path.name}")
        if path.suffix.lower() not in TEXT_EXTENSIONS:
            raise ValueError(f"Unsupported editor file type: {path.suffix or '<no extension>'}")

    def _basic_yaml_validation(self, content: str) -> Dict[str, Any]:
        # Dependency-free sanity check: indentation and tabs. It does not fully parse YAML.
        for idx, line in enumerate(content.splitlines(), 1):
            if "\t" in line[: len(line) - len(line.lstrip())]:
                raise ValueError(f"YAML indentation uses a tab at line {idx}; use spaces.")
            if re.match(r"^\s*:\s", line):
                raise ValueError(f"YAML appears to have an empty key at line {idx}.")
        return {"valid": True, "type": "yaml-basic", "warning": "Dependency-free basic YAML check only."}

    def _parse_dotted_key(self, key: str) -> List[str | int]:
        parts: List[str | int] = []
        for piece in key.split("."):
            if not piece:
                raise ValueError("Empty key segment")
            m = re.fullmatch(r"(.+)\[(\d+)\]", piece)
            if m:
                parts.append(m.group(1))
                parts.append(int(m.group(2)))
            elif piece.isdigit():
                parts.append(int(piece))
            else:
                parts.append(piece)
        return parts
