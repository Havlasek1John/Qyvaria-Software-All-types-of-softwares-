from __future__ import annotations

import ast
from pathlib import Path
from typing import Any, Dict, List


SUSPICIOUS_FUNCTIONS = {
    "eval", "exec", "compile", "__import__", "input",
    "os.system", "subprocess.Popen", "subprocess.call", "subprocess.run",
    "pickle.load", "pickle.loads", "marshal.load", "marshal.loads",
    "torch.load", "joblib.load", "cloudpickle.load", "dill.load",
    "socket.socket", "requests.get", "requests.post", "urllib.request.urlopen",
}

AGENT_KEYWORDS = ("agent", "tool", "planner", "memory", "orchestrator", "executor", "router", "chain", "workflow")
AI_IMPORT_HINTS = {
    "torch": "PyTorch",
    "tensorflow": "TensorFlow",
    "keras": "Keras",
    "transformers": "Transformers",
    "diffusers": "Diffusers",
    "sentence_transformers": "SentenceTransformers",
    "sklearn": "scikit-learn",
    "onnx": "ONNX",
    "onnxruntime": "ONNX Runtime",
    "llama_cpp": "llama.cpp",
    "langchain": "LangChain",
    "langgraph": "LangGraph",
    "crewai": "CrewAI",
    "autogen": "AutoGen",
    "openai": "OpenAI SDK",
    "anthropic": "Anthropic SDK",
    "google.generativeai": "Google Generative AI SDK",
    "haystack": "Haystack",
    "chromadb": "ChromaDB",
    "faiss": "FAISS",
    "pinecone": "Pinecone",
    "weaviate": "Weaviate",
    "qdrant_client": "Qdrant",
    "vllm": "vLLM",
    "peft": "PEFT/LoRA",
    "accelerate": "Accelerate",
}


def parse_python_module(path: str | Path, root: str | Path | None = None, include_metrics: bool = True) -> Dict[str, Any]:
    p = Path(path)
    root_path = Path(root).resolve() if root else p.parent.resolve()
    rel = _safe_rel(p, root_path)
    result: Dict[str, Any] = {
        "path": rel,
        "absolute_path": str(p.resolve()),
        "imports": [],
        "classes": [],
        "functions": [],
        "async_functions": [],
        "agent_hints": [],
        "framework_hints": [],
        "suspicious_calls": [],
        "call_targets": [],
        "metrics": {},
        "syntax_error": None,
    }
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        result["syntax_error"] = f"read failed: {exc}"
        return result

    try:
        tree = ast.parse(text, filename=str(p))
    except SyntaxError as exc:
        result["syntax_error"] = f"{exc.msg} at line {exc.lineno}"
        return result

    imports: List[str] = []
    call_targets: List[str] = []
    suspicious: List[str] = []
    class_names: List[str] = []
    function_names: List[str] = []
    async_function_names: List[str] = []
    agent_hints: List[Dict[str, str]] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            base = node.module or ""
            for alias in node.names:
                imports.append(f"{base}.{alias.name}" if base else alias.name)
        elif isinstance(node, ast.ClassDef):
            class_names.append(node.name)
            lower = node.name.lower()
            bases = [_call_name(base) for base in node.bases]
            if any(key in lower for key in AGENT_KEYWORDS) or any(any(key in b.lower() for key in AGENT_KEYWORDS) for b in bases):
                agent_hints.append({"type": "class", "name": node.name, "reason": "agent/tool keyword in class or base"})
        elif isinstance(node, ast.FunctionDef):
            function_names.append(node.name)
            if any(key in node.name.lower() for key in AGENT_KEYWORDS):
                agent_hints.append({"type": "function", "name": node.name, "reason": "agent/tool keyword in function"})
        elif isinstance(node, ast.AsyncFunctionDef):
            async_function_names.append(node.name)
            if any(key in node.name.lower() for key in AGENT_KEYWORDS):
                agent_hints.append({"type": "async_function", "name": node.name, "reason": "agent/tool keyword in async function"})
        elif isinstance(node, ast.Call):
            name = _call_name(node.func)
            if name:
                call_targets.append(name)
                if name in SUSPICIOUS_FUNCTIONS or _is_suspicious_call(name):
                    suspicious.append(name)

    frameworks = sorted({label for imp in imports for key, label in AI_IMPORT_HINTS.items() if imp == key or imp.startswith(key + ".")})
    result["imports"] = sorted(set(imports))
    result["classes"] = sorted(set(class_names))
    result["functions"] = sorted(set(function_names))
    result["async_functions"] = sorted(set(async_function_names))
    result["agent_hints"] = _unique_dicts(agent_hints)
    result["framework_hints"] = frameworks
    result["suspicious_calls"] = sorted(set(suspicious))
    result["call_targets"] = sorted(set(call_targets))[:250]

    if include_metrics:
        result["metrics"] = {
            "lines": text.count("\n") + 1,
            "classes": len(class_names),
            "functions": len(function_names),
            "async_functions": len(async_function_names),
            "imports": len(set(imports)),
            "approx_cyclomatic_complexity": _complexity(tree),
        }
    return result


def build_graph(modules: List[Dict[str, Any]], max_edges: int = 4000) -> Dict[str, Any]:
    nodes: Dict[str, Dict[str, str]] = {}
    edges: List[Dict[str, str]] = []

    def node(node_id: str, node_type: str, label: str | None = None) -> None:
        if node_id not in nodes:
            nodes[node_id] = {"id": node_id, "type": node_type, "label": label or node_id}

    def edge(src: str, dst: str, kind: str) -> None:
        if len(edges) < max_edges:
            edges.append({"from": src, "to": dst, "type": kind})

    for module in modules:
        module_path = module.get("path", "")
        if not module_path:
            continue
        node(module_path, "file")
        for cls in module.get("classes", [])[:80]:
            cls_id = f"{module_path}::{cls}"
            node(cls_id, "class", cls)
            edge(module_path, cls_id, "defines")
        for fn in (module.get("functions", []) + module.get("async_functions", []))[:120]:
            fn_id = f"{module_path}::{fn}()"
            node(fn_id, "function", fn)
            edge(module_path, fn_id, "defines")
        for imp in module.get("imports", [])[:120]:
            node(imp, "import", imp)
            edge(module_path, imp, "imports")
        for hint in module.get("agent_hints", [])[:40]:
            hint_id = f"{module_path}::{hint.get('name')}"
            node(hint_id, "agent", hint.get("name"))
            edge(module_path, hint_id, "agent_hint")

    return {"nodes": list(nodes.values()), "edges": edges, "node_count": len(nodes), "edge_count": len(edges)}


def _complexity(tree: ast.AST) -> int:
    score = 1
    branch_nodes = (
        ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try, ast.ExceptHandler,
        ast.With, ast.AsyncWith, ast.BoolOp, ast.IfExp, ast.Match,
    )
    for node in ast.walk(tree):
        if isinstance(node, branch_nodes):
            score += 1
        elif isinstance(node, ast.comprehension):
            score += 1
    return score


def _is_suspicious_call(name: str) -> bool:
    if name in SUSPICIOUS_FUNCTIONS:
        return True
    lowered = name.lower()
    return (
        lowered.endswith(".load") and any(x in lowered for x in ("pickle", "torch", "joblib", "dill", "cloudpickle"))
        or lowered.endswith(".system")
        or lowered.endswith(".popen")
    )


def _call_name(func: ast.AST) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        left = _call_name(func.value)
        return f"{left}.{func.attr}" if left else func.attr
    if isinstance(func, ast.Call):
        return _call_name(func.func)
    return ""


def _safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root))
    except Exception:
        return path.name


def _unique_dicts(items: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    out = []
    for item in items:
        key = tuple(sorted(item.items()))
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out
