from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable


def to_pretty_json(report: Dict[str, Any]) -> str:
    return json.dumps(report, indent=2, ensure_ascii=False, sort_keys=False)


def human_summary(report: Dict[str, Any]) -> str:
    lines = []
    target = report.get("target", {})
    risk = report.get("risk", {})
    lines.append(f"Target: {target.get('path', '<unknown>')}")
    lines.append(f"Kind: {target.get('kind', '<unknown>')}")
    if "total_files" in report:
        lines.append(f"Files scanned: {report.get('total_files')}")
    if "total_size_bytes" in report:
        lines.append(f"Total size: {_human_bytes(report.get('total_size_bytes', 0))}")
    if "framework_guess" in report:
        lines.append(f"Framework guess: {report.get('framework_guess')}")
    if risk:
        lines.append(f"Risk: {risk.get('level', 'unknown').upper()} ({risk.get('score', 0)}/100)")
        if risk.get("reasons"):
            lines.append("Risk reasons: " + ", ".join(risk.get("reasons", [])[:8]))

    pe = report.get("metadata", {}).get("parameter_estimate") or report.get("parameter_estimate")
    if pe:
        lines.append(f"Parameter estimate: {pe.get('params_human', pe.get('params'))} ({pe.get('method', 'unknown method')})")

    caps = report.get("capabilities", {})
    if caps:
        enabled = [name.replace("_", " ") for name, val in caps.items() if val is True or (isinstance(val, int) and val > 0)]
        if enabled:
            lines.append("Capabilities: " + ", ".join(enabled[:12]))

    findings = report.get("findings", [])
    if findings:
        lines.append("\nKey findings:")
        for item in findings[:20]:
            lines.append(f"- {item}")

    notes = report.get("safety_notes", [])
    if notes:
        lines.append("\nSafety notes:")
        for item in notes[:20]:
            lines.append(f"- {item}")

    agents = report.get("agents", [])
    if agents:
        lines.append("\nDetected agents/modules/tools:")
        for a in agents[:30]:
            reason = f" — {a.get('reason')}" if a.get("reason") else ""
            lines.append(f"- {a.get('name')} [{a.get('type')}] in {a.get('source')}{reason}")

    recs = report.get("edit_recommendations", [])
    if recs:
        lines.append("\nRecommended next edits:")
        for r in recs[:12]:
            lines.append(f"- {r.get('action')} ({r.get('area')}): {r.get('why')}")

    return "\n".join(lines)


def to_markdown(report: Dict[str, Any]) -> str:
    target = report.get("target", {})
    risk = report.get("risk", {})
    lines = [
        "# AI Inspector Editor Report",
        "",
        f"**Target:** `{target.get('path', '<unknown>')}`",
        f"**Kind:** {target.get('kind', '<unknown>')}",
        f"**Framework guess:** {report.get('framework_guess', '<unknown>')}",
        f"**Risk:** {risk.get('level', 'unknown').upper()} ({risk.get('score', 0)}/100)",
        "",
        "## Summary",
        "",
        _bullet_lines(report.get("findings", [])) or "- No key findings.",
        "",
        "## Safety Notes",
        "",
        _bullet_lines(report.get("safety_notes", [])) or "- No safety notes.",
        "",
        "## Agents / Modules / Tools",
        "",
    ]
    agents = report.get("agents", [])
    if agents:
        lines.extend([f"- **{a.get('name')}** `{a.get('type')}` in `{a.get('source')}` — {a.get('reason', '')}" for a in agents[:80]])
    else:
        lines.append("- None detected.")
    lines.extend(["", "## Model Artifacts", ""])
    arts = report.get("model_artifacts", [])
    if arts:
        for a in arts:
            lines.append(f"- `{a.get('path')}` — {a.get('framework_hint')} — {a.get('size_human', a.get('size_bytes'))}")
    else:
        lines.append("- None detected.")
    lines.extend(["", "## Recommended Edits", ""])
    recs = report.get("edit_recommendations", [])
    if recs:
        lines.extend([f"- **{r.get('action')}** ({r.get('area')}): {r.get('why')}" for r in recs])
    else:
        lines.append("- No recommendations generated.")
    lines.extend(["", "## Report Metadata", ""])
    analysis = report.get("analysis", {})
    lines.append(f"- Profile: `{analysis.get('profile', {}).get('name', '<unknown>')}`")
    lines.append(f"- Duration: `{analysis.get('duration_seconds', '<unknown>')}` seconds")
    lines.append(f"- Safe mode: `{analysis.get('safe_mode', True)}`")
    return "\n".join(lines) + "\n"


def save_report(report: Dict[str, Any], path: str | Path, fmt: str = "json") -> Path:
    p = Path(path).expanduser().resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    fmt = fmt.lower()
    if fmt == "json" or p.suffix.lower() == ".json":
        p.write_text(to_pretty_json(report) + "\n", encoding="utf-8")
    elif fmt in {"md", "markdown"} or p.suffix.lower() in {".md", ".markdown"}:
        p.write_text(to_markdown(report), encoding="utf-8")
    else:
        raise ValueError(f"Unknown report format: {fmt}")
    return p


def _bullet_lines(items: Iterable[Any]) -> str:
    return "\n".join(f"- {item}" for item in items)


def _human_bytes(n: int | float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.2f} {unit}".replace(".00", "")
        n /= 1024
    return f"{n:.2f} PB"
