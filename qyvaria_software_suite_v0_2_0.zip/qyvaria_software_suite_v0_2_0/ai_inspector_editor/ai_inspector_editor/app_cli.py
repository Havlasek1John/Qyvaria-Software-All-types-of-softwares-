from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .core.analyzer import AIAnalyzer
from .core.editor import AGENT_SCHEMA_KEYS, SafeEditor
from .core.profiles import SCAN_PROFILES
from .core.report import human_summary, save_report, to_markdown, to_pretty_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ai-inspector-editor",
        description="Advanced Linux/Windows AI software analyzer and safe AI module/agent editor.",
    )
    parser.add_argument("--version", action="version", version="AI Inspector Editor Modern 0.4.0")
    sub = parser.add_subparsers(dest="command", required=True)

    p_profiles = sub.add_parser("profiles", help="List scan profiles")

    p_analyze = sub.add_parser("analyze", help="Analyze a file or directory")
    p_analyze.add_argument("path")
    p_analyze.add_argument("--profile", choices=SCAN_PROFILES.keys(), default="standard")
    p_analyze.add_argument("--out", help="Write report to this file")
    p_analyze.add_argument("--format", choices=["json", "md"], default="json", help="Output file format when --out is used")
    p_analyze.add_argument("--summary", action="store_true", help="Print human summary instead of full JSON")
    p_analyze.add_argument("--max-files", type=int)
    p_analyze.add_argument("--no-hashes", action="store_true")
    p_analyze.add_argument("--text-samples", action="store_true", help="Include redacted text samples from prompt-like files")
    p_analyze.add_argument("--no-secret-scan", action="store_true")
    p_analyze.add_argument("--no-prompts", action="store_true")

    p_export = sub.add_parser("export-md", help="Analyze and export a Markdown report")
    p_export.add_argument("path")
    p_export.add_argument("--profile", choices=SCAN_PROFILES.keys(), default="standard")
    p_export.add_argument("--out", required=True)

    p_read = sub.add_parser("read", help="Read a text AI asset safely")
    p_read.add_argument("path")

    p_validate = sub.add_parser("validate", help="Validate a text AI asset")
    p_validate.add_argument("path")

    p_write = sub.add_parser("write", help="Write a text AI asset safely with backup")
    p_write.add_argument("path")
    p_write.add_argument("--content", required=True)
    p_write.add_argument("--no-validate", action="store_true")
    p_write.add_argument("--no-backup", action="store_true")

    p_diff = sub.add_parser("diff", help="Preview a unified diff before saving")
    p_diff.add_argument("path")
    p_diff.add_argument("--content", required=True)

    p_patch = sub.add_parser("patch-json", help="Patch a JSON key safely with backup")
    p_patch.add_argument("path")
    p_patch.add_argument("key", help="Dotted key, supports list syntax e.g. agents[0].name")
    p_patch.add_argument("value", help="JSON value, e.g. 0.7 or \"text\"")

    p_agent = sub.add_parser("new-agent", help="Create a new JSON agent manifest")
    p_agent.add_argument("path")
    p_agent.add_argument("--name", required=True)
    p_agent.add_argument("--description", default="")

    p_agent_update = sub.add_parser("update-agent", help="Update a field in a JSON agent manifest")
    p_agent_update.add_argument("path")
    p_agent_update.add_argument("field", choices=AGENT_SCHEMA_KEYS.keys())
    p_agent_update.add_argument("value", help="JSON value or string")

    p_backups = sub.add_parser("backups", help="List backups for an edited file")
    p_backups.add_argument("path")

    p_restore = sub.add_parser("restore", help="Restore a backup")
    p_restore.add_argument("backup")
    p_restore.add_argument("destination")

    p_gui = sub.add_parser("gui", help="Open classic desktop GUI")
    p_modern = sub.add_parser("modern-ui", help="Open the modern browser dashboard UI")
    p_modern.add_argument("--host", default="127.0.0.1")
    p_modern.add_argument("--port", type=int, default=8765)
    p_modern.add_argument("--no-browser", action="store_true")
    p_modern.add_argument("--allow-remote", action="store_true")

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    editor = SafeEditor()

    if args.command == "profiles":
        for key, profile in SCAN_PROFILES.items():
            print(f"{key:10s} {profile.label:14s} {profile.description}")
        return 0

    if args.command == "analyze":
        analyzer = AIAnalyzer(
            profile=args.profile,
            max_files=args.max_files,
            include_hashes=False if args.no_hashes else None,
            include_text_samples=True if args.text_samples else None,
            secret_scan=False if args.no_secret_scan else None,
            include_prompt_inventory=False if args.no_prompts else None,
        )
        report = analyzer.analyze(args.path)
        if args.out:
            save_report(report, args.out, fmt=args.format)
            print(f"Wrote {args.format.upper()} report: {args.out}")
        print(human_summary(report) if args.summary else to_pretty_json(report))
        return 0

    if args.command == "export-md":
        report = AIAnalyzer(profile=args.profile, include_text_samples=True).analyze(args.path)
        save_report(report, args.out, fmt="md")
        print(f"Wrote Markdown report: {args.out}")
        return 0

    if args.command == "read":
        print(editor.read_text(args.path))
        return 0

    if args.command == "validate":
        content = editor.read_text(args.path)
        print(json.dumps(editor.validate_content(args.path, content), indent=2))
        return 0

    if args.command == "write":
        result = editor.save_text(args.path, args.content, validate=not args.no_validate, backup=not args.no_backup)
        print(json.dumps(result, indent=2))
        return 0

    if args.command == "diff":
        print(editor.diff_text(args.path, args.content))
        return 0

    if args.command == "patch-json":
        value = _json_or_string(args.value)
        result = editor.patch_json_key(args.path, args.key, value)
        print(json.dumps(result, indent=2))
        return 0

    if args.command == "new-agent":
        result = editor.create_agent_manifest_file(args.path, args.name, args.description)
        print(json.dumps(result, indent=2))
        return 0

    if args.command == "update-agent":
        value = _json_or_string(args.value)
        result = editor.update_agent_manifest(args.path, args.field, value)
        print(json.dumps(result, indent=2))
        return 0

    if args.command == "backups":
        print(json.dumps(editor.list_backups(args.path), indent=2))
        return 0

    if args.command == "restore":
        print(json.dumps(editor.restore_backup(args.backup, args.destination), indent=2))
        return 0

    if args.command == "gui":
        from .app_gui import main as gui_main
        gui_main()
        return 0

    if args.command == "modern-ui":
        from .app_modern import run as modern_run
        modern_run(args.host, args.port, open_browser=not args.no_browser, allow_remote=args.allow_remote)
        return 0

    return 1


def _json_or_string(value: str):
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


if __name__ == "__main__":
    raise SystemExit(main())
