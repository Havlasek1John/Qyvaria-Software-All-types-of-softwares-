__version__ = "0.4.0"
__app_name__ = "AI Inspector Editor Modern"
