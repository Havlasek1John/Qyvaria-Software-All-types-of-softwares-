from __future__ import annotations

import argparse
import json
import mimetypes
import os
import socket
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict
from urllib.parse import urlparse

from .core.analyzer import AIAnalyzer
from .core.editor import AGENT_SCHEMA_KEYS, SafeEditor
from .core.profiles import SCAN_PROFILES
from .core.report import to_markdown, to_pretty_json


PACKAGE_DIR = Path(__file__).resolve().parent
WEB_DIR = PACKAGE_DIR / "web"


def _json_response(handler: BaseHTTPRequestHandler, payload: Dict[str, Any], status: int = 200) -> None:
    body = json.dumps(payload, ensure_ascii=False, indent=None).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)


def _text_response(handler: BaseHTTPRequestHandler, text: str, content_type: str = "text/plain; charset=utf-8", status: int = 200) -> None:
    body = text.encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)


def _read_request_json(handler: BaseHTTPRequestHandler) -> Dict[str, Any]:
    length = int(handler.headers.get("Content-Length", "0") or "0")
    raw = handler.rfile.read(length) if length else b"{}"
    if not raw:
        return {}
    return json.loads(raw.decode("utf-8"))


def _parse_jsonish(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def _server_url(host: str, port: int) -> str:
    display_host = "127.0.0.1" if host in {"0.0.0.0", "::"} else host
    return f"http://{display_host}:{port}/"


class ModernUIServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address, RequestHandlerClass, allow_remote: bool = False):
        super().__init__(server_address, RequestHandlerClass)
        self.editor = SafeEditor()
        self.latest_report: Dict[str, Any] | None = None
        self.allow_remote = allow_remote


class ModernUIHandler(BaseHTTPRequestHandler):
    server: ModernUIServer

    def log_message(self, fmt: str, *args) -> None:
        # Keep the terminal clean. Uncomment during development:
        # super().log_message(fmt, *args)
        return

    def _check_local(self) -> bool:
        if self.server.allow_remote:
            return True
        host = self.client_address[0]
        return host in {"127.0.0.1", "::1", "localhost"}

    def do_GET(self) -> None:
        if not self._check_local():
            _json_response(self, {"ok": False, "error": "Remote clients are disabled by default."}, 403)
            return

        parsed = urlparse(self.path)
        route = parsed.path
        if route in {"/", "/index.html"}:
            self._serve_static("index.html", "text/html; charset=utf-8")
            return
        if route.startswith("/static/"):
            rel = route.removeprefix("/static/")
            self._serve_static(rel)
            return
        if route == "/api/profiles":
            _json_response(self, {
                "ok": True,
                "profiles": {k: v.to_dict() for k, v in SCAN_PROFILES.items()},
                "agent_schema": AGENT_SCHEMA_KEYS,
            })
            return
        if route == "/api/latest-report":
            _json_response(self, {"ok": True, "report": self.server.latest_report})
            return
        _json_response(self, {"ok": False, "error": f"Unknown route: {route}"}, 404)

    def do_POST(self) -> None:
        if not self._check_local():
            _json_response(self, {"ok": False, "error": "Remote clients are disabled by default."}, 403)
            return

        parsed = urlparse(self.path)
        route = parsed.path
        try:
            data = _read_request_json(self)
            if route == "/api/analyze":
                self._api_analyze(data)
            elif route == "/api/read":
                self._api_read(data)
            elif route == "/api/validate":
                self._api_validate(data)
            elif route == "/api/diff":
                self._api_diff(data)
            elif route == "/api/save":
                self._api_save(data)
            elif route == "/api/backups":
                self._api_backups(data)
            elif route == "/api/restore":
                self._api_restore(data)
            elif route == "/api/json-patch":
                self._api_json_patch(data)
            elif route == "/api/new-agent":
                self._api_new_agent(data)
            elif route == "/api/update-agent":
                self._api_update_agent(data)
            elif route == "/api/markdown":
                self._api_markdown(data)
            elif route == "/api/export":
                self._api_export(data)
            elif route == "/api/pick-path":
                self._api_pick_path(data)
            else:
                _json_response(self, {"ok": False, "error": f"Unknown route: {route}"}, 404)
        except Exception as exc:
            _json_response(self, {
                "ok": False,
                "error": str(exc),
                "type": exc.__class__.__name__,
                "trace": traceback.format_exc(limit=4),
            }, 400)

    def _serve_static(self, rel: str, content_type: str | None = None) -> None:
        rel = rel.replace("\\", "/").lstrip("/")
        if ".." in rel.split("/"):
            _json_response(self, {"ok": False, "error": "Invalid path"}, 400)
            return
        path = WEB_DIR / rel
        if not path.exists() or path.is_dir():
            _json_response(self, {"ok": False, "error": f"Static file not found: {rel}"}, 404)
            return
        if content_type is None:
            content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            if content_type.startswith("text/") or path.suffix in {".js", ".css", ".svg"}:
                content_type += "; charset=utf-8"
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _api_analyze(self, data: Dict[str, Any]) -> None:
        target = data.get("path") or data.get("target")
        if not target:
            raise ValueError("Choose an AI project folder or file first.")

        profile = data.get("profile", "standard")
        analyzer = AIAnalyzer(
            profile=profile,
            max_files=_int_or_none(data.get("max_files")),
            include_hashes=_bool_or_none(data.get("include_hashes")),
            include_text_samples=_bool_or_none(data.get("include_text_samples")),
            include_dependency_inventory=_bool_or_none(data.get("include_dependency_inventory")),
            include_ast_metrics=_bool_or_none(data.get("include_ast_metrics")),
            include_prompt_inventory=_bool_or_none(data.get("include_prompt_inventory")),
            include_binary_fingerprints=_bool_or_none(data.get("include_binary_fingerprints")),
            secret_scan=_bool_or_none(data.get("secret_scan")),
        )
        report = analyzer.analyze(target)
        self.server.latest_report = report
        _json_response(self, {"ok": True, "report": report})

    def _api_read(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        text = self.server.editor.read_text(path)
        p = Path(path).expanduser().resolve()
        _json_response(self, {
            "ok": True,
            "path": str(p),
            "name": p.name,
            "suffix": p.suffix.lower(),
            "bytes": len(text.encode("utf-8")),
            "content": text,
            "backups": self.server.editor.list_backups(p),
        })

    def _api_validate(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        content = data.get("content")
        if content is None:
            content = self.server.editor.read_text(path)
        result = self.server.editor.validate_content(path, str(content))
        _json_response(self, {"ok": True, "result": result})

    def _api_diff(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        content = str(data.get("content", ""))
        diff = self.server.editor.diff_text(path, content)
        _json_response(self, {"ok": True, "diff": diff})

    def _api_save(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        content = str(data.get("content", ""))
        result = self.server.editor.save_text(
            path,
            content,
            validate=bool(data.get("validate", True)),
            backup=bool(data.get("backup", True)),
        )
        _json_response(self, {"ok": True, "result": result})

    def _api_backups(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        _json_response(self, {"ok": True, "backups": self.server.editor.list_backups(path)})

    def _api_restore(self, data: Dict[str, Any]) -> None:
        backup = _required(data, "backup")
        destination = _required(data, "destination")
        result = self.server.editor.restore_backup(backup, destination)
        _json_response(self, {"ok": True, "result": result})

    def _api_json_patch(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        key = _required(data, "key")
        value = _parse_jsonish(data.get("value"))
        result = self.server.editor.patch_json_key(path, key, value)
        _json_response(self, {"ok": True, "result": result})

    def _api_new_agent(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        name = data.get("name") or Path(path).stem or "new_agent"
        description = data.get("description", "")
        result = self.server.editor.create_agent_manifest_file(path, str(name), str(description))
        _json_response(self, {"ok": True, "result": result})

    def _api_update_agent(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        field = _required(data, "field")
        value = _parse_jsonish(data.get("value"))
        result = self.server.editor.update_agent_manifest(path, field, value)
        _json_response(self, {"ok": True, "result": result})

    def _api_markdown(self, data: Dict[str, Any]) -> None:
        report = data.get("report") or self.server.latest_report
        if not isinstance(report, dict):
            raise ValueError("No report available yet.")
        _json_response(self, {"ok": True, "markdown": to_markdown(report)})

    def _api_export(self, data: Dict[str, Any]) -> None:
        path = _required(data, "path")
        fmt = (data.get("format") or "json").lower()
        report = data.get("report") or self.server.latest_report
        if not isinstance(report, dict):
            raise ValueError("No report available yet.")
        out = Path(path).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        if fmt in {"md", "markdown"}:
            out.write_text(to_markdown(report), encoding="utf-8")
        elif fmt == "json":
            out.write_text(to_pretty_json(report) + "\n", encoding="utf-8")
        else:
            raise ValueError("Format must be json or md.")
        _json_response(self, {"ok": True, "saved": str(out), "bytes": out.stat().st_size})

    def _api_pick_path(self, data: Dict[str, Any]) -> None:
        mode = (data.get("mode") or "directory").lower()
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            if mode == "file":
                value = filedialog.askopenfilename(title="Choose AI file to inspect")
            else:
                value = filedialog.askdirectory(title="Choose AI project folder")
            root.destroy()
        except Exception as exc:
            raise RuntimeError(f"Native file picker unavailable: {exc}") from exc
        _json_response(self, {"ok": True, "path": value or ""})


def _int_or_none(value: Any) -> int | None:
    if value in (None, "", "auto"):
        return None
    return int(value)


def _bool_or_none(value: Any) -> bool | None:
    if value in (None, "", "auto"):
        return None
    return bool(value)


def _required(data: Dict[str, Any], key: str) -> Any:
    value = data.get(key)
    if value in (None, ""):
        raise ValueError(f"Missing required field: {key}")
    return value


def find_free_port(host: str, preferred: int) -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((host, preferred))
            return preferred
        except OSError:
            pass
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind((host, 0))
        return int(sock.getsockname()[1])


def run(host: str = "127.0.0.1", port: int = 8765, open_browser: bool = True, allow_remote: bool = False) -> None:
    actual_port = find_free_port(host, port)
    server = ModernUIServer((host, actual_port), ModernUIHandler, allow_remote=allow_remote)
    url = _server_url(host, actual_port)
    print(f"AI Inspector Editor Modern UI")
    print(f"Serving locally at: {url}")
    print("Press Ctrl+C to stop.")
    if open_browser:
        threading.Timer(0.45, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        server.server_close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Launch the modern browser UI for AI Inspector Editor.")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host. Default: 127.0.0.1")
    parser.add_argument("--port", type=int, default=8765, help="Preferred port. Default: 8765")
    parser.add_argument("--no-browser", action="store_true", help="Do not open the browser automatically.")
    parser.add_argument("--allow-remote", action="store_true", help="Allow non-local browser clients. Use only on trusted networks.")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    run(args.host, args.port, open_browser=not args.no_browser, allow_remote=args.allow_remote)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
