const state = {
  profiles: {},
  selectedProfile: "standard",
  report: null,
  editorPath: "",
  editorDirty: false,
};

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

function shortPath(value, max = 74) {
  const s = String(value ?? "");
  if (s.length <= max) return s;
  return "…" + s.slice(-(max - 1));
}

function fmtBytes(n) {
  n = Number(n || 0);
  if (!Number.isFinite(n)) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
}

function toast(title, body = "", kind = "good") {
  const host = $("#toastHost");
  const el = document.createElement("div");
  el.className = `toast ${kind === "bad" ? "bad" : "good"}`;
  el.innerHTML = `<div class="toast-title">${escapeHtml(title)}</div><div class="toast-body">${escapeHtml(body)}</div>`;
  host.appendChild(el);
  setTimeout(() => el.remove(), 5600);
}

async function api(path, payload = null, method = "POST") {
  const options = { method, headers: {} };
  if (payload !== null) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(payload);
  }
  const res = await fetch(path, options);
  const data = await res.json();
  if (!data.ok) {
    const message = data.error || `Request failed: ${res.status}`;
    throw Object.assign(new Error(message), { response: data });
  }
  return data;
}

function setProgress(active) {
  $("#scanProgress").classList.toggle("hidden", !active);
  $("#scanBtn").disabled = active;
}

async function init() {
  bindNavigation();
  bindActions();
  await loadProfiles();
  renderEmpty();
}

async function loadProfiles() {
  try {
    const data = await api("/api/profiles", null, "GET");
    state.profiles = data.profiles || {};
    renderProfiles();
  } catch (err) {
    toast("Could not load profiles", err.message, "bad");
  }
}

function renderProfiles() {
  const row = $("#profileRow");
  row.innerHTML = Object.entries(state.profiles).map(([key, p]) => `
    <button class="profile-card ${key === state.selectedProfile ? "active" : ""}" data-profile="${escapeHtml(key)}">
      <div class="profile-title">${escapeHtml(p.label || key)}</div>
      <div class="profile-desc">${escapeHtml(p.description || "")}</div>
    </button>
  `).join("");
  $$(".profile-card", row).forEach(btn => btn.addEventListener("click", () => {
    state.selectedProfile = btn.dataset.profile;
    renderProfiles();
  }));
}

function bindNavigation() {
  $$(".nav-item").forEach(btn => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
  });
}

function switchView(name) {
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === name));
  $$(".view").forEach(v => v.classList.toggle("active", v.id === `view-${name}`));
}

function bindActions() {
  $("#scanBtn").addEventListener("click", runScan);
  $("#pickFolderBtn").addEventListener("click", () => pickPath("directory"));
  $("#pickFileBtn").addEventListener("click", () => pickPath("file"));
  $("#downloadJson").addEventListener("click", downloadJson);
  $("#downloadMd").addEventListener("click", downloadMarkdown);
  $("#themeToggle").addEventListener("click", toggleTheme);
  $("#modalClose").addEventListener("click", () => $("#modal").close());

  $("#agentFilter").addEventListener("input", renderAgents);
  $("#moduleFilter").addEventListener("input", renderModules);
  $("#promptFilter").addEventListener("input", renderPrompts);
  $("#inventoryFilter").addEventListener("input", renderInventory);
  $("#rawFilter").addEventListener("input", renderRaw);

  $("#manualOpenBtn").addEventListener("click", () => openFile($("#manualFilePath").value.trim()));
  $("#validateBtn").addEventListener("click", validateEditor);
  $("#diffBtn").addEventListener("click", diffEditor);
  $("#saveBtn").addEventListener("click", saveEditor);
  $("#backupsBtn").addEventListener("click", showBackups);
  $("#patchBtn").addEventListener("click", patchJson);
  $("#newAgentBtn").addEventListener("click", createAgent);

  $("#editorText").addEventListener("input", () => {
    state.editorDirty = true;
    updateEditorPath();
  });

  document.addEventListener("keydown", ev => {
    const isMod = ev.ctrlKey || ev.metaKey;
    if (isMod && ev.key === "Enter") {
      ev.preventDefault();
      runScan();
    }
    if (isMod && ev.key.toLowerCase() === "s") {
      ev.preventDefault();
      if (state.editorPath) saveEditor();
    }
    if (ev.key === "Escape" && $("#modal").open) $("#modal").close();
  });
}

function toggleTheme() {
  const html = document.documentElement;
  html.dataset.theme = html.dataset.theme === "dark" ? "light" : "dark";
}

async function pickPath(mode) {
  try {
    const data = await api("/api/pick-path", { mode });
    if (data.path) $("#targetPath").value = data.path;
  } catch (err) {
    toast("Native picker unavailable", "Paste the file or folder path manually.\n" + err.message, "bad");
  }
}

function scanPayload() {
  const maxFiles = $("#maxFiles").value.trim();
  return {
    path: $("#targetPath").value.trim(),
    profile: state.selectedProfile,
    max_files: maxFiles ? Number(maxFiles) : null,
    include_hashes: $("#optHashes").checked,
    include_text_samples: $("#optSamples").checked,
    include_dependency_inventory: $("#optDeps").checked,
    include_ast_metrics: $("#optAst").checked,
    include_prompt_inventory: $("#optPrompts").checked,
    include_binary_fingerprints: $("#optBinary").checked,
    secret_scan: $("#optSecrets").checked,
  };
}

async function runScan() {
  const payload = scanPayload();
  if (!payload.path) {
    toast("Choose an AI project first", "Paste a path or use Choose Folder.", "bad");
    return;
  }
  setProgress(true);
  try {
    const data = await api("/api/analyze", payload);
    state.report = data.report;
    renderAll();
    toast("Scan complete", `${state.report.total_files || 0} files inspected.`);
  } catch (err) {
    toast("Scan failed", err.message, "bad");
  } finally {
    setProgress(false);
  }
}

function renderEmpty() {
  $("#summaryCards").innerHTML = [
    card("Risk", "—", "Run a scan"),
    card("Files", "—", "No target yet"),
    card("Framework", "—", "Unknown"),
    card("Agents", "—", "None"),
    card("Prompts", "—", "None"),
    card("Size", "—", "0 B"),
  ].join("");
}

function renderAll() {
  renderDashboard();
  renderAgents();
  renderModules();
  renderPrompts();
  renderInventory();
  renderRaw();
}

function card(label, value, note) {
  return `
    <div class="card">
      <div class="card-label">${escapeHtml(label)}</div>
      <div class="card-value">${escapeHtml(value)}</div>
      <div class="card-note">${escapeHtml(note || "")}</div>
    </div>
  `;
}

function renderDashboard() {
  const r = state.report || {};
  const risk = r.risk || {};
  const caps = r.capabilities || {};
  $("#summaryCards").innerHTML = [
    card("Risk", `${risk.score ?? 0}/100`, risk.level ? risk.level.toUpperCase() : "Unknown"),
    card("Files", r.total_files ?? 0, r.truncated ? "Scan truncated" : "Full scan"),
    card("Framework", r.framework_guess || "Unknown", r.target?.kind || "target"),
    card("Agents", (r.agents || []).length, summarizeCaps(caps)),
    card("Prompts", (r.prompts || []).length, "Prompt assets"),
    card("Size", fmtBytes(r.total_size_bytes), r.target?.name || ""),
  ].join("");

  const findings = r.findings || [];
  $("#findingCount").textContent = findings.length;
  $("#findingsList").classList.toggle("empty", !findings.length);
  $("#findingsList").innerHTML = findings.length
    ? findings.map(x => `<div class="item">${escapeHtml(x)}</div>`).join("")
    : "No findings.";

  $("#riskLevel").textContent = (risk.level || "unknown").toUpperCase();
  const score = Number(risk.score || 0);
  $("#riskGauge").style.setProperty("--score", Math.max(0, Math.min(100, score)));
  $("#riskGauge span").textContent = score;
  const reasons = risk.reasons || [];
  $("#riskReasons").classList.toggle("empty", !reasons.length);
  $("#riskReasons").innerHTML = reasons.length
    ? reasons.map(x => `<div class="item">${escapeHtml(x)}</div>`).join("")
    : "No risk reasons.";
  const notes = r.safety_notes || [];
  $("#safetyNotes").innerHTML = notes.length
    ? `<div class="item"><div class="item-title">Safety notes</div>${notes.map(n => `<div class="item-meta">${escapeHtml(n)}</div>`).join("")}</div>`
    : "";

  const artifacts = r.model_artifacts || [];
  $("#artifactGrid").classList.toggle("empty", !artifacts.length);
  $("#artifactGrid").innerHTML = artifacts.length
    ? artifacts.map(a => `
        <div class="artifact">
          <div class="artifact-name">${escapeHtml(a.path || a.name || "artifact")}</div>
          <div class="artifact-meta">${escapeHtml(a.framework_hint || "model artifact")} · ${escapeHtml(a.size_human || fmtBytes(a.size_bytes))}</div>
          <button class="ghost" onclick='showObject("Artifact", ${jsonAttr(a)})'>Details</button>
        </div>
      `).join("")
    : "No model artifacts found.";

  const recs = r.edit_recommendations || [];
  $("#recommendations").classList.toggle("empty", !recs.length);
  $("#recommendations").innerHTML = recs.length
    ? recs.map(x => `
        <div class="recommendation">
          <strong>${escapeHtml(x.action || "Recommendation")} <span class="muted">(${escapeHtml(x.area || "general")})</span></strong>
          <div class="muted">${escapeHtml(x.why || "")}</div>
        </div>
      `).join("")
    : "No recommendations generated.";
}

function summarizeCaps(caps) {
  const names = Object.entries(caps || {}).filter(([,v]) => v === true || Number(v) > 0).map(([k]) => k.replaceAll("_", " "));
  return names.slice(0, 3).join(", ") || "Capabilities";
}

function renderAgents() {
  const r = state.report || {};
  const filter = ($("#agentFilter")?.value || "").toLowerCase();
  const agents = (r.agents || []).filter(a => JSON.stringify(a).toLowerCase().includes(filter));
  $("#agentsTable").innerHTML = agents.length ? agents.map(a => `
    <tr>
      <td><strong>${escapeHtml(a.name || "unknown")}</strong></td>
      <td><span class="pill">${escapeHtml(a.type || "agent")}</span></td>
      <td><code>${escapeHtml(a.source || "")}</code></td>
      <td>${escapeHtml(a.reason || "")}</td>
      <td><button class="ghost" onclick='showObject("Agent", ${jsonAttr(a)})'>View</button></td>
    </tr>
  `).join("") : `<tr><td colspan="5" class="muted">No agents detected.</td></tr>`;
}

function renderModules() {
  const r = state.report || {};
  const filter = ($("#moduleFilter")?.value || "").toLowerCase();
  const modules = (r.modules || []).filter(m => JSON.stringify(m).toLowerCase().includes(filter));
  $("#modulesList").classList.toggle("empty", !modules.length);
  $("#modulesList").innerHTML = modules.length ? modules.map(m => `
    <div class="item">
      <div class="item-title">${escapeHtml(m.name || m.path || "module")}</div>
      <div class="item-meta">${escapeHtml(m.path || m.source || "")}</div>
      <button class="ghost" onclick='showObject("Module", ${jsonAttr(m)})'>Details</button>
    </div>
  `).join("") : "No modules detected.";

  const graph = r.module_graph || {};
  const nodes = graph.nodes || [];
  const edges = graph.edges || [];
  $("#graphMeta").textContent = `${nodes.length || 0} nodes · ${edges.length || 0} edges`;
  $("#graphCanvas").innerHTML = nodes.length ? nodes.slice(0, 80).map(n => `
    <div class="graph-node">
      <strong>${escapeHtml(n.name || n.id || "node")}</strong>
      <span>${escapeHtml(n.path || n.type || "")}</span>
    </div>
  `).join("") : "No module graph available.";
}

function renderPrompts() {
  const r = state.report || {};
  const filter = ($("#promptFilter")?.value || "").toLowerCase();
  const prompts = (r.prompts || []).filter(p => JSON.stringify(p).toLowerCase().includes(filter));
  $("#promptsList").classList.toggle("empty", !prompts.length);
  $("#promptsList").innerHTML = prompts.length ? prompts.map(p => `
    <div class="prompt-card">
      <div class="prompt-name">${escapeHtml(p.path || p.source || "prompt")}</div>
      <div class="prompt-meta">${escapeHtml(p.kind || "prompt")} · ${escapeHtml(String(p.length_chars || p.bytes || ""))} chars</div>
      <button class="ghost" onclick='openFileFromSource(${jsonAttr(p.path || p.source || "")})'>Open</button>
      <button class="ghost" onclick='showObject("Prompt", ${jsonAttr(p)})'>Details</button>
    </div>
  `).join("") : "No prompts found.";
}

function renderInventory() {
  const r = state.report || {};
  const targetRoot = r.target?.path || "";
  const filter = ($("#inventoryFilter")?.value || "").toLowerCase();
  const rows = (r.inventory || [])
    .filter(item => {
      const text = JSON.stringify(item).toLowerCase();
      return text.includes(filter);
    })
    .slice(0, 1200);

  $("#inventoryList").classList.toggle("empty", !rows.length);
  $("#inventoryList").innerHTML = rows.length ? rows.map(item => {
    const rel = item.path || item.source || item.name || "";
    const full = absolutePath(targetRoot, rel);
    const editable = isTextLike(rel);
    return `
      <button class="file-row" ${editable ? `onclick='openFile(${jsonAttr(full)})'` : `onclick='showObject("Inventory item", ${jsonAttr(item)})'`}>
        <strong>${escapeHtml(rel || "file")}</strong>
        <div class="path">${escapeHtml(item.kind || item.extension || "")} · ${escapeHtml(fmtBytes(item.size_bytes || 0))}${editable ? " · editable" : ""}</div>
      </button>
    `;
  }).join("") : "No inventory available.";
}

function absolutePath(root, rel) {
  const s = String(rel || "");
  if (!s) return s;
  if (/^[a-zA-Z]:[\\/]/.test(s) || s.startsWith("/") || s.startsWith("\\\\")) return s;
  if (!root) return s;
  const sep = root.includes("\\") ? "\\" : "/";
  return root.replace(/[\\/]+$/, "") + sep + s.replace(/^[\\/]+/, "");
}

function isTextLike(path) {
  return /\.(json|md|txt|yaml|yml|toml|ini|cfg|py|prompt|jinja|j2|rst|csv|example)$/i.test(path);
}

function openFileFromSource(source) {
  const root = state.report?.target?.path || "";
  openFile(absolutePath(root, source));
}

async function openFile(path) {
  if (!path) return;
  if (state.editorDirty && !confirm("You have unsaved editor changes. Open another file anyway?")) return;
  try {
    const data = await api("/api/read", { path });
    state.editorPath = data.path;
    state.editorDirty = false;
    $("#editorText").value = data.content;
    $("#manualFilePath").value = data.path;
    updateEditorPath();
    switchView("editor");
    toast("File opened", shortPath(data.path));
  } catch (err) {
    toast("Could not open file", err.message, "bad");
  }
}

function updateEditorPath() {
  $("#editorPath").textContent = state.editorPath ? `${state.editorDirty ? "Unsaved · " : ""}${state.editorPath}` : "No file open.";
}

async function validateEditor() {
  if (!state.editorPath) return toast("No file open", "Open a text asset first.", "bad");
  try {
    const data = await api("/api/validate", { path: state.editorPath, content: $("#editorText").value });
    toast("Validation passed", JSON.stringify(data.result));
  } catch (err) {
    toast("Validation failed", err.message, "bad");
  }
}

async function diffEditor() {
  if (!state.editorPath) return toast("No file open", "Open a text asset first.", "bad");
  try {
    const data = await api("/api/diff", { path: state.editorPath, content: $("#editorText").value });
    showModal("Diff preview", data.diff || "No changes.");
  } catch (err) {
    toast("Diff failed", err.message, "bad");
  }
}

async function saveEditor() {
  if (!state.editorPath) return toast("No file open", "Open a text asset first.", "bad");
  try {
    const data = await api("/api/save", { path: state.editorPath, content: $("#editorText").value, validate: true, backup: true });
    state.editorDirty = false;
    updateEditorPath();
    toast("Saved with backup", `Saved ${shortPath(data.result.saved)}\nBackup: ${data.result.backup || "not needed"}`);
  } catch (err) {
    toast("Save failed", err.message, "bad");
  }
}

async function showBackups() {
  if (!state.editorPath) return toast("No file open", "Open a text asset first.", "bad");
  try {
    const data = await api("/api/backups", { path: state.editorPath });
    showModal("Backups", JSON.stringify(data.backups || [], null, 2));
  } catch (err) {
    toast("Could not list backups", err.message, "bad");
  }
}

async function patchJson() {
  if (!state.editorPath) return toast("No JSON file open", "Open an agent/config JSON file first.", "bad");
  try {
    const data = await api("/api/json-patch", {
      path: state.editorPath,
      key: $("#patchKey").value.trim(),
      value: $("#patchValue").value
    });
    toast("JSON patched", data.result.saved);
    await openFile(state.editorPath);
  } catch (err) {
    toast("Patch failed", err.message, "bad");
  }
}

async function createAgent() {
  try {
    const payload = {
      path: $("#newAgentPath").value.trim(),
      name: $("#newAgentName").value.trim(),
      description: $("#newAgentDesc").value.trim()
    };
    const data = await api("/api/new-agent", payload);
    toast("Agent manifest created", data.result.saved);
    await openFile(data.result.saved);
  } catch (err) {
    toast("Agent creation failed", err.message, "bad");
  }
}

function renderRaw() {
  const raw = state.report ? JSON.stringify(state.report, null, 2) : "{}";
  const filter = ($("#rawFilter")?.value || "").trim().toLowerCase();
  if (!filter) {
    $("#rawReport").textContent = raw;
    return;
  }
  const lines = raw.split("\n").filter(line => line.toLowerCase().includes(filter));
  $("#rawReport").textContent = lines.join("\n") || "No matches.";
}

function downloadJson() {
  if (!state.report) return toast("No report yet", "Run a scan first.", "bad");
  downloadBlob("ai_inspector_report.json", JSON.stringify(state.report, null, 2), "application/json");
}

async function downloadMarkdown() {
  if (!state.report) return toast("No report yet", "Run a scan first.", "bad");
  try {
    const data = await api("/api/markdown", { report: state.report });
    downloadBlob("ai_inspector_report.md", data.markdown, "text/markdown");
  } catch (err) {
    toast("Markdown export failed", err.message, "bad");
  }
}

function downloadBlob(filename, content, type) {
  const blob = new Blob([content], { type });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

function showObject(title, obj) {
  showModal(title, JSON.stringify(obj, null, 2));
}

function showModal(title, body) {
  $("#modalTitle").textContent = title;
  $("#modalBody").textContent = body;
  $("#modal").showModal();
}

function jsonAttr(obj) {
  return JSON.stringify(obj).replace(/[<>&\']/g, c => ({ "<": "\\u003c", ">": "\\u003e", "&": "\\u0026", "'": "\\u0027" }[c]));
}

window.showObject = showObject;
window.openFile = openFile;
window.openFileFromSource = openFileFromSource;

init();
