Set-Location $PSScriptRoot
py -m ai_inspector_editor.app_modern
