@echo off
cd /d %~dp0
py -m ai_inspector_editor.app_modern
pause
