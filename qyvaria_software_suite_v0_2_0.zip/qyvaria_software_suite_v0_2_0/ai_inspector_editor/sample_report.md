# AI Inspector Editor Report

**Target:** `/mnt/data/work_modern_ui/ai_inspector_editor/examples/sample_ai`
**Kind:** directory
**Framework guess:** Agentic AI software project
**Risk:** LOW (0/100)

## Summary

- Parsed 1 Python module(s) without executing them.
- Detected 8 possible agent/module/tool component(s).
- Indexed 2 prompt/instruction asset(s).

## Safety Notes

- No safety notes.

## Agents / Modules / Tools

- **agent_manifest** `manifest/file` in `agent_manifest.json` — agent-like filename
- **ToolPermission** `class` in `agent_module.py` — agent/tool keyword in class or base
- **ResearchAgent** `class` in `agent_module.py` — agent/tool keyword in class or base
- **build_research_agent** `function` in `agent_module.py` — agent/tool keyword in function
- **run_tool** `function` in `agent_module.py` — agent/tool keyword in function
- **agents** `config` in `config.json` — key path agents
- **tools** `config` in `config.json` — key path agents[0].tools
- **memory** `config` in `config.json` — key path agents[0].memory

## Model Artifacts

- None detected.

## Recommended Edits

- **Review agent manifests and tool permissions** (agents): Agent tools, memory, and external actions should have explicit permissions.

## Report Metadata

- Profile: `standard`
- Duration: `0.007` seconds
- Safe mode: `True`
