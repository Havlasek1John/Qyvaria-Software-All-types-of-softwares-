# Qyvaria Software Suite v0.2.0

This suite contains upgraded builds of:

- AI Inspector Editor
- QTask Optimizer
- Qyvaria Zip Resizer
- SafeSpeed Optimizer

## Install all on Linux

```bash
chmod +x install_all_linux.sh
./install_all_linux.sh
```

Each app is installed into `~/.local/share/qyvaria/<app>`, adds a command in `~/.local/bin`, creates a `.desktop` launcher, and places a desktop icon when possible.

## Install all on Windows

Double-click:

```text
install_all_windows.bat
```

Each app is installed into `%LOCALAPPDATA%\Qyvaria\<app>`, creates a Desktop shortcut, and adds Start Menu shortcuts under `Qyvaria`.

## Individual installers

Each app also has its own installers inside:

```text
<app>\scripts\install_windows.bat
<app>/scripts/install_linux.sh
```

## Test report

Each app includes `TEST_REPORT.md` with compile, doctor, unit/smoke, and ZIP compression test results.
