@echo off
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0install_all_windows.ps1"
echo.
echo Done. Press Enter to close...
pause >nul
