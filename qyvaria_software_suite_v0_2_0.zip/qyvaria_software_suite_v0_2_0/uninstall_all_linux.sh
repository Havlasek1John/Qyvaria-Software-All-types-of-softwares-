#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for app in ai_inspector_editor qtask_optimizer qyvaria_zip_resizer safespeed_optimizer; do
  echo "Removing $app"
  chmod +x "$ROOT/$app/scripts/uninstall_linux.sh"
  "$ROOT/$app/scripts/uninstall_linux.sh" || true
done
echo "All Qyvaria apps removed."
