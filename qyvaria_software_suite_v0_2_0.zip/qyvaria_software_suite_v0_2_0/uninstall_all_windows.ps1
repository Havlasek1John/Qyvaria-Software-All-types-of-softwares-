$ErrorActionPreference = "SilentlyContinue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Apps = @("ai_inspector_editor", "qtask_optimizer", "qyvaria_zip_resizer", "safespeed_optimizer")
foreach ($App in $Apps) {
    $Script = Join-Path $Root "$App\scripts\uninstall_windows.ps1"
    if (Test-Path $Script) { powershell -ExecutionPolicy Bypass -NoProfile -File $Script }
}
Write-Host "All Qyvaria apps removed."
