from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
cmd = [
    sys.executable, "-m", "PyInstaller",
    "--noconfirm", "--onefile", "--windowed",
    "--name", "SafeSpeed-Qyvarian",
    str(root / "safespeed_gui.py"),
]
print("Running:", " ".join(map(str, cmd)))
subprocess.run(cmd, check=True)
