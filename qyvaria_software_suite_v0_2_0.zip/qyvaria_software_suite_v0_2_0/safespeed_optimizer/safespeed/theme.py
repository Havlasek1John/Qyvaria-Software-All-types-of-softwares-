from __future__ import annotations

import tkinter as tk
from tkinter import ttk

BG = "#0b1020"
PANEL = "#121a30"
CARD = "#16213f"
SIDEBAR = "#0d1327"
BORDER = "#2a3560"
TEXT = "#e6eaf2"
MUTED = "#94a3b8"
ACCENT = "#8b5cf6"
ACCENT_2 = "#6d5efc"
SUCCESS = "#4ade80"
WARNING = "#fbbf24"
DANGER = "#fb7185"


def apply_qyvarian_theme(root: tk.Tk) -> ttk.Style:
    root.configure(bg=BG)
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    style.configure(".", background=BG, foreground=TEXT, fieldbackground=PANEL)
    style.configure("TFrame", background=BG)
    style.configure("Card.TFrame", background=CARD, relief="flat", borderwidth=1)
    style.configure("Section.TLabelframe", background=BG, foreground=TEXT, bordercolor=BORDER)
    style.configure("Section.TLabelframe.Label", background=BG, foreground=TEXT)
    style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 18, "bold"))
    style.configure("Subtitle.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 10))
    style.configure("CardTitle.TLabel", background=CARD, foreground=TEXT, font=("Segoe UI", 11, "bold"))
    style.configure("CardValue.TLabel", background=CARD, foreground=TEXT, font=("Segoe UI", 20, "bold"))
    style.configure("Nav.TButton", background=SIDEBAR, foreground=TEXT, relief="flat", padding=(14, 12))
    style.map("Nav.TButton", background=[("active", ACCENT_2)], foreground=[("active", "#ffffff")])
    style.configure("Accent.TButton", background=ACCENT, foreground="#ffffff", relief="flat", padding=(14, 10), font=("Segoe UI", 10, "bold"))
    style.map("Accent.TButton", background=[("active", ACCENT_2), ("pressed", ACCENT_2)])
    style.configure("Ghost.TButton", background=CARD, foreground=TEXT, relief="flat", padding=(12, 9))
    style.map("Ghost.TButton", background=[("active", "#21305c")])
    style.configure("TLabel", background=BG, foreground=TEXT)
    style.configure("TCheckbutton", background=BG, foreground=TEXT)
    style.configure("TRadiobutton", background=BG, foreground=TEXT)
    style.configure("TNotebook", background=BG, borderwidth=0)
    style.configure("TNotebook.Tab", background=PANEL, foreground=TEXT, padding=(12, 8))
    style.map("TNotebook.Tab", background=[("selected", ACCENT)], foreground=[("selected", "#ffffff")])
    style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT, bordercolor=BORDER, rowheight=28)
    style.map("Treeview", background=[("selected", ACCENT_2)], foreground=[("selected", "#ffffff")])
    style.configure("Treeview.Heading", background=CARD, foreground=TEXT, relief="flat", font=("Segoe UI", 10, "bold"))
    style.configure("TEntry", fieldbackground=PANEL, foreground=TEXT)
    style.configure("TSpinbox", fieldbackground=PANEL, foreground=TEXT)
    style.configure("Horizontal.TProgressbar", troughcolor=PANEL, background=ACCENT, bordercolor=BORDER)
    return style


def hoverize(widget: tk.Widget, normal: str, active: str):
    def on_enter(event):
        widget.configure(bg=active)
    def on_leave(event):
        widget.configure(bg=normal)
    widget.bind("<Enter>", on_enter)
    widget.bind("<Leave>", on_leave)


def make_card(parent: tk.Widget, title: str, value: str, subtitle: str = "", accent: str = ACCENT) -> tk.Frame:
    card = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1, bd=0)
    strip = tk.Frame(card, bg=accent, height=4)
    strip.pack(fill="x", side="top")
    tk.Label(card, text=title, bg=CARD, fg=TEXT, font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x", padx=14, pady=(10, 2))
    tk.Label(card, text=value, bg=CARD, fg="#ffffff", font=("Segoe UI", 22, "bold"), anchor="w").pack(fill="x", padx=14)
    tk.Label(card, text=subtitle, bg=CARD, fg=MUTED, font=("Segoe UI", 9), anchor="w", justify="left", wraplength=260).pack(fill="x", padx=14, pady=(4, 12))
    return card
