from __future__ import annotations

import json
import os
import platform
import shutil
import sys
import tempfile
import time
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None


@dataclass
class CleanupItem:
    path: str
    size_bytes: int
    category: str
    modified_at: float
    root: str
    note: str = ""

    @property
    def age_days(self) -> int:
        return int(max(0, (time.time() - self.modified_at) // 86400))


@dataclass
class DeleteResult:
    deleted_count: int
    deleted_bytes: int
    failed: List[str]
    backup_path: Optional[str] = None


def format_bytes(num: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    value = float(max(0, num))
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{num} B"


def _iter_files(path: Path) -> Iterable[Path]:
    if path.is_file():
        yield path
        return
    if not path.exists():
        return
    for root, dirs, files in os.walk(path, topdown=True):
        # avoid hidden VCS / dangerous areas if somehow nested
        dirs[:] = [d for d in dirs if d not in {".git", ".svn", "__pycache__"}]
        for file in files:
            yield Path(root) / file


def _dir_size(path: Path) -> int:
    total = 0
    try:
        for p in _iter_files(path):
            try:
                total += p.stat().st_size
            except OSError:
                pass
    except OSError:
        pass
    return total


def _unique_existing_dirs(paths: Iterable[Path]) -> List[Path]:
    seen = set()
    result = []
    for p in paths:
        try:
            rp = p.expanduser().resolve()
        except OSError:
            rp = p.expanduser()
        if rp.exists() and rp not in seen:
            seen.add(rp)
            result.append(rp)
    return result


def safe_cleanup_roots() -> Dict[str, List[Path]]:
    home = Path.home()
    system = platform.system().lower()
    temp_paths: List[Path] = []
    cache_paths: List[Path] = []
    browser_paths: List[Path] = []
    recycle_like: List[Path] = []

    if system == "windows":
        local = Path(os.environ.get("LOCALAPPDATA", home / "AppData/Local"))
        roaming = Path(os.environ.get("APPDATA", home / "AppData/Roaming"))
        temp_paths.extend([Path(tempfile.gettempdir()), local / "Temp"])
        cache_paths.extend([
            local / "Microsoft/Windows/INetCache",
            local / "CrashDumps",
            local / "D3DSCache",
            local / "NVIDIA/DXCache",
        ])
        browser_paths.extend([
            local / "Google/Chrome/User Data/Default/Cache",
            local / "Microsoft/Edge/User Data/Default/Cache",
            roaming / "Mozilla/Firefox/Profiles",
        ])
        recycle_like.extend([home / "Downloads"])  # report-only context
    else:
        xdg_cache = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache"))
        temp_paths.extend([Path("/tmp"), Path(tempfile.gettempdir())])
        cache_paths.extend([
            xdg_cache / "thumbnails",
            xdg_cache / "pip",
            xdg_cache / "fontconfig",
            xdg_cache / "mesa_shader_cache",
        ])
        browser_paths.extend([
            xdg_cache / "google-chrome/Default/Cache",
            xdg_cache / "mozilla/firefox",
            xdg_cache / "chromium/Default/Cache",
        ])
        recycle_like.extend([home / "Downloads"])

    return {
        "Temporary files": _unique_existing_dirs(temp_paths),
        "Junk / cache": _unique_existing_dirs(cache_paths),
        "Browser cache": _unique_existing_dirs(browser_paths),
        "Large file roots": _unique_existing_dirs([home]),
        "Reference only": _unique_existing_dirs(recycle_like),
    }


def _is_inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _looks_dangerous(path: Path) -> bool:
    dangerous_parts = {
        "windows", "program files", "program files (x86)", "system32",
        "usr", "bin", "etc", "lib", "library", "applications",
    }
    parts = {p.lower() for p in path.parts}
    return any(part in dangerous_parts for part in parts)


def _allowed_root_for(path: Path, roots: Dict[str, List[Path]]) -> Optional[Tuple[str, Path]]:
    for category, category_roots in roots.items():
        for root in category_roots:
            if _is_inside(path, root) or path == root:
                return category, root
    return None


def scan_cleanup_items(
    min_age_days: int = 7,
    include_browser: bool = False,
    include_deep: bool = False,
    max_results: int = 2000,
) -> List[CleanupItem]:
    roots = safe_cleanup_roots()
    chosen_categories = ["Temporary files", "Junk / cache"]
    if include_browser:
        chosen_categories.append("Browser cache")
    results: List[CleanupItem] = []
    cutoff = time.time() - (min_age_days * 86400)

    for category in chosen_categories:
        for root in roots.get(category, []):
            # For Firefox profile root, only include cache-ish dirs
            targets = [root]
            if "firefox" in str(root).lower() and root.is_dir():
                targets = [p for p in root.rglob("*") if p.is_dir() and "cache" in p.name.lower()] or [root]
            for target in targets:
                if len(results) >= max_results:
                    return sorted(results, key=lambda x: x.size_bytes, reverse=True)
                if target.is_file():
                    candidates = [target]
                elif include_deep:
                    candidates = list(_iter_files(target))
                else:
                    try:
                        candidates = [p for p in target.iterdir() if p.is_file()]
                    except Exception:
                        candidates = []
                for candidate in candidates:
                    if len(results) >= max_results:
                        break
                    try:
                        if not candidate.exists():
                            continue
                        stat = candidate.stat()
                        if stat.st_mtime > cutoff:
                            continue
                        if _looks_dangerous(candidate):
                            continue
                        if stat.st_size <= 0:
                            continue
                        allowed = _allowed_root_for(candidate, roots)
                        if not allowed:
                            continue
                        results.append(CleanupItem(
                            path=str(candidate),
                            size_bytes=stat.st_size,
                            category=category,
                            modified_at=stat.st_mtime,
                            root=str(allowed[1]),
                            note="Scanned by safe conservative rules."
                        ))
                    except OSError:
                        continue
    return sorted(results, key=lambda x: x.size_bytes, reverse=True)


def estimate_cleanup(min_age_days: int = 7, include_browser: bool = False, include_deep: bool = False) -> Tuple[int, int, List[CleanupItem]]:
    items = scan_cleanup_items(min_age_days=min_age_days, include_browser=include_browser, include_deep=include_deep)
    total = sum(x.size_bytes for x in items)
    return len(items), total, items


def _backup_selected(paths: Iterable[Path], backup_dir: Optional[Path] = None) -> Optional[str]:
    backup_dir = backup_dir or (Path.home() / ".safespeed_backups")
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    archive = backup_dir / f"safespeed-backup-{stamp}.zip"
    manifest = []
    bytes_written = 0
    limit = 50 * 1024 * 1024  # 50 MB conservative backup cap
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for raw in paths:
            path = Path(raw)
            if not path.exists():
                continue
            if path.is_file():
                if bytes_written + path.stat().st_size > limit:
                    manifest.append({"path": str(path), "status": "skipped_size_limit"})
                    continue
                zf.write(path, arcname=str(Path("files") / path.name))
                bytes_written += path.stat().st_size
                manifest.append({"path": str(path), "status": "backed_up"})
            else:
                file_count = 0
                for child in _iter_files(path):
                    try:
                        size = child.stat().st_size
                    except OSError:
                        continue
                    if bytes_written + size > limit or file_count >= 500:
                        manifest.append({"path": str(path), "status": "partially_backed_up"})
                        break
                    arc = Path("dirs") / path.name / child.relative_to(path)
                    zf.write(child, arcname=str(arc))
                    bytes_written += size
                    file_count += 1
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))
    return str(archive)


def delete_cleanup_items(paths: Iterable[str], dry_run: bool = True, make_backup: bool = False) -> DeleteResult:
    roots = safe_cleanup_roots()
    deleted_count = 0
    deleted_bytes = 0
    failed: List[str] = []
    path_objs: List[Path] = []
    for raw in paths:
        p = Path(raw).expanduser()
        path_objs.append(p)

    backup_path = _backup_selected(path_objs) if (make_backup and not dry_run) else None

    for path in path_objs:
        try:
            if not path.exists():
                continue
            allowed = _allowed_root_for(path, roots)
            if not allowed or _looks_dangerous(path):
                failed.append(f"{path} (blocked by safety rules)")
                continue
            size = path.stat().st_size if path.is_file() else _dir_size(path)
            if dry_run:
                deleted_count += 1
                deleted_bytes += size
                continue
            if path.is_file():
                path.unlink()
            else:
                shutil.rmtree(path)
            deleted_count += 1
            deleted_bytes += size
        except Exception as exc:
            failed.append(f"{path} ({exc})")
    return DeleteResult(deleted_count=deleted_count, deleted_bytes=deleted_bytes, failed=failed, backup_path=backup_path)


def disk_report() -> List[Dict[str, str]]:
    reports = []
    system = platform.system().lower()
    targets: List[Tuple[str, Path]] = []
    if system == "windows":
        for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            drive = Path(f"{letter}:/")
            if drive.exists():
                targets.append((f"{letter}:", drive))
    else:
        for p in [Path("/"), Path.home()]:
            if p.exists():
                targets.append((str(p), p))
    seen = set()
    for label, path in targets:
        if str(path) in seen:
            continue
        seen.add(str(path))
        try:
            usage = shutil.disk_usage(path)
        except OSError:
            continue
        reports.append({
            "mount": label,
            "total": format_bytes(usage.total),
            "used": format_bytes(usage.used),
            "free": format_bytes(usage.free),
            "used_percent": f"{(usage.used / usage.total * 100):.1f}%" if usage.total else "0.0%",
        })
    return reports


def _windows_startup_entries() -> List[Dict[str, str]]:
    home = Path.home()
    paths = [
        Path(os.environ.get("APPDATA", home / "AppData/Roaming")) / "Microsoft/Windows/Start Menu/Programs/Startup",
        Path(os.environ.get("PROGRAMDATA", "C:/ProgramData")) / "Microsoft/Windows/Start Menu/Programs/StartUp",
    ]
    items = []
    for root in paths:
        if not root.exists():
            continue
        for p in root.glob("*"):
            items.append({"name": p.name, "path": str(p), "source": "Startup folder"})
    return items


def _linux_startup_entries() -> List[Dict[str, str]]:
    home = Path.home()
    dirs = [home / ".config/autostart", Path("/etc/xdg/autostart")]
    items = []
    for root in dirs:
        if not root.exists():
            continue
        for p in root.glob("*.desktop"):
            items.append({"name": p.stem, "path": str(p), "source": "Autostart"})
    return items


def startup_entries() -> List[Dict[str, str]]:
    system = platform.system().lower()
    if system == "windows":
        return _windows_startup_entries()
    return _linux_startup_entries()


def list_processes(limit: int = 100) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    if psutil is None:
        return rows
    for proc in psutil.process_iter(attrs=["pid", "name", "username", "memory_info", "cpu_percent", "status"]):
        try:
            info = proc.info
            mem = getattr(info.get("memory_info"), "rss", 0) if info.get("memory_info") else 0
            rows.append({
                "pid": info.get("pid"),
                "name": info.get("name") or "unknown",
                "user": info.get("username") or "",
                "memory": mem,
                "memory_human": format_bytes(mem),
                "cpu_percent": info.get("cpu_percent") or 0.0,
                "status": info.get("status") or "",
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    rows.sort(key=lambda x: (x["memory"], x["cpu_percent"]), reverse=True)
    return rows[:limit]


def terminate_process(pid: int) -> Tuple[bool, str]:
    if psutil is None:
        return False, "psutil is not installed."
    try:
        proc = psutil.Process(pid)
        proc.terminate()
        proc.wait(timeout=5)
        return True, f"Terminated process {pid}."
    except psutil.TimeoutExpired:
        return False, f"Timed out while terminating process {pid}."
    except psutil.AccessDenied:
        return False, f"Access denied for process {pid}."
    except psutil.NoSuchProcess:
        return False, f"Process {pid} not found."
    except Exception as exc:
        return False, str(exc)


def large_files_report(start_dir: Optional[str] = None, min_size_mb: int = 100, limit: int = 100) -> List[Dict[str, object]]:
    root = Path(start_dir).expanduser() if start_dir else Path.home()
    min_bytes = min_size_mb * 1024 * 1024
    skip_names = {"node_modules", ".git", "__pycache__", ".cache"}
    rows: List[Dict[str, object]] = []
    for base, dirs, files in os.walk(root, topdown=True):
        dirs[:] = [d for d in dirs if d not in skip_names]
        for file in files:
            path = Path(base) / file
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size >= min_bytes:
                rows.append({
                    "path": str(path),
                    "size_bytes": size,
                    "size_human": format_bytes(size),
                })
    rows.sort(key=lambda x: x["size_bytes"], reverse=True)
    return rows[:limit]


def performance_tips() -> List[Dict[str, str]]:
    return [
        {"category": "General", "title": "Keep at least 15% disk space free", "detail": "Low free space can hurt updates and virtual memory."},
        {"category": "Startup", "title": "Review auto-starting apps", "detail": "Too many startup apps can slow login and background performance."},
        {"category": "Browser", "title": "Clean browser cache occasionally", "detail": "This can reclaim space, but sites may reload slower at first."},
        {"category": "Memory", "title": "Close memory-heavy apps you do not need", "detail": "This reduces swap usage and keeps the system responsive."},
        {"category": "Storage", "title": "Move or delete large forgotten files", "detail": "Video captures, installers, and backups often occupy the most space."},
        {"category": "Safety", "title": "Create backups before major cleanup", "detail": "Especially when using deep cleanup or aggressive profiles."},
    ]


def schedule_preview(profile: str = "balanced", frequency: str = "weekly", hour: int = 19, minute: int = 0) -> Dict[str, str]:
    system = platform.system().lower()
    if system == "windows":
        cmd = (
            f'schtasks /Create /SC {frequency.upper()} /TN "SafeSpeed {profile}" '
            f'/TR "python -m safespeed.cli clean --profile {profile} --delete" '
            f'/ST {hour:02d}:{minute:02d}'
        )
    else:
        cron_time = f"{minute} {hour} * * {'0' if frequency == 'weekly' else '*'}"
        cmd = f'{cron_time} python -m safespeed.cli clean --profile {profile} --delete'
    return {
        "platform": system,
        "profile": profile,
        "frequency": frequency,
        "time": f"{hour:02d}:{minute:02d}",
        "command": cmd,
    }


def system_report() -> Dict[str, object]:
    report: Dict[str, object] = {
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "hostname": platform.node(),
        "cleanup_roots": {k: [str(p) for p in v] for k, v in safe_cleanup_roots().items()},
        "disk": disk_report(),
        "startup_count": len(startup_entries()),
    }
    if psutil:
        vm = psutil.virtual_memory()
        report["memory"] = {
            "total": format_bytes(vm.total),
            "available": format_bytes(vm.available),
            "used": format_bytes(vm.used),
            "percent": vm.percent,
        }
        report["process_count"] = len(psutil.pids())
        report["top_processes"] = list_processes(limit=10)
    else:
        report["memory"] = {"note": "psutil not installed"}
        report["process_count"] = 0
        report["top_processes"] = []
    count, total, items = estimate_cleanup(min_age_days=7, include_browser=False, include_deep=False)
    report["cleanup_estimate"] = {
        "count": count,
        "bytes": total,
        "human": format_bytes(total),
        "top_items": [asdict(x) for x in items[:20]],
    }
    return report
