from __future__ import annotations

import argparse
import json

from .optimizer import (
    delete_cleanup_items,
    estimate_cleanup,
    format_bytes,
    large_files_report,
    list_processes,
    performance_tips,
    schedule_preview,
    startup_entries,
    system_report,
    terminate_process,
)


def _print_json(data):
    print(json.dumps(data, indent=2))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="safespeed", description="SafeSpeed Optimizer CLI")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("report")

    clean = sub.add_parser("clean")
    clean.add_argument("--days", type=int, default=7)
    clean.add_argument("--browser", action="store_true")
    clean.add_argument("--deep", action="store_true")
    clean.add_argument("--delete", action="store_true")
    clean.add_argument("--backup", action="store_true")
    clean.add_argument("--profile", default="balanced")

    proc = sub.add_parser("processes")
    proc.add_argument("--limit", type=int, default=20)

    kill = sub.add_parser("kill")
    kill.add_argument("pid", type=int)

    sub.add_parser("startup")

    lf = sub.add_parser("large-files")
    lf.add_argument("--dir", default=None)
    lf.add_argument("--min-size-mb", type=int, default=100)
    lf.add_argument("--limit", type=int, default=20)

    sub.add_parser("tips")

    sched = sub.add_parser("schedule")
    sched.add_argument("--profile", default="balanced")
    sched.add_argument("--frequency", default="weekly", choices=["daily", "weekly"])
    sched.add_argument("--hour", type=int, default=19)
    sched.add_argument("--minute", type=int, default=0)

    args = ap.parse_args(argv)

    if args.cmd == "report":
        _print_json(system_report())
    elif args.cmd == "clean":
        include_browser = args.browser or args.profile in {"balanced", "aggressive"}
        include_deep = args.deep or args.profile == "aggressive"
        count, total, items = estimate_cleanup(args.days, include_browser=include_browser, include_deep=include_deep)
        print(f"Found {count} items totaling {format_bytes(total)}")
        for item in items[:20]:
            print(f"- {item.category}: {item.path} ({format_bytes(item.size_bytes)})")
        if args.delete:
            result = delete_cleanup_items([x.path for x in items], dry_run=False, make_backup=args.backup)
            print(f"\nDeleted {result.deleted_count} items and reclaimed {format_bytes(result.deleted_bytes)}")
            if result.backup_path:
                print(f"Backup: {result.backup_path}")
            if result.failed:
                print("Failures:")
                for row in result.failed:
                    print("  ", row)
    elif args.cmd == "processes":
        rows = list_processes(limit=args.limit)
        for row in rows:
            print(f"{row['pid']:>6}  {row['memory_human']:>9}  {row['cpu_percent']:>5}  {row['name']}")
    elif args.cmd == "kill":
        ok, msg = terminate_process(args.pid)
        print(msg)
    elif args.cmd == "startup":
        _print_json(startup_entries())
    elif args.cmd == "large-files":
        _print_json(large_files_report(start_dir=args.dir, min_size_mb=args.min_size_mb, limit=args.limit))
    elif args.cmd == "tips":
        _print_json(performance_tips())
    elif args.cmd == "schedule":
        _print_json(schedule_preview(profile=args.profile, frequency=args.frequency, hour=args.hour, minute=args.minute))


if __name__ == "__main__":
    raise SystemExit(main())
