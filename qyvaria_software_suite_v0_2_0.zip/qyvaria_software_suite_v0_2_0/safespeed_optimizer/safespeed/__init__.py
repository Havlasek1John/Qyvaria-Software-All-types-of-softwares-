"""SafeSpeed Optimizer — Qyvarian Edition."""
__version__ = "0.3.1"
