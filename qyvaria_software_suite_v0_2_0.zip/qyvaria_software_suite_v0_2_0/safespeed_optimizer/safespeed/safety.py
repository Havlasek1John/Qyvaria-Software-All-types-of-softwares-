from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class RiskOption:
    key: str
    title: str
    level: str
    description: str
    side_effects: str
    admin_required: bool = False
    backup_recommended: bool = False
    undo_note: str = "Revert the toggle or restore from backup if available."


RISK_OPTIONS: Dict[str, RiskOption] = {
    "browser_cache": RiskOption(
        key="browser_cache",
        title="Browser Cache Cleaning",
        level="Caution",
        description="Removes cached browser files to free space.",
        side_effects="Websites may load slower the first time after cleanup and some sessions may expire.",
        backup_recommended=False,
        undo_note="Browser caches rebuild automatically after browsing."
    ),
    "kill_process": RiskOption(
        key="kill_process",
        title="Process Termination",
        level="Risky",
        description="Ends a running background process.",
        side_effects="Unsaved work may be lost and apps may close unexpectedly.",
        admin_required=True,
        backup_recommended=False,
        undo_note="Restart the application manually if it was closed."
    ),
    "disable_startup": RiskOption(
        key="disable_startup",
        title="Startup App Management",
        level="Advanced",
        description="Disables selected startup applications.",
        side_effects="Some tools may stop launching automatically after login.",
        admin_required=False,
        backup_recommended=True,
        undo_note="Re-enable the startup entry from the same tool or OS settings."
    ),
    "deep_cleanup": RiskOption(
        key="deep_cleanup",
        title="Deep Cleanup",
        level="Advanced",
        description="Scans more cache and temp locations for removable files.",
        side_effects="Some application caches may be rebuilt later, temporarily slowing the next launch.",
        admin_required=False,
        backup_recommended=True,
        undo_note="Caches are generally rebuilt automatically."
    ),
    "aggressive_profile": RiskOption(
        key="aggressive_profile",
        title="Aggressive Optimization Profile",
        level="Risky",
        description="Applies the broadest scanning profile and highlights more aggressive actions.",
        side_effects="Not recommended for inexperienced users. Review every suggested action carefully.",
        admin_required=False,
        backup_recommended=True,
        undo_note="Switch back to Safe or Balanced mode."
    ),
}


PROFILE_DESCRIPTIONS = {
    "safe": {
        "title": "Safe",
        "summary": "Only conservative cleanup suggestions and low-risk actions.",
        "toggles": ["backup_before_delete"],
    },
    "balanced": {
        "title": "Balanced",
        "summary": "Balanced cleanup with optional browser cache cleanup and scheduling.",
        "toggles": ["backup_before_delete", "browser_cache", "scheduled_cleanup"],
    },
    "aggressive": {
        "title": "Aggressive",
        "summary": "Advanced cleanup profile for experienced users. Review all warnings first.",
        "toggles": ["backup_before_delete", "browser_cache", "deep_cleanup", "allow_process_tools"],
    },
}


def risk_color(level: str) -> str:
    return {
        "Safe": "#4ade80",
        "Caution": "#fbbf24",
        "Advanced": "#a78bfa",
        "Risky": "#fb7185",
    }.get(level, "#cbd5e1")


def warning_text(option_key: str) -> str:
    option = RISK_OPTIONS[option_key]
    lines = [
        f"{option.title}",
        f"Risk level: {option.level}",
        "",
        option.description,
        "",
        f"Possible side effects: {option.side_effects}",
    ]
    if option.admin_required:
        lines.append("Requires admin privileges: Yes")
    if option.backup_recommended:
        lines.append("Recommended backup first: Yes")
    lines.append(f"Undo note: {option.undo_note}")
    return "\n".join(lines)


def all_warning_options() -> List[RiskOption]:
    return list(RISK_OPTIONS.values())
