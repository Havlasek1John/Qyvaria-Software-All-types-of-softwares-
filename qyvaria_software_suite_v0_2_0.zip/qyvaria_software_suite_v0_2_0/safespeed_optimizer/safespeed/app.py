from __future__ import annotations

import json
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .optimizer import (
    delete_cleanup_items,
    disk_report,
    estimate_cleanup,
    format_bytes,
    large_files_report,
    list_processes,
    performance_tips,
    schedule_preview,
    startup_entries,
    system_report,
    terminate_process,
)
from .safety import PROFILE_DESCRIPTIONS, RISK_OPTIONS, risk_color, warning_text
from .theme import (
    ACCENT,
    BG,
    BORDER,
    CARD,
    DANGER,
    MUTED,
    SIDEBAR,
    SUCCESS,
    TEXT,
    WARNING,
    apply_qyvarian_theme,
    make_card,
)


class SafeSpeedApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SafeSpeed Optimizer — Qyvarian Edition")
        self.geometry("1400x880")
        self.minsize(1200, 760)
        apply_qyvarian_theme(self)

        self.settings = {
            "browser_cache": tk.BooleanVar(value=False),
            "deep_cleanup": tk.BooleanVar(value=False),
            "allow_process_tools": tk.BooleanVar(value=False),
            "backup_before_delete": tk.BooleanVar(value=True),
            "require_confirmation": tk.BooleanVar(value=True),
        }
        self.profile_var = tk.StringVar(value="balanced")
        self.scan_days_var = tk.IntVar(value=7)
        self.max_large_size_var = tk.IntVar(value=100)

        self._build_layout()
        self.show_page("dashboard")

    def _build_menu(self):
        """Desktop-friendly Qyvarian menu layer."""
        menubar = tk.Menu(self)
        file_menu = tk.Menu(menubar, tearoff=False)
        file_menu.add_command(label="Refresh Dashboard   F5", command=self.refresh_dashboard)
        file_menu.add_command(label="Export Report", command=self.export_report)
        file_menu.add_separator()
        file_menu.add_command(label="Exit   Ctrl+Q", command=self.destroy)
        menubar.add_cascade(label="File", menu=file_menu)

        view_menu = tk.Menu(menubar, tearoff=False)
        for page in ["dashboard", "cleanup", "processes", "startup", "disk", "schedule", "settings"]:
            view_menu.add_command(label=page.title(), command=lambda p=page: self.show_page(p))
        menubar.add_cascade(label="View", menu=view_menu)

        help_menu = tk.Menu(menubar, tearoff=False)
        help_menu.add_command(
            label="About SafeSpeed",
            command=lambda: messagebox.showinfo(
                "SafeSpeed Optimizer",
                "SafeSpeed Optimizer — Qyvarian Edition\n\n"
                "Cleaner v0.4 desktop setup, app-menu shortcuts, safer options, diagnostics, and installer support."
            ),
        )
        menubar.add_cascade(label="Help", menu=help_menu)
        self.config(menu=menubar)

    def _build_layout(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        self.sidebar = tk.Frame(self, bg=SIDEBAR, width=240, highlightthickness=1, highlightbackground=BORDER)
        self.sidebar.grid(row=0, column=0, sticky="nsw")
        self.sidebar.grid_propagate(False)

        content_wrap = tk.Frame(self, bg=BG)
        content_wrap.grid(row=0, column=1, sticky="nsew")
        content_wrap.columnconfigure(0, weight=1)
        content_wrap.rowconfigure(1, weight=1)

        header = tk.Frame(content_wrap, bg=BG)
        header.grid(row=0, column=0, sticky="ew", padx=20, pady=(18, 8))
        header.columnconfigure(0, weight=1)
        tk.Label(header, text="Qyvarian Control Center", bg=BG, fg=TEXT, font=("Segoe UI", 22, "bold")).grid(row=0, column=0, sticky="w")
        tk.Label(header, text="A safer optimizer for Windows and Linux with modern visuals, guided warnings, and reversible actions.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Button(header, text="Export JSON Report", style="Accent.TButton", command=self.export_report).grid(row=0, column=1, rowspan=2, sticky="e")

        self.page_container = tk.Frame(content_wrap, bg=BG)
        self.page_container.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 18))
        self.page_container.columnconfigure(0, weight=1)
        self.page_container.rowconfigure(0, weight=1)

        brand = tk.Frame(self.sidebar, bg=SIDEBAR)
        brand.pack(fill="x", padx=18, pady=(18, 12))
        tk.Label(brand, text="✦ SafeSpeed", bg=SIDEBAR, fg="#ffffff", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        tk.Label(brand, text="Qyvarian Edition", bg=SIDEBAR, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(2, 0))

        nav_items = [
            ("dashboard", "🏠 Dashboard"),
            ("cleanup", "🧹 Optimize & Scan"),
            ("processes", "⚡ Background Apps"),
            ("startup", "🚀 Startup Manager"),
            ("storage", "📦 Storage Tools"),
            ("profiles", "🛡 Profiles"),
            ("schedule", "🗓 Scheduled Cleanup"),
            ("settings", "⚙ Advanced"),
            ("tips", "💡 Tips"),
        ]
        self.nav_buttons = {}
        for key, label in nav_items:
            btn = tk.Button(self.sidebar, text=label, anchor="w", bg=SIDEBAR, fg=TEXT, activebackground=ACCENT,
                            activeforeground="#ffffff", relief="flat", bd=0, padx=18, pady=12,
                            font=("Segoe UI", 11), command=lambda k=key: self.show_page(k))
            btn.pack(fill="x", padx=10, pady=3)
            self.nav_buttons[key] = btn

        footer = tk.Frame(self.sidebar, bg=SIDEBAR)
        footer.pack(side="bottom", fill="x", padx=18, pady=18)
        tk.Label(footer, text="Risk badges", bg=SIDEBAR, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w")
        for level in ["Safe", "Caution", "Advanced", "Risky"]:
            tk.Label(footer, text=f"● {level}", bg=SIDEBAR, fg=risk_color(level), font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=1)

        self.pages = {
            "dashboard": DashboardPage(self.page_container, self),
            "cleanup": CleanupPage(self.page_container, self),
            "processes": ProcessesPage(self.page_container, self),
            "startup": StartupPage(self.page_container, self),
            "storage": StoragePage(self.page_container, self),
            "profiles": ProfilesPage(self.page_container, self),
            "schedule": SchedulePage(self.page_container, self),
            "settings": SettingsPage(self.page_container, self),
            "tips": TipsPage(self.page_container, self),
        }
        for frame in self.pages.values():
            frame.grid(row=0, column=0, sticky="nsew")

    def show_page(self, key: str):
        for name, btn in self.nav_buttons.items():
            btn.configure(bg=ACCENT if name == key else SIDEBAR)
        self.pages[key].tkraise()
        if hasattr(self.pages[key], "refresh"):
            self.pages[key].refresh()

    def confirm_risk(self, key: str) -> bool:
        option = RISK_OPTIONS[key]
        title = f"{option.level} Warning"
        return messagebox.askyesno(title, warning_text(key) + "\n\nDo you want to continue?")

    def export_report(self):
        data = system_report()
        out = filedialog.asksaveasfilename(title="Save report", defaultextension=".json", filetypes=[("JSON", "*.json")])
        if not out:
            return
        Path(out).write_text(json.dumps(data, indent=2), encoding="utf-8")
        messagebox.showinfo("Export complete", f"Saved report to:\n{out}")

    def apply_profile(self, name: str):
        self.profile_var.set(name)
        self.settings["browser_cache"].set(name in {"balanced", "aggressive"})
        self.settings["deep_cleanup"].set(name == "aggressive")
        self.settings["backup_before_delete"].set(True)
        if name == "aggressive":
            proceed = self.confirm_risk("aggressive_profile")
            if not proceed:
                self.profile_var.set("balanced")
                self.settings["deep_cleanup"].set(False)
                self.settings["browser_cache"].set(True)
                return False
        return True

    def safe_toggle(self, setting_key: str):
        if self.settings[setting_key].get() and setting_key in RISK_OPTIONS:
            if not self.confirm_risk(setting_key):
                self.settings[setting_key].set(False)


class PageBase(tk.Frame):
    def __init__(self, parent, app: SafeSpeedApp):
        super().__init__(parent, bg=BG)
        self.app = app

    def section(self, title: str, subtitle: str = "") -> tk.Frame:
        frame = tk.Frame(self, bg=BG)
        tk.Label(frame, text=title, bg=BG, fg=TEXT, font=("Segoe UI", 16, "bold")).pack(anchor="w")
        if subtitle:
            tk.Label(frame, text=subtitle, bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(2, 10))
        return frame


class DashboardPage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        top = self.section("System Dashboard", "Animated summary cards update whenever you open this page.")
        top.pack(fill="x", pady=(4, 12))

        self.card_wrap = tk.Frame(self, bg=BG)
        self.card_wrap.pack(fill="x")
        for i in range(4):
            self.card_wrap.columnconfigure(i, weight=1, uniform="cards")

        self.cards = []
        for i in range(4):
            card = make_card(self.card_wrap, "Loading", "...", "Please wait")
            card.grid(row=0, column=i, sticky="nsew", padx=8, pady=8)
            self.cards.append(card)

        lower = tk.Frame(self, bg=BG)
        lower.pack(fill="both", expand=True, pady=(8, 0))
        lower.columnconfigure(0, weight=3)
        lower.columnconfigure(1, weight=2)
        lower.rowconfigure(0, weight=1)

        self.report_text = tk.Text(lower, bg=CARD, fg=TEXT, insertbackground=TEXT, relief="flat",
                                   highlightbackground=BORDER, highlightthickness=1, wrap="word", font=("Consolas", 10))
        self.report_text.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.report_text.configure(state="disabled")

        right = tk.Frame(lower, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        self.quick_actions = tk.Frame(right, bg=BG)
        self.quick_actions.pack(fill="x")
        self._quick_button("Quick Boost", self.run_quick_boost, ACCENT)
        self._quick_button("Deep Cleanup", self.run_deep_scan, "#7c3aed")
        self._quick_button("Refresh Dashboard", self.refresh, "#334155")

        self.badges = tk.Frame(right, bg=BG)
        self.badges.pack(fill="both", expand=True, pady=(12, 0))
        self._warning_card("Safe", "Conservative cleanup only", SUCCESS)
        self._warning_card("Caution", "Browser cache cleaning may sign you out", WARNING)
        self._warning_card("Advanced", "Deep cleanup rebuilds some caches later", "#a78bfa")
        self._warning_card("Risky", "Process termination may lose unsaved work", DANGER)

    def _quick_button(self, text, cmd, color):
        btn = tk.Button(self.quick_actions, text=text, command=cmd, bg=color, fg="#ffffff",
                        activebackground=color, relief="flat", bd=0, font=("Segoe UI", 10, "bold"),
                        padx=14, pady=10)
        btn.pack(fill="x", pady=5)

    def _warning_card(self, title, detail, color):
        frame = tk.Frame(self.badges, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        frame.pack(fill="x", pady=6)
        tk.Frame(frame, bg=color, height=4).pack(fill="x")
        tk.Label(frame, text=title, bg=CARD, fg="#ffffff", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
        tk.Label(frame, text=detail, bg=CARD, fg=MUTED, wraplength=320, justify="left", font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=(0, 10))

    def refresh_dashboard(self):
        data = system_report()
        memory = data.get("memory", {})
        disk = (data.get("disk") or [{}])[0]
        cleanup = data.get("cleanup_estimate", {})
        cards_data = [
            ("🧠 RAM Usage", f"{memory.get('percent', 0)}%", f"{memory.get('used', '?')} used of {memory.get('total', '?')}", ACCENT),
            ("💽 Disk Usage", disk.get("used_percent", "?"), f"{disk.get('used', '?')} used • {disk.get('free', '?')} free", "#38bdf8"),
            ("🧹 Cleanup Estimate", cleanup.get("human", "0 B"), f"{cleanup.get('count', 0)} removable items detected", SUCCESS),
            ("🚀 Startup Items", str(data.get("startup_count", 0)), f"{data.get('process_count', 0)} running processes detected", WARNING),
        ]
        for idx, (title, value, subtitle, accent) in enumerate(cards_data):
            self.cards[idx].destroy()
            self.cards[idx] = make_card(self.card_wrap, title, value, subtitle, accent)
            self.cards[idx].grid(row=0, column=idx, sticky="nsew", padx=8, pady=8)

        lines = [
            "System Summary",
            "==============",
            f"Platform: {data.get('platform')}",
            f"Python: {data.get('python')}",
            f"Hostname: {data.get('hostname')}",
            "",
            "Top processes:",
        ]
        for proc in data.get("top_processes", [])[:8]:
            lines.append(f"  • {proc['name']} (PID {proc['pid']}) — {proc['memory_human']}")
        lines.append("")
        lines.append("Cleanup roots:")
        for name, roots in data.get("cleanup_roots", {}).items():
            lines.append(f"  • {name}:")
            for root in roots[:4]:
                lines.append(f"      - {root}")

        self.report_text.configure(state="normal")
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", "\n".join(lines))
        self.report_text.configure(state="disabled")

    def run_quick_boost(self):
        self.app.show_page("cleanup")
        self.app.pages["cleanup"].scan(mode="quick")

    def run_deep_scan(self):
        self.app.show_page("cleanup")
        self.app.pages["cleanup"].scan(mode="deep")

    def refresh(self):
        self.refresh_dashboard()


class CleanupPage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.items = []

        header = self.section("Optimize & Scan", "Quick Boost is conservative. Deep Cleanup scans more cache locations and shows warnings.")
        header.pack(fill="x")

        controls = tk.Frame(self, bg=BG)
        controls.pack(fill="x", pady=(0, 10))
        tk.Label(controls, text="Scan age (days):", bg=BG, fg=TEXT).pack(side="left")
        ttk.Spinbox(controls, from_=0, to=365, textvariable=self.app.scan_days_var, width=6).pack(side="left", padx=(8, 16))
        ttk.Checkbutton(controls, text="Browser Cache", variable=self.app.settings["browser_cache"],
                        command=lambda: self.app.safe_toggle("browser_cache")).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(controls, text="Deep Cleanup", variable=self.app.settings["deep_cleanup"],
                        command=lambda: self.app.safe_toggle("deep_cleanup")).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(controls, text="Backup Before Delete", variable=self.app.settings["backup_before_delete"]).pack(side="left", padx=(0, 16))

        ttk.Button(controls, text="Quick Boost", style="Accent.TButton", command=lambda: self.scan("quick")).pack(side="left", padx=6)
        ttk.Button(controls, text="Deep Cleanup", style="Ghost.TButton", command=lambda: self.scan("deep")).pack(side="left", padx=6)
        ttk.Button(controls, text="Delete Selected", style="Ghost.TButton", command=self.delete_selected).pack(side="left", padx=6)

        info = tk.Frame(self, bg=BG)
        info.pack(fill="x", pady=(0, 8))
        self.summary_var = tk.StringVar(value="No scan yet.")
        tk.Label(info, textvariable=self.summary_var, bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w")

        table_wrap = tk.Frame(self, bg=BG)
        table_wrap.pack(fill="both", expand=True)
        columns = ("category", "size", "age", "path")
        self.tree = ttk.Treeview(table_wrap, columns=columns, show="headings", selectmode="extended")
        for col, title, width in [
            ("category", "Category", 160),
            ("size", "Size", 110),
            ("age", "Age (days)", 100),
            ("path", "Path", 780),
        ]:
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(table_wrap, orient="vertical", command=self.tree.yview)
        scroll.pack(fill="y", side="right")
        self.tree.configure(yscrollcommand=scroll.set)

    def scan(self, mode="quick"):
        if mode == "deep":
            self.app.settings["deep_cleanup"].set(True)
            if not self.app.confirm_risk("deep_cleanup"):
                self.app.settings["deep_cleanup"].set(False)
                return
        days = int(self.app.scan_days_var.get())
        include_browser = self.app.settings["browser_cache"].get()
        include_deep = self.app.settings["deep_cleanup"].get() if mode == "deep" else False
        _, total, items = estimate_cleanup(days, include_browser=include_browser, include_deep=include_deep)
        self.items = items
        self.tree.delete(*self.tree.get_children())
        for idx, item in enumerate(items):
            self.tree.insert("", "end", iid=str(idx), values=(item.category, format_bytes(item.size_bytes), item.age_days, item.path))
        self.summary_var.set(f"Found {len(items)} items • estimated reclaimable space: {format_bytes(total)}")

    def delete_selected(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("Nothing selected", "Select one or more scan results first.")
            return
        paths = [self.items[int(iid)].path for iid in selection]
        if self.app.settings["require_confirmation"].get():
            if not messagebox.askyesno("Confirm delete", f"Delete {len(paths)} selected items?"):
                return
        result = delete_cleanup_items(paths, dry_run=False, make_backup=self.app.settings["backup_before_delete"].get())
        msg = f"Deleted {result.deleted_count} items and reclaimed {format_bytes(result.deleted_bytes)}."
        if result.backup_path:
            msg += f"\nBackup archive: {result.backup_path}"
        if result.failed:
            msg += "\n\nSome paths could not be deleted:\n- " + "\n- ".join(result.failed[:10])
        messagebox.showinfo("Cleanup complete", msg)
        self.scan("quick")

    def refresh(self):
        pass


class ProcessesPage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        header = self.section("Background Apps Manager", "Review memory-heavy processes. Termination is disabled unless you explicitly enable it in Advanced settings.")
        header.pack(fill="x")
        controls = tk.Frame(self, bg=BG)
        controls.pack(fill="x", pady=(0, 8))
        ttk.Button(controls, text="Refresh", style="Accent.TButton", command=self.refresh).pack(side="left")
        ttk.Button(controls, text="Terminate Selected", style="Ghost.TButton", command=self.kill_selected).pack(side="left", padx=8)
        self.note_var = tk.StringVar(value="Process list sorted by memory usage.")
        tk.Label(controls, textvariable=self.note_var, bg=BG, fg=MUTED).pack(side="left", padx=16)

        columns = ("pid", "name", "memory", "cpu", "status")
        self.tree = ttk.Treeview(self, columns=columns, show="headings")
        for col, title, width in [
            ("pid", "PID", 80),
            ("name", "Name", 360),
            ("memory", "Memory", 120),
            ("cpu", "CPU %", 90),
            ("status", "Status", 150),
        ]:
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True)

    def refresh(self):
        rows = list_processes(limit=200)
        self.tree.delete(*self.tree.get_children())
        for row in rows:
            self.tree.insert("", "end", values=(row["pid"], row["name"], row["memory_human"], row["cpu_percent"], row["status"]))

    def kill_selected(self):
        if not self.app.settings["allow_process_tools"].get():
            messagebox.showwarning("Disabled", "Enable 'Allow process termination tools' in the Advanced page first.")
            return
        selected = self.tree.focus()
        if not selected:
            messagebox.showinfo("Nothing selected", "Select a process first.")
            return
        pid = int(self.tree.item(selected, "values")[0])
        if not self.app.confirm_risk("kill_process"):
            return
        ok, msg = terminate_process(pid)
        if ok:
            messagebox.showinfo("Process manager", msg)
            self.refresh()
        else:
            messagebox.showwarning("Process manager", msg)


class StartupPage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        header = self.section("Startup Manager", "Review startup entries. This page is conservative and currently read-only.")
        header.pack(fill="x")
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", pady=(0, 8))
        ttk.Button(top, text="Refresh", style="Accent.TButton", command=self.refresh).pack(side="left")
        self.note_var = tk.StringVar(value="You will be warned before future disabling features are added.")
        tk.Label(top, textvariable=self.note_var, bg=BG, fg=MUTED).pack(side="left", padx=14)

        columns = ("name", "source", "path")
        self.tree = ttk.Treeview(self, columns=columns, show="headings")
        for col, title, width in [
            ("name", "Name", 220),
            ("source", "Source", 140),
            ("path", "Path", 820),
        ]:
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True)

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for row in startup_entries():
            self.tree.insert("", "end", values=(row["name"], row["source"], row["path"]))


class StoragePage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        header = self.section("Storage Tools", "Disk summary and large file finder.")
        header.pack(fill="x")

        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", pady=(0, 8))
        ttk.Button(top, text="Refresh Disks", style="Accent.TButton", command=self.refresh_disks).pack(side="left")
        tk.Label(top, text="Large files threshold (MB):", bg=BG, fg=TEXT).pack(side="left", padx=(18, 8))
        ttk.Spinbox(top, from_=10, to=5000, textvariable=self.app.max_large_size_var, width=8).pack(side="left")
        ttk.Button(top, text="Find Large Files", style="Ghost.TButton", command=self.scan_large).pack(side="left", padx=8)

        mid = tk.Frame(self, bg=BG)
        mid.pack(fill="both", expand=True)
        mid.columnconfigure(0, weight=1)
        mid.columnconfigure(1, weight=2)
        mid.rowconfigure(0, weight=1)

        self.disk_tree = ttk.Treeview(mid, columns=("mount", "total", "used", "free", "pct"), show="headings", height=8)
        for col, title, width in [
            ("mount", "Mount", 120),
            ("total", "Total", 120),
            ("used", "Used", 120),
            ("free", "Free", 120),
            ("pct", "Used %", 80),
        ]:
            self.disk_tree.heading(col, text=title)
            self.disk_tree.column(col, width=width, anchor="w")
        self.disk_tree.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        self.large_tree = ttk.Treeview(mid, columns=("size", "path"), show="headings")
        self.large_tree.heading("size", text="Size")
        self.large_tree.heading("path", text="Path")
        self.large_tree.column("size", width=120, anchor="w")
        self.large_tree.column("path", width=900, anchor="w")
        self.large_tree.grid(row=0, column=1, sticky="nsew")

    def refresh_disks(self):
        self.disk_tree.delete(*self.disk_tree.get_children())
        for row in disk_report():
            self.disk_tree.insert("", "end", values=(row["mount"], row["total"], row["used"], row["free"], row["used_percent"]))

    def scan_large(self):
        self.large_tree.delete(*self.large_tree.get_children())
        for row in large_files_report(min_size_mb=int(self.app.max_large_size_var.get()), limit=200):
            self.large_tree.insert("", "end", values=(row["size_human"], row["path"]))

    def refresh(self):
        self.refresh_disks()


class ProfilesPage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        header = self.section("Optimization Profiles", "Choose a profile to pre-configure scan behavior and safety defaults.")
        header.pack(fill="x")
        row = tk.Frame(self, bg=BG)
        row.pack(fill="both", expand=True)
        row.columnconfigure(0, weight=1)
        row.columnconfigure(1, weight=1)
        row.columnconfigure(2, weight=1)

        self.cards = {}
        entries = [("safe", SUCCESS), ("balanced", ACCENT), ("aggressive", DANGER)]
        for idx, (key, color) in enumerate(entries):
            info = PROFILE_DESCRIPTIONS[key]
            card = tk.Frame(row, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            card.grid(row=0, column=idx, sticky="nsew", padx=8, pady=8)
            tk.Frame(card, bg=color, height=5).pack(fill="x")
            tk.Label(card, text=info["title"], bg=CARD, fg="#ffffff", font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=16, pady=(16, 6))
            tk.Label(card, text=info["summary"], bg=CARD, fg=MUTED, wraplength=360, justify="left",
                     font=("Segoe UI", 10)).pack(anchor="w", padx=16)
            for toggle in info["toggles"]:
                tk.Label(card, text=f"• {toggle.replace('_', ' ').title()}", bg=CARD, fg=TEXT, font=("Segoe UI", 10)).pack(anchor="w", padx=16, pady=3)
            ttk.Button(card, text=f"Use {info['title']}", style="Accent.TButton", command=lambda k=key: self.use_profile(k)).pack(anchor="w", padx=16, pady=(16, 16))
            self.cards[key] = card
        self.status = tk.StringVar(value="Current profile: balanced")
        tk.Label(self, textvariable=self.status, bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(6, 0))

    def use_profile(self, key):
        if self.app.apply_profile(key):
            self.status.set(f"Current profile: {key}")

    def refresh(self):
        self.status.set(f"Current profile: {self.app.profile_var.get()}")


class SchedulePage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        header = self.section("Scheduled Cleanup", "Preview a command for Task Scheduler or cron. Safer than silently installing tasks.")
        header.pack(fill="x")

        form = tk.Frame(self, bg=BG)
        form.pack(fill="x", pady=(0, 8))
        self.frequency = tk.StringVar(value="weekly")
        self.hour = tk.IntVar(value=19)
        self.minute = tk.IntVar(value=0)

        tk.Label(form, text="Profile:", bg=BG, fg=TEXT).grid(row=0, column=0, sticky="w")
        ttk.Combobox(form, textvariable=self.app.profile_var, values=["safe", "balanced", "aggressive"], width=12, state="readonly").grid(row=0, column=1, sticky="w", padx=8)
        tk.Label(form, text="Frequency:", bg=BG, fg=TEXT).grid(row=0, column=2, sticky="w", padx=(18, 0))
        ttk.Combobox(form, textvariable=self.frequency, values=["daily", "weekly"], width=12, state="readonly").grid(row=0, column=3, sticky="w", padx=8)
        tk.Label(form, text="Time:", bg=BG, fg=TEXT).grid(row=0, column=4, sticky="w", padx=(18, 0))
        ttk.Spinbox(form, from_=0, to=23, textvariable=self.hour, width=4).grid(row=0, column=5, sticky="w", padx=(8, 2))
        ttk.Spinbox(form, from_=0, to=59, textvariable=self.minute, width=4).grid(row=0, column=6, sticky="w", padx=(2, 8))
        ttk.Button(form, text="Generate Preview", style="Accent.TButton", command=self.refresh).grid(row=0, column=7, padx=8)

        self.text = tk.Text(self, bg=CARD, fg=TEXT, relief="flat", highlightbackground=BORDER, highlightthickness=1,
                            insertbackground=TEXT, font=("Consolas", 10), wrap="word")
        self.text.pack(fill="both", expand=True)

    def refresh(self):
        data = schedule_preview(profile=self.app.profile_var.get(), frequency=self.frequency.get(), hour=self.hour.get(), minute=self.minute.get())
        lines = [
            "Scheduled Cleanup Preview",
            "=========================",
            f"Platform: {data['platform']}",
            f"Profile: {data['profile']}",
            f"Frequency: {data['frequency']}",
            f"Time: {data['time']}",
            "",
            "Suggested command:",
            data["command"],
            "",
            "Recommended workflow:",
            "1. Review the selected profile first.",
            "2. Test cleanup in preview mode manually.",
            "3. Keep backup-before-delete enabled when possible.",
        ]
        self.text.delete("1.0", "end")
        self.text.insert("1.0", "\n".join(lines))


class SettingsPage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        header = self.section("Advanced Settings", "Risky toggles always show contextual warnings.")
        header.pack(fill="x")

        wrap = tk.Frame(self, bg=BG)
        wrap.pack(fill="both", expand=True)
        left = tk.Frame(wrap, bg=BG)
        right = tk.Frame(wrap, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))

        for key, label in [
            ("browser_cache", "Enable browser cache cleaning"),
            ("deep_cleanup", "Enable deep cleanup scanning"),
            ("allow_process_tools", "Allow process termination tools"),
            ("backup_before_delete", "Create backup before delete"),
            ("require_confirmation", "Require confirmation dialogs"),
        ]:
            frame = tk.Frame(left, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            frame.pack(fill="x", pady=6)
            tk.Label(frame, text=label, bg=CARD, fg="#ffffff", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
            var = self.app.settings[key]
            if key in {"browser_cache", "deep_cleanup"}:
                level = RISK_OPTIONS[key].level
                detail = warning_text(key)
            elif key == "allow_process_tools":
                level = "Risky"
                detail = warning_text("kill_process")
            else:
                level = "Safe"
                detail = "This setting is conservative."
            badge_color = risk_color(level)
            tk.Label(frame, text=level, bg=CARD, fg=badge_color, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=14)
            tk.Label(frame, text=detail, bg=CARD, fg=MUTED, wraplength=560, justify="left").pack(anchor="w", padx=14, pady=(2, 8))
            ttk.Checkbutton(frame, variable=var, command=lambda k=key: self.on_toggle(k)).pack(anchor="w", padx=14, pady=(0, 12))

        warn = tk.Frame(right, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        warn.pack(fill="both", expand=True)
        tk.Label(warn, text="Warnings Reference", bg=CARD, fg="#ffffff", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=16, pady=(16, 10))
        for key, option in RISK_OPTIONS.items():
            tk.Label(warn, text=f"● {option.title} — {option.level}", bg=CARD, fg=risk_color(option.level),
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=16, pady=(8, 2))
            tk.Label(warn, text=option.side_effects, bg=CARD, fg=MUTED, wraplength=520, justify="left").pack(anchor="w", padx=16)

    def on_toggle(self, key):
        if key == "allow_process_tools" and self.app.settings[key].get():
            if not self.app.confirm_risk("kill_process"):
                self.app.settings[key].set(False)
        elif key in {"browser_cache", "deep_cleanup"}:
            self.app.safe_toggle(key)

    def refresh(self):
        pass


class TipsPage(PageBase):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        header = self.section("Performance Tips", "Practical tips and reminders for safer optimization.")
        header.pack(fill="x")
        self.box = tk.Frame(self, bg=BG)
        self.box.pack(fill="both", expand=True)

    def refresh(self):
        for child in self.box.winfo_children():
            child.destroy()
        for row in performance_tips():
            frame = tk.Frame(self.box, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            frame.pack(fill="x", pady=6)
            tk.Label(frame, text=f"{row['category']} — {row['title']}", bg=CARD, fg="#ffffff", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=14, pady=(12, 4))
            tk.Label(frame, text=row["detail"], bg=CARD, fg=MUTED, wraplength=1100, justify="left", font=("Segoe UI", 10)).pack(anchor="w", padx=14, pady=(0, 12))


def main():
    app = SafeSpeedApp()
    app.mainloop()


if __name__ == "__main__":
    main()
