# Changelog

## 0.4.0 — Qyvaria Stable Desktop Upgrade

- Added Linux installer with venv setup, dependency install, desktop icon, app menu entry, and CLI launcher.
- Added Windows installer with venv setup, dependency install, desktop shortcut, and Start Menu entry.
- Added uninstall scripts for Windows and Linux.
- Added doctor diagnostics script.
- Added Qyvaria icon assets.
- Rebuilt build scripts to install PyInstaller automatically in a local build venv.
- Improved Qyvarian UI consistency and desktop behavior.
- Added desktop menu bar, keyboard shortcuts, and safer desktop navigation.
