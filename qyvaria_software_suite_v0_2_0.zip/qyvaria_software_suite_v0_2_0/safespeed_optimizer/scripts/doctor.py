from __future__ import annotations
import importlib
import platform
import sys
from pathlib import Path

APP_NAME = 'SafeSpeed Optimizer'
GUI_MODULE = 'safespeed'
CLI_MODULE = 'safespeed.cli'

def check(name: str, fn) -> bool:
    try:
        fn()
        print(f"[OK] {name}")
        return True
    except Exception as exc:
        print(f"[FAIL] {name}: {exc}")
        return False

def main() -> int:
    print(f"{APP_NAME} Doctor")
    print("=" * (len(APP_NAME) + 7))
    print("Python:", sys.version.split()[0])
    print("Platform:", platform.platform())
    ok = True
    ok &= check("Tkinter", lambda: importlib.import_module("tkinter"))
    ok &= check("GUI module import", lambda: importlib.import_module(GUI_MODULE))
    ok &= check("CLI module import", lambda: importlib.import_module(CLI_MODULE))
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
