#!/usr/bin/env bash
set -Eeuo pipefail
APP_NAME="SafeSpeed Optimizer"
SLUG="safespeed-optimizer"
INSTALL_ROOT="${XDG_DATA_HOME:-$HOME/.local/share}/qyvaria/$SLUG"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
DESKTOP_DIR="${XDG_DESKTOP_DIR:-$HOME/Desktop}"

rm -rf "$INSTALL_ROOT"
rm -f "$BIN_DIR/$SLUG" "$BIN_DIR/$SLUG-cli"
rm -f "$APPS_DIR/$SLUG.desktop" "$DESKTOP_DIR/$SLUG.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS_DIR" || true
echo "$APP_NAME removed."
