$ErrorActionPreference = "Stop"
$AppName = "SafeSpeed Optimizer"
$Slug = "safespeed-optimizer"
$GuiModule = "safespeed"
$CliModule = "safespeed.cli"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Push-Location $Root

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $python) { throw "Python 3.10+ is required." }
$pycmd = $python.Source

& $pycmd -m venv .venv-build
$venvPython = Join-Path $Root ".venv-build\Scripts\python.exe"
& $venvPython -m pip install --upgrade pip setuptools wheel pyinstaller
if (Test-Path "requirements.txt") { & $venvPython -m pip install -r requirements.txt }
& $venvPython -m pip install -e .

Remove-Item -Recurse -Force build,dist -ErrorAction SilentlyContinue
& $venvPython -m PyInstaller --noconfirm --clean --name $Slug --windowed --icon assets\qyvaria_icon.ico -m $GuiModule
& $venvPython -m PyInstaller --noconfirm --clean --name "$Slug-cli" --console -m $CliModule

Write-Host ""
Write-Host "Build complete:"
Write-Host "  dist\$Slug\$Slug.exe"
Write-Host "  dist\$Slug-cli\$Slug-cli.exe"
Pop-Location
