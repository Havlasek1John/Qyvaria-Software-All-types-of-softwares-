from safespeed.optimizer import (
    format_bytes,
    performance_tips,
    schedule_preview,
    system_report,
)


def test_format_bytes():
    assert format_bytes(0) == "0 B"
    assert format_bytes(1024) == "1.0 KB"


def test_schedule_preview_contains_command():
    data = schedule_preview(profile="balanced", frequency="weekly", hour=8, minute=30)
    assert "command" in data
    assert data["time"] == "08:30"


def test_system_report_has_top_level_keys():
    data = system_report()
    assert "platform" in data
    assert "disk" in data
    assert "cleanup_estimate" in data


def test_performance_tips_nonempty():
    tips = performance_tips()
    assert len(tips) >= 3
