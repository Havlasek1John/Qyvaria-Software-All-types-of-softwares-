# SafeSpeed Optimizer — Qyvarian Edition

A safer cross-platform optimizer for Windows and Linux with a modern **Qyvarian**
dark UI, purple/violet/indigo accents, glass-like cards, and built-in warnings
for risky options.

## Highlights

- Qyvarian dark UI with left sidebar and dashboard cards
- Quick Boost, Deep Cleanup, and profile-based optimization
- Safe junk / temp scanner
- Browser cache cleaner
- Startup manager
- Background process manager
- Large file finder
- RAM usage overview
- Disk usage summary
- Performance tips
- Scheduled cleanup command preview
- Backup-before-delete support
- Risk badges and warnings:
  - Safe
  - Caution
  - Advanced
  - Risky

## Install

```bash
pip install -r requirements.txt
```

## Run GUI

```bash
python -m safespeed
```

## Run CLI

```bash
python -m safespeed.cli report
python -m safespeed.cli clean --days 7 --browser --deep
python -m safespeed.cli processes --limit 20
python -m safespeed.cli startup
python -m safespeed.cli large-files --min-size-mb 200
python -m safespeed.cli schedule --profile balanced --frequency weekly
```

## Safety Notes

This app intentionally avoids unsafe "registry cleaning" or undocumented system
tweaks. Risky features require confirmation, display warnings, and can suggest
backup first.

## Build Executables

```bash
python -m pip install pyinstaller
python build_exe.py
```


## 0.3.1 Hotfix

- Fixed Linux/Windows GUI startup crash caused by calling `refresh_dashboard` on the root app object instead of the Dashboard page.
- Added the missing CLI module entrypoint so `python -m safespeed.cli ...` works correctly.
- Hardened `run_linux.sh` and `run_windows.bat` so they launch from the script directory.


---

## Qyvaria Stable Setup v0.4.0

This package includes installers for both Windows and Linux.

### Linux

```bash
chmod +x scripts/install_linux.sh
./scripts/install_linux.sh
```

This installs the app into `~/.local/share/qyvaria/safespeed-optimizer`, adds a launcher in `~/.local/bin`, creates a desktop icon, and adds the app to your Linux app menu.

### Windows

Double-click:

```text
scripts\install_windows.bat
```

This installs the app into `%LOCALAPPDATA%\Qyvaria\safespeed-optimizer`, creates a Desktop shortcut, and adds the app to Start Menu > Qyvaria.

### Doctor test

```bash
python scripts/doctor.py
```
