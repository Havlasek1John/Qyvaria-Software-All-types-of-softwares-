# Qyvaria Software Suite v0.2 Test Report

Generated: 2026-06-15T20:22:03Z

## Qyvaria kernel run

- `/mnt/data/qyvaria.py` existed: `True`
- Return code: `0`
- Stdout length: `0`
- Note: the uploaded kernel produced empty stdout, so the upgrade used the uploaded Qyvaria package/design direction plus the existing app codebase.

## Static compile tests

- ai_inspector_editor: compileall return code `0`
- qtask_optimizer: compileall return code `0`
- qyvaria_zip_resizer: compileall return code `0`
- safespeed_optimizer: compileall return code `0`

## Doctor import tests

- ai_inspector_editor: doctor return code `0`; [OK] Tkinter; [OK] GUI module import; [OK] CLI module import
- qtask_optimizer: doctor return code `0`; [OK] Tkinter; [OK] GUI module import; [OK] CLI module import
- qyvaria_zip_resizer: doctor return code `0`; [OK] Tkinter; [OK] GUI module import; [OK] CLI module import
- safespeed_optimizer: doctor return code `0`; [OK] Tkinter; [OK] GUI module import; [OK] CLI module import

## Unit / smoke tests

- ai_inspector_editor: smoke_test.py return code `0`
- qtask_optimizer: pytest return code `0`; ..                                                                       [100%] 2 passed in 0.13s
- qyvaria_zip_resizer: pytest return code `0`; .                                                                        [100%] 1 passed in 5.28s
- safespeed_optimizer: pytest return code `0`; ....                                                                     [100%] 4 passed in 0.17s

## Functional ZIP compression test

- qyvaria_zip_resizer resized the demo archive using the new `web` recipe.
- Original: `4.96 KB`
- Output: `1.36 KB`
- Duplicates removed: `2`
- Junk removed: `2`
- Transformed text files: `2`
- Verified: `True`
- Qyvaria Proof Seal: `True`

## Installer syntax tests

- `build_linux.sh` in `ai_inspector_editor`: bash syntax return code `0`
- `install_linux.sh` in `ai_inspector_editor`: bash syntax return code `0`
- `uninstall_linux.sh` in `ai_inspector_editor`: bash syntax return code `0`
- `build_linux.sh` in `qtask_optimizer`: bash syntax return code `0`
- `install_linux.sh` in `qtask_optimizer`: bash syntax return code `0`
- `uninstall_linux.sh` in `qtask_optimizer`: bash syntax return code `0`
- `run_gui_linux.sh` in `qyvaria_zip_resizer`: bash syntax return code `0`
- `run_cli_linux.sh` in `qyvaria_zip_resizer`: bash syntax return code `0`
- `build_linux.sh` in `qyvaria_zip_resizer`: bash syntax return code `0`
- `install_linux.sh` in `qyvaria_zip_resizer`: bash syntax return code `0`
- `uninstall_linux.sh` in `qyvaria_zip_resizer`: bash syntax return code `0`
- `install_linux.sh` in `safespeed_optimizer`: bash syntax return code `0`
- `uninstall_linux.sh` in `safespeed_optimizer`: bash syntax return code `0`
- `build_linux.sh` in `safespeed_optimizer`: bash syntax return code `0`

## Known note

The sandbox Python environment printed an unrelated `Spreadsheet runtime warmup failed` message to stderr during Python startup. All app test return codes above were still `0`.