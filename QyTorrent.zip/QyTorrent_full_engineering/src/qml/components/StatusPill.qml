import QtQuick
import QtQuick.Controls

Rectangle {
    property alias text: label.text
    property color accent: "#7cc4ff"
    radius: 999
    height: 26
    implicitWidth: label.implicitWidth + 24
    color: Qt.rgba(accent.r, accent.g, accent.b, 0.12)
    border.color: accent

    Label {
        id: label
        anchors.centerIn: parent
        color: accent
        font.pixelSize: 12
        font.bold: true
    }
}
