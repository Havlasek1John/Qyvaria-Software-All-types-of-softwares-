import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ScrollView {
    id: panel
    property string torrentId: ""

    ColumnLayout {
        width: panel.width
        spacing: 12

        BoostPanel {
            Layout.fillWidth: true
            torrentId: panel.torrentId
        }

        GroupBox {
            title: "Controls"
            Layout.fillWidth: true
            ColumnLayout {
                anchors.fill: parent
                CheckBox {
                    text: "Sequential download"
                    onToggled: if (panel.torrentId !== "") torrentSession.setSequential(panel.torrentId, checked)
                }
                RowLayout {
                    Label { text: "Upload KB/s" }
                    SpinBox { id: up; from: 0; to: 10000000; editable: true; Layout.fillWidth: true }
                }
                RowLayout {
                    Label { text: "Download KB/s" }
                    SpinBox { id: down; from: 0; to: 10000000; editable: true; Layout.fillWidth: true }
                }
                Button {
                    text: "Apply per-torrent limits"
                    onClicked: if (panel.torrentId !== "") torrentSession.setTorrentLimits(panel.torrentId, up.value * 1024, down.value * 1024)
                }
            }
        }

        GroupBox {
            title: "Peers"
            Layout.fillWidth: true
            ColumnLayout {
                Repeater {
                    model: panel.torrentId === "" ? [] : torrentSession.peersFor(panel.torrentId)
                    delegate: Label {
                        text: modelData.address + "  ↓" + Math.round(modelData.downloadRate/1024) + " KB/s  ↑" + Math.round(modelData.uploadRate/1024) + " KB/s  score " + modelData.score
                        color: "#a8b3c7"
                    }
                }
            }
        }

        GroupBox {
            title: "Files"
            Layout.fillWidth: true
            ColumnLayout {
                Repeater {
                    model: panel.torrentId === "" ? [] : torrentSession.filesFor(panel.torrentId)
                    delegate: RowLayout {
                        Label { text: modelData.path; color: "#a8b3c7"; elide: Text.ElideMiddle; Layout.fillWidth: true }
                        SpinBox {
                            from: 0; to: 7; value: modelData.priority
                            onValueModified: torrentSession.setFilePriority(panel.torrentId, modelData.index, value)
                        }
                    }
                }
            }
        }
    }
}
