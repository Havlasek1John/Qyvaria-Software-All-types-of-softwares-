import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: row
    height: 112
    radius: 14
    color: selected ? "#243b5b" : "#101722"
    border.color: selected ? "#4fb4ff" : "#253047"

    property bool selected: false
    signal clicked()

    MouseArea { anchors.fill: parent; onClicked: row.clicked() }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 12
        spacing: 8

        RowLayout {
            Label { text: name; color: "#e9eef9"; font.pixelSize: 16; font.bold: true; elide: Text.ElideRight; Layout.fillWidth: true }
            StatusPill { text: state }
            StatusPill { text: boostEnabled ? "Boost" : "Normal"; accent: boostEnabled ? "#7cffc2" : "#7e8ba3" }
        }

        ProgressBar {
            Layout.fillWidth: true
            from: 0
            to: 1
            value: progress
        }

        RowLayout {
            Label { text: Math.round(progress * 1000) / 10 + "%"; color: "#a8b3c7" }
            Label { text: "↓ " + Math.round(downloadRate / 1024) + " KB/s"; color: "#a8b3c7" }
            Label { text: "↑ " + Math.round(uploadRate / 1024) + " KB/s"; color: "#a8b3c7" }
            Label { text: "Ratio " + ratio.toFixed(2); color: "#a8b3c7" }
            Label { text: "S/L " + seeders + "/" + leechers; color: "#a8b3c7" }
            Item { Layout.fillWidth: true }
            Button { text: "Pause"; onClicked: torrentSession.pauseTorrent(torrentId) }
            Button { text: "Resume"; onClicked: torrentSession.resumeTorrent(torrentId) }
            Button { text: "Remove"; onClicked: torrentSession.removeTorrent(torrentId, false) }
        }

        Label { text: savePath + "  •  " + trackerStatus; color: "#7e8ba3"; elide: Text.ElideMiddle; Layout.fillWidth: true }
    }
}
