import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

GroupBox {
    id: box
    title: "Auto Seed Boost"
    property string torrentId: ""

    ColumnLayout {
        anchors.fill: parent
        CheckBox {
            text: "Boost this torrent by sharing more"
            checked: true
            onToggled: if (torrentId !== "") torrentSession.setBoostEnabled(torrentId, checked)
        }
        Label {
            text: "Boost mode scores peers, protects user limits, prioritizes swarm value, and avoids overloading the connection."
            wrapMode: Text.Wrap
            color: "#a8b3c7"
            Layout.fillWidth: true
        }
    }
}
