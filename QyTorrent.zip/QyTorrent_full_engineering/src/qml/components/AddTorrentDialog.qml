import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

Dialog {
    id: dialog
    title: "Add Torrent"
    modal: true
    standardButtons: Dialog.NoButton
    width: 720
    height: 620
    anchors.centerIn: parent

    property string torrentFile: ""
    property string saveFolder: settingsStore.defaultDownloadPath

    function localPath(urlText) {
        var s = String(urlText)
        if (s.indexOf("file://") === 0) {
            return decodeURIComponent(s.replace("file://", ""))
        }
        return s
    }

    FileDialog {
        id: torrentFileDialog
        title: "Choose .torrent file"
        nameFilters: ["Torrent files (*.torrent)", "All files (*)"]
        onAccepted: torrentFile = selectedFile
    }

    FolderDialog {
        id: folderDialog
        title: "Choose download folder or drive"
        currentFolder: saveFolder
        onAccepted: {
            saveFolder = selectedFolder
            settingsStore.setDefaultDownloadPath(localPath(selectedFolder))
        }
    }

    contentItem: ColumnLayout {
        spacing: 12

        Label {
            text: "Choose what to download and where to save it before starting."
            color: "#a8b3c7"
        }

        GroupBox {
            title: "Torrent source"
            Layout.fillWidth: true
            ColumnLayout {
                anchors.fill: parent
                RowLayout {
                    TextField {
                        id: torrentPath
                        Layout.fillWidth: true
                        placeholderText: "Choose .torrent file"
                        text: dialog.localPath(dialog.torrentFile)
                    }
                    Button { text: "Browse"; onClicked: torrentFileDialog.open() }
                }
                TextArea {
                    id: magnet
                    Layout.fillWidth: true
                    Layout.preferredHeight: 82
                    placeholderText: "Or paste magnet link here"
                    wrapMode: Text.WrapAnywhere
                }
            }
        }

        GroupBox {
            title: "Download location"
            Layout.fillWidth: true
            ColumnLayout {
                anchors.fill: parent

                RowLayout {
                    TextField {
                        id: savePath
                        Layout.fillWidth: true
                        text: dialog.localPath(dialog.saveFolder)
                        placeholderText: "Example: D:/Downloads/QyTorrent or /mnt/storage/torrents"
                        onTextChanged: dialog.saveFolder = text
                    }
                    Button { text: "Choose folder / drive"; onClicked: folderDialog.open() }
                }

                Label {
                    text: "Available roots: " + torrentSession.downloadRoots.join("   ")
                    color: "#7e8ba3"
                    wrapMode: Text.Wrap
                    Layout.fillWidth: true
                }
            }
        }

        GroupBox {
            title: "Mode"
            Layout.fillWidth: true
            ColumnLayout {
                anchors.fill: parent
                ComboBox {
                    id: mode
                    Layout.fillWidth: true
                    model: ["Fast Download", "Ratio Builder", "Seed Forever", "Normal"]
                    currentIndex: 0
                }
                CheckBox { id: boost; text: "Enable Auto Seed Boost Mode"; checked: true }
                CheckBox { id: sequential; text: "Sequential download"; checked: false }
            }
        }

        GroupBox {
            title: "Per-torrent speed limits"
            Layout.fillWidth: true
            GridLayout {
                columns: 2
                anchors.fill: parent

                Label { text: "Upload limit KB/s, 0 = global/unlimited" }
                SpinBox { id: upLimit; from: 0; to: 10000000; value: 0; editable: true; Layout.fillWidth: true }

                Label { text: "Download limit KB/s, 0 = global/unlimited" }
                SpinBox { id: downLimit; from: 0; to: 10000000; value: 0; editable: true; Layout.fillWidth: true }
            }
        }

        Item { Layout.fillHeight: true }

        RowLayout {
            Layout.alignment: Qt.AlignRight
            Button { text: "Cancel"; onClicked: dialog.close() }
            Button {
                text: "Start Torrent"
                highlighted: true
                onClicked: {
                    var save = dialog.localPath(dialog.saveFolder)
                    if (magnet.text.trim().length > 0) {
                        torrentSession.addMagnet(magnet.text.trim(), save, boost.checked, sequential.checked, mode.currentText, upLimit.value * 1024, downLimit.value * 1024)
                    } else {
                        torrentSession.addTorrentFile(torrentPath.text, save, boost.checked, sequential.checked, mode.currentText, upLimit.value * 1024, downLimit.value * 1024)
                    }
                    dialog.close()
                }
            }
        }
    }
}
