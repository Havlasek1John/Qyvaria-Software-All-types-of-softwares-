import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

Rectangle {
    color: settingsStore.darkMode ? "#0c1017" : "#f5f7fb"

    FolderDialog {
        id: defaultFolder
        title: "Default download folder"
        onAccepted: settingsStore.setDefaultDownloadPath(String(selectedFolder).replace("file://", ""))
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 18
        spacing: 14

        Label { text: "Settings"; font.pixelSize: 24; font.bold: true; color: "#e9eef9" }

        GroupBox {
            title: "Download folders"
            Layout.fillWidth: true
            ColumnLayout {
                anchors.fill: parent
                RowLayout {
                    TextField { text: settingsStore.defaultDownloadPath; Layout.fillWidth: true; onEditingFinished: settingsStore.setDefaultDownloadPath(text) }
                    Button { text: "Browse"; onClicked: defaultFolder.open() }
                }
            }
        }

        GroupBox {
            title: "Global speed limits"
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label { text: "Global upload KB/s" }
                SpinBox { from: 0; to: 10000000; value: settingsStore.globalUploadLimit / 1024; editable: true; onValueModified: settingsStore.setGlobalUploadLimit(value * 1024) }
                Label { text: "Global download KB/s" }
                SpinBox { from: 0; to: 10000000; value: settingsStore.globalDownloadLimit / 1024; editable: true; onValueModified: settingsStore.setGlobalDownloadLimit(value * 1024) }
            }
        }

        GroupBox {
            title: "Interface"
            Layout.fillWidth: true
            CheckBox { text: "Dark mode"; checked: settingsStore.darkMode; onToggled: settingsStore.setDarkMode(checked) }
        }

        GroupBox {
            title: "Local Web API"
            Layout.fillWidth: true
            ColumnLayout {
                anchors.fill: parent
                CheckBox { text: "Enable localhost API"; checked: settingsStore.webApiEnabled; onToggled: settingsStore.setWebApiEnabled(checked) }
                SpinBox { from: 1024; to: 65535; value: settingsStore.webApiPort; editable: true; onValueModified: settingsStore.setWebApiPort(value) }
                Label { text: webApi.running ? "Running" : "Stopped"; color: "#a8b3c7" }
            }
        }

        Item { Layout.fillHeight: true }
    }
}
