import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "components"

ApplicationWindow {
    id: root
    width: 1220
    height: 780
    visible: true
    title: "QyTorrent"

    property string selectedTorrentId: ""

    color: settingsStore.darkMode ? "#0c1017" : "#f5f7fb"

    header: ToolBar {
        background: Rectangle { color: settingsStore.darkMode ? "#121824" : "#ffffff" }
        RowLayout {
            anchors.fill: parent
            anchors.margins: 8
            Label { text: "QyTorrent"; font.pixelSize: 22; font.bold: true; color: "#7cc4ff" }
            Label { text: "Share smarter. Download faster."; color: "#a8b3c7" }
            Item { Layout.fillWidth: true }
            Button { text: "+ Add Torrent"; onClicked: addDialog.open() }
            Button { text: "Settings"; onClicked: settingsDrawer.open() }
        }
    }

    AddTorrentDialog { id: addDialog }

    Drawer {
        id: settingsDrawer
        width: Math.min(root.width * 0.42, 520)
        height: root.height
        edge: Qt.RightEdge
        SettingsPage { anchors.fill: parent }
    }

    SplitView {
        anchors.fill: parent
        anchors.margins: 14
        orientation: Qt.Horizontal

        Rectangle {
            SplitView.fillWidth: true
            SplitView.minimumWidth: 720
            radius: 16
            color: settingsStore.darkMode ? "#151b27" : "#ffffff"
            border.color: settingsStore.darkMode ? "#253047" : "#dfe4ee"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 12
                spacing: 10

                RowLayout {
                    Label { text: "Downloads"; font.pixelSize: 20; font.bold: true; color: settingsStore.darkMode ? "#e9eef9" : "#152033" }
                    Item { Layout.fillWidth: true }
                    Label { text: torrentSession.lastError; color: "#ff8e8e"; elide: Text.ElideRight; Layout.maximumWidth: 500 }
                }

                ListView {
                    id: list
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    spacing: 8
                    clip: true
                    model: torrentModel
                    delegate: TorrentRow {
                        width: list.width
                        selected: root.selectedTorrentId === torrentId
                        onClicked: root.selectedTorrentId = torrentId
                    }
                }
            }
        }

        Rectangle {
            SplitView.preferredWidth: 410
            SplitView.minimumWidth: 360
            radius: 16
            color: settingsStore.darkMode ? "#151b27" : "#ffffff"
            border.color: settingsStore.darkMode ? "#253047" : "#dfe4ee"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 12
                Label {
                    text: selectedTorrentId === "" ? "Select a torrent" : "Torrent Details"
                    font.pixelSize: 20
                    font.bold: true
                    color: settingsStore.darkMode ? "#e9eef9" : "#152033"
                }
                DetailsPanel {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    torrentId: root.selectedTorrentId
                }
            }
        }
    }
}
