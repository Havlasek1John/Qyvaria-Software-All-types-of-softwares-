#pragma once
#include <QObject>
#include <QSettings>
#include <QString>
#include <QStringList>

class SettingsStore : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString defaultDownloadPath READ defaultDownloadPath WRITE setDefaultDownloadPath NOTIFY changed)
    Q_PROPERTY(QStringList recentDownloadPaths READ recentDownloadPaths NOTIFY changed)
    Q_PROPERTY(int globalUploadLimit READ globalUploadLimit WRITE setGlobalUploadLimit NOTIFY changed)
    Q_PROPERTY(int globalDownloadLimit READ globalDownloadLimit WRITE setGlobalDownloadLimit NOTIFY changed)
    Q_PROPERTY(QString speedProfile READ speedProfile WRITE setSpeedProfile NOTIFY changed)
    Q_PROPERTY(bool darkMode READ darkMode WRITE setDarkMode NOTIFY changed)
    Q_PROPERTY(bool webApiEnabled READ webApiEnabled WRITE setWebApiEnabled NOTIFY changed)
    Q_PROPERTY(int webApiPort READ webApiPort WRITE setWebApiPort NOTIFY changed)

public:
    explicit SettingsStore(QObject* parent = nullptr);

    QString defaultDownloadPath() const;
    QStringList recentDownloadPaths() const;
    int globalUploadLimit() const;
    int globalDownloadLimit() const;
    QString speedProfile() const;
    bool darkMode() const;
    bool webApiEnabled() const;
    int webApiPort() const;

    Q_INVOKABLE void setDefaultDownloadPath(const QString& path);
    Q_INVOKABLE void addRecentDownloadPath(const QString& path);
    Q_INVOKABLE void setGlobalUploadLimit(int bytesPerSecond);
    Q_INVOKABLE void setGlobalDownloadLimit(int bytesPerSecond);
    Q_INVOKABLE void setSpeedProfile(const QString& profile);
    Q_INVOKABLE void setDarkMode(bool value);
    Q_INVOKABLE void setWebApiEnabled(bool value);
    Q_INVOKABLE void setWebApiPort(int port);

signals:
    void changed();

private:
    QSettings m_settings;
};
