#include "PathTools.hpp"
#include <QDir>
#include <QFileInfo>
#include <QStorageInfo>

QStringList PathTools::availableDownloadRoots()
{
    QStringList roots;
    const auto volumes = QStorageInfo::mountedVolumes();
    for (const auto& volume : volumes) {
        if (!volume.isValid() || !volume.isReady()) continue;
        if (volume.bytesAvailable() <= 0) continue;
        const QString root = QDir::cleanPath(volume.rootPath());
        if (!root.isEmpty()) roots << root;
    }
    roots.removeDuplicates();
    roots.sort(Qt::CaseInsensitive);
    return roots;
}

QString PathTools::driveLabelForRoot(const QString& rootPath)
{
    QStorageInfo volume(rootPath);
    QString name = volume.displayName();
    if (name.isEmpty()) name = QFileInfo(rootPath).fileName();
    if (name.isEmpty()) name = rootPath;

    const QString free = displaySize(volume.bytesAvailable());
    const QString total = displaySize(volume.bytesTotal());
    const QString fs = QString::fromUtf8(volume.fileSystemType());
    return QString("%1  —  %2 free of %3  —  %4  —  %5")
        .arg(rootPath, free, total, fs.isEmpty() ? "filesystem" : fs, name);
}

QString PathTools::defaultDownloadFolderOnRoot(const QString& rootPath)
{
    QDir root(rootPath);
#ifdef Q_OS_WIN
    return QDir::cleanPath(root.filePath("QyTorrent"));
#else
    // On Linux, a removable drive often mounts at /media/user/DriveName.
    // Putting data in a QyTorrent subfolder prevents mixing files with existing drive contents.
    return QDir::cleanPath(root.filePath("QyTorrent"));
#endif
}

QString PathTools::displayBytes(qint64 b)
{
    const char* units[] = {"B/s", "KB/s", "MB/s", "GB/s"};
    double v = static_cast<double>(b);
    int u = 0;
    while (v >= 1024.0 && u < 3) { v /= 1024.0; ++u; }
    return QString::number(v, 'f', u == 0 ? 0 : 1) + " " + units[u];
}

QString PathTools::displaySize(qint64 b)
{
    if (b <= 0) return "unknown";
    const char* units[] = {"B", "KB", "MB", "GB", "TB"};
    double v = static_cast<double>(b);
    int u = 0;
    while (v >= 1024.0 && u < 4) { v /= 1024.0; ++u; }
    return QString::number(v, 'f', u == 0 ? 0 : 1) + " " + units[u];
}
