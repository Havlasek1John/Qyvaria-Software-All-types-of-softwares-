#pragma once
#include <QObject>
#include <QString>

struct AddTorrentRequest
{
    QString source;       // .torrent file path or magnet URI
    QString savePath;     // drive/folder selected before start
    bool sourceIsMagnet = false;
    bool boost = true;
    bool sequential = false;
    QString mode = "Fast Download";
    int uploadLimit = 0;   // bytes/sec, 0 means unlimited/global
    int downloadLimit = 0; // bytes/sec, 0 means unlimited/global
};

class DownloadPlanner
{
public:
    static QString normalizeLocalPath(QString pathOrUrl);
    static bool ensureDownloadDirectory(const QString& path, QString* error);
    static bool looksLikeMagnet(const QString& text);
    static QString defaultNameForSource(const QString& source);
};
