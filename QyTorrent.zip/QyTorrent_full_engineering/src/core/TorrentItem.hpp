#pragma once
#include <QObject>
#include <QString>
#include <QVector>

struct PeerView
{
    QString address;
    int downloadRate = 0;
    int uploadRate = 0;
    int score = 0;
    bool choked = false;
};

struct FileEntryView
{
    QString path;
    qint64 size = 0;
    int priority = 4;
};

class TorrentItem : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString id READ id CONSTANT)
    Q_PROPERTY(QString name READ name WRITE setName NOTIFY changed)
    Q_PROPERTY(QString savePath READ savePath WRITE setSavePath NOTIFY changed)
    Q_PROPERTY(QString state READ state WRITE setState NOTIFY changed)
    Q_PROPERTY(QString trackerStatus READ trackerStatus WRITE setTrackerStatus NOTIFY changed)
    Q_PROPERTY(double progress READ progress WRITE setProgress NOTIFY changed)
    Q_PROPERTY(double ratio READ ratio WRITE setRatio NOTIFY changed)
    Q_PROPERTY(int seeders READ seeders WRITE setSeeders NOTIFY changed)
    Q_PROPERTY(int leechers READ leechers WRITE setLeechers NOTIFY changed)
    Q_PROPERTY(int peers READ peers WRITE setPeers NOTIFY changed)
    Q_PROPERTY(int downloadRate READ downloadRate WRITE setDownloadRate NOTIFY changed)
    Q_PROPERTY(int uploadRate READ uploadRate WRITE setUploadRate NOTIFY changed)
    Q_PROPERTY(int uploadLimit READ uploadLimit WRITE setUploadLimit NOTIFY changed)
    Q_PROPERTY(int downloadLimit READ downloadLimit WRITE setDownloadLimit NOTIFY changed)
    Q_PROPERTY(bool boostEnabled READ boostEnabled WRITE setBoostEnabled NOTIFY changed)
    Q_PROPERTY(bool sequential READ sequential WRITE setSequential NOTIFY changed)
    Q_PROPERTY(QString mode READ mode WRITE setMode NOTIFY changed)

public:
    explicit TorrentItem(QString id, QObject* parent = nullptr);

    QString id() const { return m_id; }
    QString name() const { return m_name; }
    QString savePath() const { return m_savePath; }
    QString state() const { return m_state; }
    QString trackerStatus() const { return m_trackerStatus; }
    double progress() const { return m_progress; }
    double ratio() const { return m_ratio; }
    int seeders() const { return m_seeders; }
    int leechers() const { return m_leechers; }
    int peers() const { return m_peers; }
    int downloadRate() const { return m_downloadRate; }
    int uploadRate() const { return m_uploadRate; }
    int uploadLimit() const { return m_uploadLimit; }
    int downloadLimit() const { return m_downloadLimit; }
    bool boostEnabled() const { return m_boostEnabled; }
    bool sequential() const { return m_sequential; }
    QString mode() const { return m_mode; }

    QVector<PeerView> peerViews() const { return m_peerViews; }
    QVector<FileEntryView> files() const { return m_files; }

    void setName(const QString& v);
    void setSavePath(const QString& v);
    void setState(const QString& v);
    void setTrackerStatus(const QString& v);
    void setProgress(double v);
    void setRatio(double v);
    void setSeeders(int v);
    void setLeechers(int v);
    void setPeers(int v);
    void setDownloadRate(int v);
    void setUploadRate(int v);
    void setUploadLimit(int v);
    void setDownloadLimit(int v);
    void setBoostEnabled(bool v);
    void setSequential(bool v);
    void setMode(const QString& v);
    void setPeerViews(QVector<PeerView> peers);
    void setFiles(QVector<FileEntryView> files);

signals:
    void changed();

private:
    QString m_id;
    QString m_name = "New torrent";
    QString m_savePath;
    QString m_state = "queued";
    QString m_trackerStatus = "waiting";
    double m_progress = 0.0;
    double m_ratio = 0.0;
    int m_seeders = 0;
    int m_leechers = 0;
    int m_peers = 0;
    int m_downloadRate = 0;
    int m_uploadRate = 0;
    int m_uploadLimit = 0;
    int m_downloadLimit = 0;
    bool m_boostEnabled = false;
    bool m_sequential = false;
    QString m_mode = "Fast Download";
    QVector<PeerView> m_peerViews;
    QVector<FileEntryView> m_files;
};
