#include "TorrentItem.hpp"

TorrentItem::TorrentItem(QString id, QObject* parent) : QObject(parent), m_id(std::move(id)) {}

#define SETTER_IMPL(Type, Name, Field) \
void TorrentItem::Name(Type v) { if (Field == v) return; Field = v; emit changed(); }

SETTER_IMPL(const QString&, setName, m_name)
SETTER_IMPL(const QString&, setSavePath, m_savePath)
SETTER_IMPL(const QString&, setState, m_state)
SETTER_IMPL(const QString&, setTrackerStatus, m_trackerStatus)
SETTER_IMPL(double, setProgress, m_progress)
SETTER_IMPL(double, setRatio, m_ratio)
SETTER_IMPL(int, setSeeders, m_seeders)
SETTER_IMPL(int, setLeechers, m_leechers)
SETTER_IMPL(int, setPeers, m_peers)
SETTER_IMPL(int, setDownloadRate, m_downloadRate)
SETTER_IMPL(int, setUploadRate, m_uploadRate)
SETTER_IMPL(int, setUploadLimit, m_uploadLimit)
SETTER_IMPL(int, setDownloadLimit, m_downloadLimit)
SETTER_IMPL(bool, setBoostEnabled, m_boostEnabled)
SETTER_IMPL(bool, setSequential, m_sequential)
SETTER_IMPL(const QString&, setMode, m_mode)

void TorrentItem::setPeerViews(QVector<PeerView> peers)
{
    m_peerViews = std::move(peers);
    emit changed();
}

void TorrentItem::setFiles(QVector<FileEntryView> files)
{
    m_files = std::move(files);
    emit changed();
}
