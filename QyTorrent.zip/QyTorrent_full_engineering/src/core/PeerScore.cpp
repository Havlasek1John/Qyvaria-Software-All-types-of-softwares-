#include "PeerScore.hpp"
#include <algorithm>

int PeerScore::calculate(const PeerMetrics& p)
{
    int score = 0;
    score += std::min(p.downloadRate / 1024, 400);
    score += std::min(p.uploadRate / 2048, 100);
    score += std::max(0, 120 - p.latencyMs / 4);
    if (p.hasRarePieces) score += 80;
    if (p.interested) score += 30;
    if (p.chokingUs) score -= 120;
    if (p.weChoke) score -= 20;
    score -= p.failedPieces * 50;
    return std::clamp(score, 0, 1000);
}
