#pragma once
#include <QString>
#include <QStringList>

class PathTools
{
public:
    // Root paths only, used by QML/legacy callers.
    static QStringList availableDownloadRoots();

    // Human-readable rows for the Widgets UI. The real path is kept as combobox item data there.
    static QString driveLabelForRoot(const QString& rootPath);
    static QString defaultDownloadFolderOnRoot(const QString& rootPath);
    static QString displayBytes(qint64 bytesPerSecond);
    static QString displaySize(qint64 bytes);
};
