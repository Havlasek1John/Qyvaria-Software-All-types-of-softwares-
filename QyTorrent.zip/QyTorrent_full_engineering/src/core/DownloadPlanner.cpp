#include "DownloadPlanner.hpp"
#include <QDir>
#include <QFileInfo>
#include <QUrl>

QString DownloadPlanner::normalizeLocalPath(QString pathOrUrl)
{
    if (pathOrUrl.startsWith("file://")) {
        return QUrl(pathOrUrl).toLocalFile();
    }
    return pathOrUrl;
}

bool DownloadPlanner::ensureDownloadDirectory(const QString& path, QString* error)
{
    if (path.trimmed().isEmpty()) {
        if (error) *error = "Choose a download folder before starting.";
        return false;
    }
    QDir dir(path);
    if (!dir.exists() && !dir.mkpath(".")) {
        if (error) *error = "Could not create download folder: " + path;
        return false;
    }
    QFileInfo info(path);
    if (!info.isDir() || !info.isWritable()) {
        if (error) *error = "Download folder is not writable: " + path;
        return false;
    }
    return true;
}

bool DownloadPlanner::looksLikeMagnet(const QString& text)
{
    return text.trimmed().startsWith("magnet:?", Qt::CaseInsensitive);
}

QString DownloadPlanner::defaultNameForSource(const QString& source)
{
    if (looksLikeMagnet(source)) return "Magnet download";
    return QFileInfo(source).completeBaseName();
}
