#pragma once
#include <QObject>
#include <QTimer>
#include "TorrentItem.hpp"

class TorrentSession;

class QyBoostEngine : public QObject
{
    Q_OBJECT
public:
    explicit QyBoostEngine(TorrentSession* session, QObject* parent = nullptr);
    void start();
    void stop();

    Q_INVOKABLE void setAggressiveness(int value);
    int aggressiveness() const { return m_aggressiveness; }

private slots:
    void tick();

private:
    TorrentSession* m_session = nullptr;
    QTimer m_timer;
    int m_aggressiveness = 65;
};
