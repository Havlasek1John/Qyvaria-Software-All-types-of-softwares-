#include "TorrentModel.hpp"

TorrentModel::TorrentModel(QObject* parent) : QAbstractListModel(parent) {}

int TorrentModel::rowCount(const QModelIndex& parent) const
{
    if (parent.isValid()) return 0;
    return m_items.size();
}

QVariant TorrentModel::data(const QModelIndex& index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_items.size()) return {};
    auto* t = m_items[index.row()];
    switch (role) {
    case IdRole: return t->id();
    case NameRole: return t->name();
    case SavePathRole: return t->savePath();
    case StateRole: return t->state();
    case TrackerStatusRole: return t->trackerStatus();
    case ProgressRole: return t->progress();
    case RatioRole: return t->ratio();
    case SeedersRole: return t->seeders();
    case LeechersRole: return t->leechers();
    case PeersRole: return t->peers();
    case DownloadRateRole: return t->downloadRate();
    case UploadRateRole: return t->uploadRate();
    case UploadLimitRole: return t->uploadLimit();
    case DownloadLimitRole: return t->downloadLimit();
    case BoostRole: return t->boostEnabled();
    case SequentialRole: return t->sequential();
    case ModeRole: return t->mode();
    default: return {};
    }
}

QHash<int, QByteArray> TorrentModel::roleNames() const
{
    return {
        {IdRole, "torrentId"}, {NameRole, "name"}, {SavePathRole, "savePath"},
        {StateRole, "state"}, {TrackerStatusRole, "trackerStatus"},
        {ProgressRole, "progress"}, {RatioRole, "ratio"},
        {SeedersRole, "seeders"}, {LeechersRole, "leechers"}, {PeersRole, "peers"},
        {DownloadRateRole, "downloadRate"}, {UploadRateRole, "uploadRate"},
        {UploadLimitRole, "uploadLimit"}, {DownloadLimitRole, "downloadLimit"},
        {BoostRole, "boostEnabled"}, {SequentialRole, "sequential"}, {ModeRole, "mode"}
    };
}

TorrentItem* TorrentModel::getById(const QString& id) const
{
    for (auto* item : m_items) if (item->id() == id) return item;
    return nullptr;
}

TorrentItem* TorrentModel::at(int row) const
{
    if (row < 0 || row >= m_items.size()) return nullptr;
    return m_items[row];
}

void TorrentModel::addItem(TorrentItem* item)
{
    beginInsertRows({}, m_items.size(), m_items.size());
    m_items.push_back(item);
    connect(item, &TorrentItem::changed, this, [this, item] {
        const int row = m_items.indexOf(item);
        if (row >= 0) emit dataChanged(index(row), index(row));
    });
    endInsertRows();
}

void TorrentModel::removeById(const QString& id)
{
    for (int i = 0; i < m_items.size(); ++i) {
        if (m_items[i]->id() == id) {
            beginRemoveRows({}, i, i);
            auto* item = m_items.takeAt(i);
            item->deleteLater();
            endRemoveRows();
            return;
        }
    }
}
