#include "QyBoostEngine.hpp"
#include "TorrentSession.hpp"

QyBoostEngine::QyBoostEngine(TorrentSession* session, QObject* parent)
    : QObject(parent), m_session(session)
{
    m_timer.setInterval(1500);
    connect(&m_timer, &QTimer::timeout, this, &QyBoostEngine::tick);
}

void QyBoostEngine::start() { m_timer.start(); }
void QyBoostEngine::stop() { m_timer.stop(); }
void QyBoostEngine::setAggressiveness(int value) { m_aggressiveness = std::clamp(value, 0, 100); }

void QyBoostEngine::tick()
{
    if (!m_session) return;
    m_session->runBoostCycle(m_aggressiveness);
}
