#pragma once
#include <QAbstractListModel>
#include <QVector>
#include "TorrentItem.hpp"

class TorrentModel : public QAbstractListModel
{
    Q_OBJECT
public:
    enum Roles {
        IdRole = Qt::UserRole + 1,
        NameRole,
        SavePathRole,
        StateRole,
        TrackerStatusRole,
        ProgressRole,
        RatioRole,
        SeedersRole,
        LeechersRole,
        PeersRole,
        DownloadRateRole,
        UploadRateRole,
        UploadLimitRole,
        DownloadLimitRole,
        BoostRole,
        SequentialRole,
        ModeRole
    };

    explicit TorrentModel(QObject* parent = nullptr);

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;
    QVariant data(const QModelIndex& index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    TorrentItem* getById(const QString& id) const;
    TorrentItem* at(int row) const;
    void addItem(TorrentItem* item);
    void removeById(const QString& id);

private:
    QVector<TorrentItem*> m_items;
};
