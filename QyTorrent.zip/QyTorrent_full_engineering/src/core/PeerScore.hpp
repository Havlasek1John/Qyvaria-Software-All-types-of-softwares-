#pragma once
#include <QString>

struct PeerMetrics
{
    QString endpoint;
    int downloadRate = 0;
    int uploadRate = 0;
    int latencyMs = 1000;
    int failedPieces = 0;
    bool interested = false;
    bool chokingUs = false;
    bool weChoke = false;
    bool hasRarePieces = false;
};

class PeerScore
{
public:
    static int calculate(const PeerMetrics& p);
};
