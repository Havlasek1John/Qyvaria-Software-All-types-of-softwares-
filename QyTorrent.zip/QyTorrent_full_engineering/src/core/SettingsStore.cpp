#include "SettingsStore.hpp"
#include <QStandardPaths>
#include <QDir>

SettingsStore::SettingsStore(QObject* parent)
    : QObject(parent), m_settings("Qyvaria", "QyTorrent")
{
    if (defaultDownloadPath().isEmpty()) {
        auto fallback = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
        if (fallback.isEmpty()) fallback = QDir::homePath();
        setDefaultDownloadPath(fallback + "/QyTorrent");
    }
    if (speedProfile().isEmpty()) {
        setSpeedProfile("High throughput");
    }
}

QString SettingsStore::defaultDownloadPath() const { return m_settings.value("download/defaultPath").toString(); }
QStringList SettingsStore::recentDownloadPaths() const { return m_settings.value("download/recentPaths").toStringList(); }
int SettingsStore::globalUploadLimit() const { return m_settings.value("network/globalUploadLimit", 0).toInt(); }
int SettingsStore::globalDownloadLimit() const { return m_settings.value("network/globalDownloadLimit", 0).toInt(); }
QString SettingsStore::speedProfile() const { return m_settings.value("network/speedProfile", "High throughput").toString(); }
bool SettingsStore::darkMode() const { return m_settings.value("ui/darkMode", true).toBool(); }
bool SettingsStore::webApiEnabled() const { return m_settings.value("web/enabled", false).toBool(); }
int SettingsStore::webApiPort() const { return m_settings.value("web/port", 47891).toInt(); }

void SettingsStore::setDefaultDownloadPath(const QString& path) {
    const QString clean = QDir::cleanPath(path);
    m_settings.setValue("download/defaultPath", clean);
    addRecentDownloadPath(clean);
    emit changed();
}

void SettingsStore::addRecentDownloadPath(const QString& path) {
    const QString clean = QDir::cleanPath(path.trimmed());
    if (clean.isEmpty()) return;
    QStringList paths = recentDownloadPaths();
    paths.removeAll(clean);
    paths.prepend(clean);
    while (paths.size() > 12) paths.removeLast();
    m_settings.setValue("download/recentPaths", paths);
}

void SettingsStore::setGlobalUploadLimit(int v) { m_settings.setValue("network/globalUploadLimit", v); emit changed(); }
void SettingsStore::setGlobalDownloadLimit(int v) { m_settings.setValue("network/globalDownloadLimit", v); emit changed(); }
void SettingsStore::setSpeedProfile(const QString& v) { m_settings.setValue("network/speedProfile", v); emit changed(); }
void SettingsStore::setDarkMode(bool v) { m_settings.setValue("ui/darkMode", v); emit changed(); }
void SettingsStore::setWebApiEnabled(bool v) { m_settings.setValue("web/enabled", v); emit changed(); }
void SettingsStore::setWebApiPort(int v) { m_settings.setValue("web/port", v); emit changed(); }
