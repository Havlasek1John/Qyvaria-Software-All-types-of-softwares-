#pragma once
#include <QObject>
#include <QHash>
#include <QTimer>
#include <QStringList>
#include "TorrentModel.hpp"
#include "DownloadPlanner.hpp"

#if QYTORRENT_HAS_LIBTORRENT
#include <libtorrent/session.hpp>
#include <libtorrent/torrent_handle.hpp>
#include <libtorrent/alert.hpp>
#endif

class SettingsStore;
class QyBoostEngine;

class TorrentSession : public QObject
{
    Q_OBJECT
    Q_PROPERTY(TorrentModel* model READ model CONSTANT)
    Q_PROPERTY(QString lastError READ lastError NOTIFY lastErrorChanged)
    Q_PROPERTY(QStringList downloadRoots READ downloadRoots NOTIFY downloadRootsChanged)

public:
    explicit TorrentSession(SettingsStore* settings, QObject* parent = nullptr);
    ~TorrentSession() override;

    TorrentModel* model() { return &m_model; }
    QString lastError() const { return m_lastError; }
    QStringList downloadRoots() const;

    void start();
    void stop();

    Q_INVOKABLE QString addTorrentFile(const QString& torrentFileUrlOrPath,
                                       const QString& savePathUrlOrPath,
                                       bool boost,
                                       bool sequential,
                                       const QString& mode,
                                       int uploadLimit,
                                       int downloadLimit);

    Q_INVOKABLE QString addMagnet(const QString& magnet,
                                  const QString& savePathUrlOrPath,
                                  bool boost,
                                  bool sequential,
                                  const QString& mode,
                                  int uploadLimit,
                                  int downloadLimit);

    Q_INVOKABLE void pauseTorrent(const QString& id);
    Q_INVOKABLE void resumeTorrent(const QString& id);
    Q_INVOKABLE void removeTorrent(const QString& id, bool deleteFiles);
    Q_INVOKABLE void setTorrentLimits(const QString& id, int uploadLimit, int downloadLimit);
    Q_INVOKABLE void setGlobalLimits(int uploadLimit, int downloadLimit);
    Q_INVOKABLE void setPerformanceProfile(const QString& profile);
    Q_INVOKABLE void setBoostEnabled(const QString& id, bool enabled);
    Q_INVOKABLE void setSequential(const QString& id, bool enabled);
    Q_INVOKABLE void setFilePriority(const QString& id, int fileIndex, int priority);
    Q_INVOKABLE QVariantList peersFor(const QString& id) const;
    Q_INVOKABLE QVariantList filesFor(const QString& id) const;

    void runBoostCycle(int aggressiveness);

signals:
    void lastErrorChanged();
    void downloadRootsChanged();

private slots:
    void poll();

private:
    QString addTorrent(const AddTorrentRequest& request);
    void setError(const QString& error);
    QString makeId(const QString& seed) const;
    void updateItemFromBackend(const QString& id);
    void applyInitialOptions(const QString& id, const AddTorrentRequest& request);
    void applyPerformanceProfile(const QString& profile);

    SettingsStore* m_settings = nullptr;
    TorrentModel m_model;
    QyBoostEngine* m_boost = nullptr;
    QTimer m_pollTimer;
    QString m_lastError;

#if QYTORRENT_HAS_LIBTORRENT
    lt::session m_session;
    QHash<QString, lt::torrent_handle> m_handles;
#endif
};
