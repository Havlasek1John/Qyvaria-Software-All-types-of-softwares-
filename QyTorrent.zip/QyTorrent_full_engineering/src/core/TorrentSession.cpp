#include "TorrentSession.hpp"
#include "SettingsStore.hpp"
#include "QyBoostEngine.hpp"
#include "PathTools.hpp"

#include <QCryptographicHash>
#include <QDateTime>
#include <QFileInfo>
#include <QUrl>
#include <QVariantMap>
#include <QDir>

#if QYTORRENT_HAS_LIBTORRENT
#include <libtorrent/add_torrent_params.hpp>
#include <libtorrent/magnet_uri.hpp>
#include <libtorrent/torrent_info.hpp>
#include <libtorrent/alert_types.hpp>
#include <libtorrent/settings_pack.hpp>
#endif

#if QYTORRENT_HAS_LIBTORRENT
namespace {
void setIntSettingByName(lt::settings_pack& pack, const char* name, int value)
{
    const int id = lt::setting_by_name(name);
    if (id >= 0) pack.set_int(id, value);
}

void setBoolSettingByName(lt::settings_pack& pack, const char* name, bool value)
{
    const int id = lt::setting_by_name(name);
    if (id >= 0) pack.set_bool(id, value);
}
}
#endif

TorrentSession::TorrentSession(SettingsStore* settings, QObject* parent)
    : QObject(parent), m_settings(settings), m_boost(new QyBoostEngine(this, this))
{
    m_pollTimer.setInterval(1000);
    connect(&m_pollTimer, &QTimer::timeout, this, &TorrentSession::poll);
    if (m_settings) {
        connect(m_settings, &SettingsStore::changed, this, [this] {
            applyPerformanceProfile(m_settings->speedProfile());
            setGlobalLimits(m_settings->globalUploadLimit(), m_settings->globalDownloadLimit());
        });
    }
}

TorrentSession::~TorrentSession()
{
    stop();
}

void TorrentSession::start()
{
#if QYTORRENT_HAS_LIBTORRENT
    lt::settings_pack pack;
    pack.set_int(lt::settings_pack::alert_mask,
        lt::alert::error_notification |
        lt::alert::storage_notification |
        lt::alert::status_notification |
        lt::alert::tracker_notification |
        lt::alert::connect_notification |
        lt::alert::peer_notification);
    pack.set_bool(lt::settings_pack::enable_dht, true);
    pack.set_bool(lt::settings_pack::enable_lsd, true);
    pack.set_bool(lt::settings_pack::enable_outgoing_utp, true);
    pack.set_bool(lt::settings_pack::enable_incoming_utp, true);
    m_session.apply_settings(pack);
#endif
    applyPerformanceProfile(m_settings ? m_settings->speedProfile() : QString("High throughput"));
    if (m_settings) setGlobalLimits(m_settings->globalUploadLimit(), m_settings->globalDownloadLimit());
    m_pollTimer.start();
    m_boost->start();
}

void TorrentSession::stop()
{
    m_boost->stop();
    m_pollTimer.stop();
#if QYTORRENT_HAS_LIBTORRENT
    for (auto it = m_handles.begin(); it != m_handles.end(); ++it) {
        if (it.value().is_valid()) it.value().pause();
    }
#endif
}

QStringList TorrentSession::downloadRoots() const
{
    return PathTools::availableDownloadRoots();
}

QString TorrentSession::addTorrentFile(const QString& torrentFileUrlOrPath, const QString& savePathUrlOrPath,
                                       bool boost, bool sequential, const QString& mode,
                                       int uploadLimit, int downloadLimit)
{
    AddTorrentRequest req;
    req.source = DownloadPlanner::normalizeLocalPath(torrentFileUrlOrPath);
    req.savePath = DownloadPlanner::normalizeLocalPath(savePathUrlOrPath);
    req.sourceIsMagnet = false;
    req.boost = boost;
    req.sequential = sequential;
    req.mode = mode;
    req.uploadLimit = uploadLimit;
    req.downloadLimit = downloadLimit;
    return addTorrent(req);
}

QString TorrentSession::addMagnet(const QString& magnet, const QString& savePathUrlOrPath,
                                  bool boost, bool sequential, const QString& mode,
                                  int uploadLimit, int downloadLimit)
{
    AddTorrentRequest req;
    req.source = magnet.trimmed();
    req.savePath = DownloadPlanner::normalizeLocalPath(savePathUrlOrPath);
    req.sourceIsMagnet = true;
    req.boost = boost;
    req.sequential = sequential;
    req.mode = mode;
    req.uploadLimit = uploadLimit;
    req.downloadLimit = downloadLimit;
    return addTorrent(req);
}

QString TorrentSession::addTorrent(const AddTorrentRequest& request)
{
    QString error;
    if (!DownloadPlanner::ensureDownloadDirectory(request.savePath, &error)) {
        setError(error);
        return {};
    }

    if (request.sourceIsMagnet && !DownloadPlanner::looksLikeMagnet(request.source)) {
        setError("Paste a valid magnet link.");
        return {};
    }

    if (!request.sourceIsMagnet && !QFileInfo::exists(request.source)) {
        setError("Torrent file does not exist: " + request.source);
        return {};
    }

    const QString id = makeId(request.source + request.savePath + QString::number(QDateTime::currentMSecsSinceEpoch()));
    auto* item = new TorrentItem(id, &m_model);
    item->setName(DownloadPlanner::defaultNameForSource(request.source));
    item->setSavePath(request.savePath);
    item->setBoostEnabled(request.boost);
    item->setSequential(request.sequential);
    item->setMode(request.mode);
    item->setUploadLimit(request.uploadLimit);
    item->setDownloadLimit(request.downloadLimit);
    item->setState("starting");
    item->setTrackerStatus("adding");
    m_model.addItem(item);

#if QYTORRENT_HAS_LIBTORRENT
    try {
        lt::add_torrent_params p;
        p.save_path = request.savePath.toStdString();
        p.flags |= lt::torrent_flags::auto_managed;
        if (request.sequential) p.flags |= lt::torrent_flags::sequential_download;

        if (request.sourceIsMagnet) {
            p = lt::parse_magnet_uri(request.source.toStdString());
            p.save_path = request.savePath.toStdString();
        } else {
            p.ti = std::make_shared<lt::torrent_info>(request.source.toStdString());
        }

        auto handle = m_session.add_torrent(p);
        m_handles.insert(id, handle);
        applyInitialOptions(id, request);
    } catch (const std::exception& e) {
        m_model.removeById(id);
        setError(QString("libtorrent add failed: ") + e.what());
        return {};
    }
#else
    Q_UNUSED(request)
#endif

    return id;
}

void TorrentSession::applyInitialOptions(const QString& id, const AddTorrentRequest& request)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto handle = m_handles.value(id);
    if (!handle.is_valid()) return;
    handle.set_upload_limit(request.uploadLimit);
    handle.set_download_limit(request.downloadLimit);
    if (request.sequential) handle.set_flags(lt::torrent_flags::sequential_download);
    else handle.unset_flags(lt::torrent_flags::sequential_download);
#endif
    if (auto* item = m_model.getById(id)) {
        item->setUploadLimit(request.uploadLimit);
        item->setDownloadLimit(request.downloadLimit);
        item->setSequential(request.sequential);
        item->setBoostEnabled(request.boost);
        item->setMode(request.mode);
    }
}

void TorrentSession::pauseTorrent(const QString& id)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto h = m_handles.value(id); if (h.is_valid()) h.pause();
#endif
    if (auto* item = m_model.getById(id)) item->setState("paused");
}

void TorrentSession::resumeTorrent(const QString& id)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto h = m_handles.value(id); if (h.is_valid()) h.resume();
#endif
    if (auto* item = m_model.getById(id)) item->setState("downloading");
}

void TorrentSession::removeTorrent(const QString& id, bool deleteFiles)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto h = m_handles.take(id);
    if (h.is_valid()) {
        m_session.remove_torrent(h, deleteFiles ? lt::session::delete_files : lt::session::delete_partfile);
    }
#else
    Q_UNUSED(deleteFiles)
#endif
    m_model.removeById(id);
}

void TorrentSession::setTorrentLimits(const QString& id, int uploadLimit, int downloadLimit)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto h = m_handles.value(id);
    if (h.is_valid()) {
        h.set_upload_limit(uploadLimit);
        h.set_download_limit(downloadLimit);
    }
#endif
    if (auto* item = m_model.getById(id)) {
        item->setUploadLimit(uploadLimit);
        item->setDownloadLimit(downloadLimit);
    }
}

void TorrentSession::setPerformanceProfile(const QString& profile)
{
    if (m_settings && m_settings->speedProfile() != profile) {
        m_settings->setSpeedProfile(profile);
    }
    applyPerformanceProfile(profile);
}

void TorrentSession::applyPerformanceProfile(const QString& profile)
{
#if QYTORRENT_HAS_LIBTORRENT
    lt::settings_pack p;

    // These are safe, legal performance settings. They do not bypass tracker rules,
    // do not spoof ratio, and do not force other peers to upload. They only let a
    // healthy swarm, fast disk, and good connection perform closer to their limit.
    if (profile == "Extreme / 100MB+ capable") {
        setIntSettingByName(p, "connections_limit", 1200);
        setIntSettingByName(p, "active_limit", 200);
        setIntSettingByName(p, "active_downloads", 50);
        setIntSettingByName(p, "active_seeds", 200);
        setIntSettingByName(p, "connection_speed", 80);
        setIntSettingByName(p, "torrent_connect_boost", 80);
        setIntSettingByName(p, "num_want", 200);
        setIntSettingByName(p, "max_peerlist_size", 6000);
        setIntSettingByName(p, "request_timeout", 35);
        setIntSettingByName(p, "peer_timeout", 90);
        setIntSettingByName(p, "inactivity_timeout", 120);
        setIntSettingByName(p, "max_out_request_queue", 1500);
        setIntSettingByName(p, "max_allowed_in_request_queue", 3000);
        setIntSettingByName(p, "aio_threads", 8);
        setIntSettingByName(p, "hashing_threads", 4);
        setIntSettingByName(p, "file_pool_size", 400);
        setIntSettingByName(p, "send_socket_buffer_size", 4 * 1024 * 1024);
        setIntSettingByName(p, "recv_socket_buffer_size", 4 * 1024 * 1024);
        setIntSettingByName(p, "send_buffer_watermark", 4 * 1024 * 1024);
        setIntSettingByName(p, "send_buffer_low_watermark", 512 * 1024);
        setIntSettingByName(p, "unchoke_slots_limit", 64);
        setBoolSettingByName(p, "allow_multiple_connections_per_ip", true);
    } else if (profile == "High throughput") {
        setIntSettingByName(p, "connections_limit", 700);
        setIntSettingByName(p, "active_limit", 100);
        setIntSettingByName(p, "active_downloads", 25);
        setIntSettingByName(p, "active_seeds", 100);
        setIntSettingByName(p, "connection_speed", 50);
        setIntSettingByName(p, "torrent_connect_boost", 60);
        setIntSettingByName(p, "num_want", 160);
        setIntSettingByName(p, "max_peerlist_size", 4000);
        setIntSettingByName(p, "request_timeout", 45);
        setIntSettingByName(p, "peer_timeout", 100);
        setIntSettingByName(p, "inactivity_timeout", 180);
        setIntSettingByName(p, "max_out_request_queue", 1000);
        setIntSettingByName(p, "max_allowed_in_request_queue", 2500);
        setIntSettingByName(p, "aio_threads", 6);
        setIntSettingByName(p, "hashing_threads", 2);
        setIntSettingByName(p, "file_pool_size", 250);
        setIntSettingByName(p, "send_socket_buffer_size", 2 * 1024 * 1024);
        setIntSettingByName(p, "recv_socket_buffer_size", 2 * 1024 * 1024);
        setIntSettingByName(p, "send_buffer_watermark", 2 * 1024 * 1024);
        setIntSettingByName(p, "send_buffer_low_watermark", 256 * 1024);
        setIntSettingByName(p, "unchoke_slots_limit", 32);
    } else {
        setIntSettingByName(p, "connections_limit", 350);
        setIntSettingByName(p, "active_limit", 50);
        setIntSettingByName(p, "active_downloads", 10);
        setIntSettingByName(p, "active_seeds", 50);
        setIntSettingByName(p, "connection_speed", 30);
        setIntSettingByName(p, "torrent_connect_boost", 30);
        setIntSettingByName(p, "num_want", 100);
        setIntSettingByName(p, "max_peerlist_size", 3000);
        setIntSettingByName(p, "request_timeout", 60);
        setIntSettingByName(p, "peer_timeout", 120);
        setIntSettingByName(p, "inactivity_timeout", 300);
        setIntSettingByName(p, "aio_threads", 4);
        setIntSettingByName(p, "hashing_threads", 1);
        setIntSettingByName(p, "file_pool_size", 100);
        setIntSettingByName(p, "unchoke_slots_limit", 16);
    }

    m_session.apply_settings(p);
#else
    Q_UNUSED(profile)
#endif
}

void TorrentSession::setGlobalLimits(int uploadLimit, int downloadLimit)
{
#if QYTORRENT_HAS_LIBTORRENT
    lt::settings_pack p;
    p.set_int(lt::settings_pack::upload_rate_limit, uploadLimit);
    p.set_int(lt::settings_pack::download_rate_limit, downloadLimit);
    m_session.apply_settings(p);
#endif
}

void TorrentSession::setBoostEnabled(const QString& id, bool enabled)
{
    if (auto* item = m_model.getById(id)) item->setBoostEnabled(enabled);
}

void TorrentSession::setSequential(const QString& id, bool enabled)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto h = m_handles.value(id);
    if (h.is_valid()) {
        if (enabled) h.set_flags(lt::torrent_flags::sequential_download);
        else h.unset_flags(lt::torrent_flags::sequential_download);
    }
#endif
    if (auto* item = m_model.getById(id)) item->setSequential(enabled);
}

void TorrentSession::setFilePriority(const QString& id, int fileIndex, int priority)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto h = m_handles.value(id);
    if (h.is_valid()) h.file_priority(lt::file_index_t(fileIndex), lt::download_priority_t(priority));
#else
    Q_UNUSED(id); Q_UNUSED(fileIndex); Q_UNUSED(priority)
#endif
}

QVariantList TorrentSession::peersFor(const QString& id) const
{
    QVariantList list;
    auto* item = m_model.getById(id);
    if (!item) return list;
    for (const auto& p : item->peerViews()) {
        QVariantMap m;
        m["address"] = p.address;
        m["downloadRate"] = p.downloadRate;
        m["uploadRate"] = p.uploadRate;
        m["score"] = p.score;
        m["choked"] = p.choked;
        list << m;
    }
    return list;
}

QVariantList TorrentSession::filesFor(const QString& id) const
{
    QVariantList list;
    auto* item = m_model.getById(id);
    if (!item) return list;
    int index = 0;
    for (const auto& f : item->files()) {
        QVariantMap m;
        m["index"] = index++;
        m["path"] = f.path;
        m["size"] = f.size;
        m["priority"] = f.priority;
        list << m;
    }
    return list;
}

void TorrentSession::runBoostCycle(int aggressiveness)
{
#if QYTORRENT_HAS_LIBTORRENT
    for (auto it = m_handles.begin(); it != m_handles.end(); ++it) {
        auto* item = m_model.getById(it.key());
        auto h = it.value();
        if (!item || !h.is_valid() || !item->boostEnabled()) continue;

        auto st = h.status();
        const bool activeDownload = !st.is_seeding && !st.paused;
        if (!activeDownload && item->mode() != "Seed Forever" && item->mode() != "Ratio Builder") continue;

        int baseUpload = item->uploadLimit();
        if (baseUpload <= 0 && m_settings) baseUpload = m_settings->globalUploadLimit();
        if (baseUpload <= 0) baseUpload = (aggressiveness >= 80 ? 0 : 4 * 1024 * 1024);

        int tunedUpload = baseUpload;
        if (item->mode() == "Fast Download") tunedUpload = int(baseUpload * 0.85);
        if (item->mode() == "Ratio Builder") tunedUpload = int(baseUpload * 1.15);
        if (item->mode() == "Seed Forever") tunedUpload = int(baseUpload * 1.25);
        if (baseUpload == 0) tunedUpload = 0;

        h.set_upload_limit(tunedUpload);

        const QString profile = m_settings ? m_settings->speedProfile() : QString("High throughput");
        if (profile == "Extreme / 100MB+ capable") {
            h.set_max_connections(aggressiveness >= 80 ? 600 : 400);
            h.set_max_uploads(aggressiveness >= 80 ? 64 : 40);
        } else if (profile == "High throughput") {
            h.set_max_connections(aggressiveness >= 80 ? 400 : 250);
            h.set_max_uploads(aggressiveness >= 80 ? 40 : 24);
        } else {
            h.set_max_connections(aggressiveness >= 80 ? 250 : 120);
            h.set_max_uploads(aggressiveness >= 80 ? 24 : 12);
        }

        // Keep rare-piece value high. Sequential mode is user-controlled and not forced here.
        if (!item->sequential()) {
            h.unset_flags(lt::torrent_flags::sequential_download);
        }
    }
#else
    Q_UNUSED(aggressiveness)
    for (int i = 0; i < m_model.rowCount(); ++i) {
        auto* item = m_model.at(i);
        if (!item || !item->boostEnabled()) continue;
        if (item->state() == "paused") continue;
        item->setUploadRate(std::max(item->uploadRate(), 512 * 1024));
        item->setTrackerStatus("boost active");
    }
#endif
}

void TorrentSession::poll()
{
#if QYTORRENT_HAS_LIBTORRENT
    std::vector<lt::alert*> alerts;
    m_session.pop_alerts(&alerts);
    for (auto* alert : alerts) {
        if (auto* a = lt::alert_cast<lt::torrent_error_alert>(alert)) {
            Q_UNUSED(a)
            setError(QString::fromStdString(alert->message()));
        }
        if (auto* a = lt::alert_cast<lt::tracker_reply_alert>(alert)) {
            Q_UNUSED(a)
        }
    }
    for (auto it = m_handles.begin(); it != m_handles.end(); ++it) {
        updateItemFromBackend(it.key());
    }
#else
    for (int i = 0; i < m_model.rowCount(); ++i) {
        auto* item = m_model.at(i);
        if (!item || item->state() == "paused") continue;
        item->setState(item->progress() >= 1.0 ? "seeding" : "downloading");
        item->setProgress(std::min(1.0, item->progress() + 0.002));
        item->setDownloadRate(item->progress() < 1.0 ? 2 * 1024 * 1024 : 0);
        item->setUploadRate(item->boostEnabled() ? 1024 * 1024 : 128 * 1024);
        item->setSeeders(128);
        item->setLeechers(23);
        item->setPeers(42);
        item->setRatio(item->ratio() + 0.001);
        item->setTrackerStatus(item->boostEnabled() ? "boost active" : "working");
    }
#endif
}

void TorrentSession::updateItemFromBackend(const QString& id)
{
#if QYTORRENT_HAS_LIBTORRENT
    auto h = m_handles.value(id);
    auto* item = m_model.getById(id);
    if (!item || !h.is_valid()) return;

    auto st = h.status();
    item->setName(QString::fromStdString(st.name));
    item->setProgress(st.progress);
    item->setDownloadRate(st.download_rate);
    item->setUploadRate(st.upload_rate);
    item->setRatio(st.total_done > 0 ? double(st.total_upload) / double(st.total_done) : 0.0);
    item->setSeeders(st.num_seeds);
    item->setPeers(st.num_peers);
    item->setLeechers(std::max(0, st.list_peers - st.num_seeds));

    QString state = "unknown";
    switch (st.state) {
    case lt::torrent_status::checking_files: state = "checking"; break;
    case lt::torrent_status::downloading_metadata: state = "metadata"; break;
    case lt::torrent_status::downloading: state = "downloading"; break;
    case lt::torrent_status::finished: state = "finished"; break;
    case lt::torrent_status::seeding: state = "seeding"; break;
    case lt::torrent_status::allocating: state = "allocating"; break;
    case lt::torrent_status::checking_resume_data: state = "resume check"; break;
    default: break;
    }
    if (st.paused) state = "paused";
    item->setState(state);
    item->setTrackerStatus(st.errc ? QString::fromStdString(st.errc.message()) : "working");

    std::vector<lt::peer_info> peers;
    h.get_peer_info(peers);
    QVector<PeerView> views;
    for (const auto& p : peers) {
        PeerView v;
        v.address = QString::fromStdString(p.ip.address().to_string());
        v.downloadRate = p.down_speed;
        v.uploadRate = p.up_speed;
        v.choked = p.flags & lt::peer_info::choked;
        v.score = std::clamp((p.down_speed / 1024) + (p.up_speed / 2048), 0, 1000);
        views.push_back(v);
    }
    item->setPeerViews(views);

    QVector<FileEntryView> files;
    if (h.torrent_file()) {
        auto ti = h.torrent_file();
        auto fs = ti->files();
        for (lt::file_index_t i(0); i < fs.num_files(); ++i) {
            FileEntryView f;
            f.path = QString::fromStdString(fs.file_path(i));
            f.size = fs.file_size(i);
            f.priority = int(h.file_priority(i));
            files.push_back(f);
        }
    }
    item->setFiles(files);
#else
    Q_UNUSED(id)
#endif
}

void TorrentSession::setError(const QString& error)
{
    m_lastError = error;
    emit lastErrorChanged();
}

QString TorrentSession::makeId(const QString& seed) const
{
    return QCryptographicHash::hash(seed.toUtf8(), QCryptographicHash::Sha1).toHex();
}
