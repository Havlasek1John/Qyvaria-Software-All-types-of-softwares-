#include <QApplication>
#include <QIcon>
#include <QDir>

#include "core/TorrentSession.hpp"
#include "core/SettingsStore.hpp"
#include "web/WebApi.hpp"
#include "ui/MainWindow.hpp"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName("QyTorrent");
    QApplication::setApplicationDisplayName("QyTorrent");
    QApplication::setOrganizationName("Qyvaria");
    QApplication::setWindowIcon(QIcon::fromTheme("qytorrent"));

    SettingsStore settings;
    TorrentSession session(&settings);
    session.start();

    WebApi webApi(&session, &settings);
    if (settings.webApiEnabled()) {
        webApi.start(settings.webApiPort());
    }

    MainWindow window(&session, &settings);
    window.show();

    return app.exec();
}
