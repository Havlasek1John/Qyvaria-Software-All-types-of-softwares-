#include "MainWindow.hpp"

#include "core/TorrentSession.hpp"
#include "core/TorrentModel.hpp"
#include "core/SettingsStore.hpp"
#include "core/DownloadPlanner.hpp"
#include "core/PathTools.hpp"

#include <QApplication>
#include <QBoxLayout>
#include <QCheckBox>
#include <QColor>
#include <QComboBox>
#include <QDesktopServices>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QFileDialog>
#include <QFormLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QInputDialog>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPalette>
#include <QProgressBar>
#include <QPushButton>
#include <QSpinBox>
#include <QStandardPaths>
#include <QStorageInfo>
#include <QTableWidget>
#include <QTextEdit>
#include <QUrl>
#include <QVariant>
#include <QVector>

MainWindow::MainWindow(TorrentSession* session, SettingsStore* settings, QWidget* parent)
    : QMainWindow(parent), m_session(session), m_settings(settings)
{
    setupUi();
    applyDarkTheme();

    connect(&m_refreshTimer, &QTimer::timeout, this, &MainWindow::refreshTable);
    m_refreshTimer.start(1000);

    if (m_session) {
        connect(m_session, &TorrentSession::lastErrorChanged, this, &MainWindow::showError);
        connect(m_session->model(), &QAbstractItemModel::rowsInserted, this, &MainWindow::refreshTable);
        connect(m_session->model(), &QAbstractItemModel::rowsRemoved, this, &MainWindow::refreshTable);
        connect(m_session->model(), &QAbstractItemModel::dataChanged, this, &MainWindow::refreshTable);
    }

    refreshTable();
}

void MainWindow::setupUi()
{
    setWindowTitle("QyTorrent");
    resize(1180, 720);

    auto* root = new QWidget(this);
    auto* main = new QVBoxLayout(root);
    main->setContentsMargins(14, 14, 14, 14);
    main->setSpacing(10);

    auto* titleRow = new QHBoxLayout();
    auto* title = new QLabel("<b style='font-size:22px'>QyTorrent</b><br><span style='color:#9aa4b2'>Share smarter. Download faster.</span>");
    titleRow->addWidget(title);
    titleRow->addStretch();

    auto* addFileBtn = new QPushButton("Add .torrent");
    auto* addMagnetBtn = new QPushButton("Add magnet");
    auto* folderBtn = new QPushButton("Download folder");
    titleRow->addWidget(addFileBtn);
    titleRow->addWidget(addMagnetBtn);
    titleRow->addWidget(folderBtn);
    main->addLayout(titleRow);

    auto* controls = new QGroupBox("Global speed and performance");
    auto* controlsLayout = new QHBoxLayout(controls);
    m_globalUpload = new QSpinBox();
    m_globalUpload->setRange(0, 1000000);
    m_globalUpload->setSuffix(" KB/s up");
    m_globalUpload->setSpecialValueText("Unlimited upload");
    m_globalUpload->setValue(m_settings ? m_settings->globalUploadLimit() / 1024 : 0);

    m_globalDownload = new QSpinBox();
    m_globalDownload->setRange(0, 1000000);
    m_globalDownload->setSuffix(" KB/s down");
    m_globalDownload->setSpecialValueText("Unlimited download");
    m_globalDownload->setValue(m_settings ? m_settings->globalDownloadLimit() / 1024 : 0);

    m_speedProfile = new QComboBox();
    m_speedProfile->addItems({"Balanced", "High throughput", "Extreme / 100MB+ capable"});
    const QString profile = m_settings ? m_settings->speedProfile() : QString("High throughput");
    const int profileIndex = m_speedProfile->findText(profile);
    if (profileIndex >= 0) m_speedProfile->setCurrentIndex(profileIndex);
    else m_speedProfile->setCurrentText("High throughput");

    auto* applyLimits = new QPushButton("Apply");
    controlsLayout->addWidget(new QLabel("Upload:"));
    controlsLayout->addWidget(m_globalUpload);
    controlsLayout->addWidget(new QLabel("Download:"));
    controlsLayout->addWidget(m_globalDownload);
    controlsLayout->addWidget(new QLabel("Performance:"));
    controlsLayout->addWidget(m_speedProfile);
    controlsLayout->addWidget(applyLimits);
    controlsLayout->addStretch();
    main->addWidget(controls);

    m_table = new QTableWidget(0, 12, this);
    m_table->setHorizontalHeaderLabels({
        "Name", "State", "Progress", "Download", "Upload", "Ratio",
        "Seeders", "Leechers", "Peers", "Boost", "Mode", "Save path"
    });
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->verticalHeader()->setVisible(false);
    m_table->horizontalHeader()->setStretchLastSection(true);
    m_table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(11, QHeaderView::Stretch);
    m_table->setAlternatingRowColors(true);
    main->addWidget(m_table, 1);

    auto* actions = new QHBoxLayout();
    auto* pauseBtn = new QPushButton("Pause");
    auto* resumeBtn = new QPushButton("Resume");
    auto* removeBtn = new QPushButton("Remove");
    auto* detailsBtn = new QPushButton("Peers / Files");
    actions->addWidget(pauseBtn);
    actions->addWidget(resumeBtn);
    actions->addWidget(removeBtn);
    actions->addWidget(detailsBtn);
    actions->addStretch();
    m_status = new QLabel("Ready");
    actions->addWidget(m_status);
    main->addLayout(actions);

    setCentralWidget(root);

    connect(addFileBtn, &QPushButton::clicked, this, &MainWindow::addTorrentFile);
    connect(addMagnetBtn, &QPushButton::clicked, this, &MainWindow::addMagnet);
    connect(folderBtn, &QPushButton::clicked, this, &MainWindow::openDownloadFolder);
    connect(applyLimits, &QPushButton::clicked, this, &MainWindow::applyGlobalLimits);
    connect(pauseBtn, &QPushButton::clicked, this, &MainWindow::pauseSelected);
    connect(resumeBtn, &QPushButton::clicked, this, &MainWindow::resumeSelected);
    connect(removeBtn, &QPushButton::clicked, this, &MainWindow::removeSelected);
    connect(detailsBtn, &QPushButton::clicked, this, &MainWindow::showDetails);
    connect(m_table, &QTableWidget::cellDoubleClicked, this, [this](int, int){ showDetails(); });
}

void MainWindow::applyDarkTheme()
{
    if (!m_settings || !m_settings->darkMode()) return;

    QPalette p;
    p.setColor(QPalette::Window, QColor(18, 22, 30));
    p.setColor(QPalette::WindowText, QColor(230, 235, 245));
    p.setColor(QPalette::Base, QColor(24, 29, 39));
    p.setColor(QPalette::AlternateBase, QColor(30, 36, 48));
    p.setColor(QPalette::ToolTipBase, QColor(230, 235, 245));
    p.setColor(QPalette::ToolTipText, QColor(18, 22, 30));
    p.setColor(QPalette::Text, QColor(230, 235, 245));
    p.setColor(QPalette::Button, QColor(37, 45, 60));
    p.setColor(QPalette::ButtonText, QColor(230, 235, 245));
    p.setColor(QPalette::BrightText, Qt::red);
    p.setColor(QPalette::Highlight, QColor(70, 130, 220));
    p.setColor(QPalette::HighlightedText, Qt::white);
    qApp->setPalette(p);
}

MainWindow::AddOptions MainWindow::askAddOptions(const QString& title)
{
    AddOptions out;
    out.savePath = m_settings ? m_settings->defaultDownloadPath()
                              : QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);

    QDialog dialog(this);
    dialog.setWindowTitle(title + " — choose drive and speed mode");
    dialog.resize(760, 420);

    auto* layout = new QVBoxLayout(&dialog);
    auto* form = new QFormLayout();

    auto* pathRow = new QWidget(&dialog);
    auto* pathLayout = new QHBoxLayout(pathRow);
    pathLayout->setContentsMargins(0, 0, 0, 0);
    auto* pathEdit = new QLineEdit(out.savePath, pathRow);
    auto* browse = new QPushButton("Browse any drive/folder…", pathRow);
    pathLayout->addWidget(pathEdit, 1);
    pathLayout->addWidget(browse);
    form->addRow("Download to:", pathRow);

    auto* driveCombo = new QComboBox(&dialog);
    if (m_session) {
        const QStringList roots = m_session->downloadRoots();
        for (const QString& root : roots) {
            driveCombo->addItem(PathTools::driveLabelForRoot(root), root);
        }
    }
    if (driveCombo->count() == 0) {
        driveCombo->addItem(PathTools::driveLabelForRoot(QDir::homePath()), QDir::homePath());
    }
    form->addRow("Mounted drive:", driveCombo);

    auto* recentCombo = new QComboBox(&dialog);
    recentCombo->addItem("Choose a recent download folder…", QString());
    if (m_settings) {
        const QStringList recent = m_settings->recentDownloadPaths();
        for (const QString& path : recent) {
            if (!path.trimmed().isEmpty()) recentCombo->addItem(path, path);
        }
    }
    form->addRow("Recent folders:", recentCombo);

    auto* freeSpaceLabel = new QLabel(&dialog);
    freeSpaceLabel->setWordWrap(true);
    form->addRow("Selected drive:", freeSpaceLabel);

    auto updateFreeSpace = [&] {
        const QString path = pathEdit->text().trimmed().isEmpty() ? QDir::homePath() : pathEdit->text().trimmed();
        QStorageInfo storage(path);
        if (!storage.isValid()) storage = QStorageInfo(QFileInfo(path).absolutePath());
        const QString rootPath = storage.rootPath().isEmpty() ? QString("unknown") : storage.rootPath();
        const QString msg = QString("Root: %1    Free: %2    Total: %3    Filesystem: %4")
            .arg(rootPath,
                 PathTools::displaySize(storage.bytesAvailable()),
                 PathTools::displaySize(storage.bytesTotal()),
                 QString::fromUtf8(storage.fileSystemType()));
        freeSpaceLabel->setText(msg);
    };

    auto* boost = new QCheckBox("Boost by sharing more upload", &dialog);
    boost->setChecked(true);
    form->addRow("Auto Seed Boost:", boost);

    auto* sequential = new QCheckBox("Sequential download", &dialog);
    sequential->setToolTip("Sequential is useful for media previewing, but rarest-first is usually faster and better for swarms.");
    form->addRow("Sequential:", sequential);

    auto* mode = new QComboBox(&dialog);
    mode->addItems({"Fast Download", "Ratio Builder", "Seed Forever", "Normal"});
    form->addRow("Mode:", mode);

    auto* upload = new QSpinBox(&dialog);
    upload->setRange(0, 1000000);
    upload->setSpecialValueText("No per-torrent upload limit");
    upload->setSuffix(" KB/s");
    upload->setToolTip("For fastest download, use a real upload cap around 70–85% of your upload capacity. 0 means unlimited/global.");
    form->addRow("Torrent upload limit:", upload);

    auto* download = new QSpinBox(&dialog);
    download->setRange(0, 1000000);
    download->setSpecialValueText("No per-torrent download limit");
    download->setSuffix(" KB/s");
    download->setToolTip("0 means unlimited/global. To reach 100 MB/s+, leave this at 0 and use a fast SSD/NVMe destination.");
    form->addRow("Torrent download limit:", download);

    layout->addLayout(form);

    auto* note = new QLabel(
        "Pick any mounted hard drive, SSD, external drive, /mnt path, /media path, or Windows drive. "
        "For 100 MB/s+ legal torrents, use a healthy swarm, wired/fast Wi‑Fi, an open listening port, no download cap, "
        "and a fast SSD/NVMe destination. QyTorrent creates a QyTorrent folder on the selected drive by default.",
        &dialog);
    note->setWordWrap(true);
    layout->addWidget(note);

    auto* buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
    auto* useDriveButton = new QPushButton("Use selected drive");
    buttons->addButton(useDriveButton, QDialogButtonBox::ActionRole);
    layout->addWidget(buttons);

    connect(browse, &QPushButton::clicked, &dialog, [&] {
        const QString selected = QFileDialog::getExistingDirectory(
            &dialog,
            "Choose download folder on any hard drive",
            pathEdit->text().isEmpty() ? QDir::homePath() : pathEdit->text(),
            QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
        if (!selected.isEmpty()) {
            pathEdit->setText(QDir::cleanPath(selected));
            updateFreeSpace();
        }
    });

    connect(driveCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), &dialog, [&](int index) {
        const QString root = driveCombo->itemData(index).toString();
        if (!root.isEmpty()) {
            pathEdit->setText(PathTools::defaultDownloadFolderOnRoot(root));
            updateFreeSpace();
        }
    });

    connect(recentCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), &dialog, [&](int index) {
        const QString recent = recentCombo->itemData(index).toString();
        if (!recent.isEmpty()) {
            pathEdit->setText(recent);
            updateFreeSpace();
        }
    });

    connect(pathEdit, &QLineEdit::textChanged, &dialog, [&](const QString&) { updateFreeSpace(); });
    connect(useDriveButton, &QPushButton::clicked, &dialog, [&] {
        const QString root = driveCombo->currentData().toString();
        if (!root.isEmpty()) {
            pathEdit->setText(PathTools::defaultDownloadFolderOnRoot(root));
            updateFreeSpace();
        }
    });
    connect(buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);

    updateFreeSpace();

    if (dialog.exec() == QDialog::Accepted) {
        out.savePath = QDir::cleanPath(pathEdit->text().trimmed());
        out.boost = boost->isChecked();
        out.sequential = sequential->isChecked();
        out.mode = mode->currentText();
        out.uploadLimit = upload->value() * 1024;
        out.downloadLimit = download->value() * 1024;

        QString error;
        if (!DownloadPlanner::ensureDownloadDirectory(out.savePath, &error)) {
            QMessageBox::warning(this, "Download folder not usable", error);
            return out;
        }

        QStorageInfo storage(out.savePath);
        if (storage.isValid() && storage.bytesAvailable() > 0 && storage.bytesAvailable() < 1024LL * 1024LL * 1024LL) {
            const auto answer = QMessageBox::question(
                this,
                "Low free space",
                "The selected drive has less than 1 GB free. Continue anyway?");
            if (answer != QMessageBox::Yes) return out;
        }

        out.accepted = true;
        if (m_settings) {
            m_settings->setDefaultDownloadPath(out.savePath);
            m_settings->addRecentDownloadPath(out.savePath);
        }
    }
    return out;
}

void MainWindow::addTorrentFile()
{
    const QString path = QFileDialog::getOpenFileName(this, "Choose .torrent file", QDir::homePath(), "Torrent files (*.torrent);;All files (*)");
    if (path.isEmpty()) return;

    const auto options = askAddOptions("Add torrent");
    if (!options.accepted) return;

    const QString id = m_session->addTorrentFile(path, options.savePath, options.boost, options.sequential,
                                                 options.mode, options.uploadLimit, options.downloadLimit);
    if (!id.isEmpty()) m_status->setText("Added torrent: " + id);
    refreshTable();
}

void MainWindow::addMagnet()
{
    bool ok = false;
    const QString magnet = QInputDialog::getMultiLineText(this, "Add magnet link", "Magnet link:", "", &ok).trimmed();
    if (!ok || magnet.isEmpty()) return;

    const auto options = askAddOptions("Add magnet");
    if (!options.accepted) return;

    const QString id = m_session->addMagnet(magnet, options.savePath, options.boost, options.sequential,
                                            options.mode, options.uploadLimit, options.downloadLimit);
    if (!id.isEmpty()) m_status->setText("Added magnet: " + id);
    refreshTable();
}

QString MainWindow::selectedTorrentId() const
{
    if (!m_table || !m_table->currentItem()) return {};
    const int row = m_table->currentRow();
    auto* item = m_table->item(row, 0);
    return item ? item->data(Qt::UserRole).toString() : QString();
}

void MainWindow::pauseSelected()
{
    const QString id = selectedTorrentId();
    if (!id.isEmpty()) m_session->pauseTorrent(id);
}

void MainWindow::resumeSelected()
{
    const QString id = selectedTorrentId();
    if (!id.isEmpty()) m_session->resumeTorrent(id);
}

void MainWindow::removeSelected()
{
    const QString id = selectedTorrentId();
    if (id.isEmpty()) return;

    const auto answer = QMessageBox::question(this, "Remove torrent", "Remove selected torrent?\n\nChoose No to cancel. Files are kept by default.");
    if (answer == QMessageBox::Yes) {
        m_session->removeTorrent(id, false);
        refreshTable();
    }
}

void MainWindow::applyGlobalLimits()
{
    const int up = m_globalUpload->value() * 1024;
    const int down = m_globalDownload->value() * 1024;
    const QString profile = m_speedProfile ? m_speedProfile->currentText() : QString("High throughput");
    if (m_settings) {
        m_settings->setGlobalUploadLimit(up);
        m_settings->setGlobalDownloadLimit(down);
        m_settings->setSpeedProfile(profile);
    }
    if (m_session) {
        m_session->setPerformanceProfile(profile);
        m_session->setGlobalLimits(up, down);
    }
    m_status->setText("Global limits and performance profile applied");
}

void MainWindow::openDownloadFolder()
{
    const QString path = m_settings ? m_settings->defaultDownloadPath() : QDir::homePath();
    QDir().mkpath(path);
    QDesktopServices::openUrl(QUrl::fromLocalFile(path));
}

void MainWindow::showDetails()
{
    const QString id = selectedTorrentId();
    if (id.isEmpty()) return;

    QString text;
    text += "Peers\n=====\n";
    const QVariantList peers = m_session->peersFor(id);
    if (peers.isEmpty()) text += "No peer details yet.\n";
    for (const QVariant& v : peers) {
        const auto m = v.toMap();
        text += QString("%1  down=%2  up=%3  score=%4\n")
            .arg(m.value("address").toString())
            .arg(rateText(m.value("downloadRate").toInt()))
            .arg(rateText(m.value("uploadRate").toInt()))
            .arg(m.value("score").toInt());
    }

    text += "\nFiles\n=====\n";
    const QVariantList files = m_session->filesFor(id);
    if (files.isEmpty()) text += "No file details yet.\n";
    for (const QVariant& v : files) {
        const auto m = v.toMap();
        text += QString("[%1] %2 (%3 bytes)\n")
            .arg(m.value("priority").toInt())
            .arg(m.value("path").toString())
            .arg(m.value("size").toLongLong());
    }

    QDialog dialog(this);
    dialog.setWindowTitle("QyTorrent details");
    auto* layout = new QVBoxLayout(&dialog);
    auto* edit = new QTextEdit(&dialog);
    edit->setReadOnly(true);
    edit->setPlainText(text);
    layout->addWidget(edit);
    auto* buttons = new QDialogButtonBox(QDialogButtonBox::Close, &dialog);
    layout->addWidget(buttons);
    connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    connect(buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    dialog.resize(700, 480);
    dialog.exec();
}

QString MainWindow::rateText(int bytesPerSecond)
{
    if (bytesPerSecond <= 0) return "0 B/s";
    if (bytesPerSecond < 1024) return QString::number(bytesPerSecond) + " B/s";
    if (bytesPerSecond < 1024 * 1024) return QString::number(bytesPerSecond / 1024.0, 'f', 1) + " KB/s";
    return QString::number(bytesPerSecond / 1024.0 / 1024.0, 'f', 2) + " MB/s";
}

void MainWindow::refreshTable()
{
    if (!m_session || !m_table) return;

    auto* model = m_session->model();
    const int rows = model->rowCount();
    const int selected = m_table->currentRow();
    const QString selectedId = selectedTorrentId();

    m_table->setSortingEnabled(false);
    m_table->setRowCount(rows);

    for (int row = 0; row < rows; ++row) {
        const QModelIndex idx = model->index(row, 0);
        const QString id = model->data(idx, TorrentModel::IdRole).toString();
        const QStringList values = {
            model->data(idx, TorrentModel::NameRole).toString(),
            model->data(idx, TorrentModel::StateRole).toString(),
            QString::number(model->data(idx, TorrentModel::ProgressRole).toDouble() * 100.0, 'f', 1) + "%",
            rateText(model->data(idx, TorrentModel::DownloadRateRole).toInt()),
            rateText(model->data(idx, TorrentModel::UploadRateRole).toInt()),
            QString::number(model->data(idx, TorrentModel::RatioRole).toDouble(), 'f', 2),
            QString::number(model->data(idx, TorrentModel::SeedersRole).toInt()),
            QString::number(model->data(idx, TorrentModel::LeechersRole).toInt()),
            QString::number(model->data(idx, TorrentModel::PeersRole).toInt()),
            model->data(idx, TorrentModel::BoostRole).toBool() ? "On" : "Off",
            model->data(idx, TorrentModel::ModeRole).toString(),
            model->data(idx, TorrentModel::SavePathRole).toString()
        };

        for (int col = 0; col < values.size(); ++col) {
            auto* cell = m_table->item(row, col);
            if (!cell) {
                cell = new QTableWidgetItem();
                m_table->setItem(row, col, cell);
            }
            cell->setText(values[col]);
            if (col == 0) cell->setData(Qt::UserRole, id);
        }
    }

    for (int row = 0; row < rows; ++row) {
        if (m_table->item(row, 0) && m_table->item(row, 0)->data(Qt::UserRole).toString() == selectedId) {
            m_table->selectRow(row);
            break;
        }
    }
    if (selectedId.isEmpty() && selected >= 0 && selected < rows) m_table->selectRow(selected);

    m_table->setSortingEnabled(true);
    m_status->setText(QString("%1 torrent(s)").arg(rows));
}

void MainWindow::showError()
{
    if (!m_session) return;
    const QString err = m_session->lastError();
    if (!err.isEmpty()) {
        m_status->setText(err);
        QMessageBox::warning(this, "QyTorrent", err);
    }
}
