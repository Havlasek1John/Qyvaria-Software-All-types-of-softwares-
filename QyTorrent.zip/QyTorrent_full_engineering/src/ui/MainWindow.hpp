#pragma once

#include <QMainWindow>
#include <QTimer>
#include <QString>

class QTableWidget;
class QPushButton;
class QLabel;
class QSpinBox;
class QCheckBox;
class QComboBox;
class QLineEdit;
class SettingsStore;
class TorrentSession;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(TorrentSession* session, SettingsStore* settings, QWidget* parent = nullptr);

private slots:
    void addTorrentFile();
    void addMagnet();
    void pauseSelected();
    void resumeSelected();
    void removeSelected();
    void applyGlobalLimits();
    void openDownloadFolder();
    void showDetails();
    void refreshTable();
    void showError();

private:
    struct AddOptions {
        QString savePath;
        bool boost = true;
        bool sequential = false;
        QString mode = "Fast Download";
        int uploadLimit = 0;
        int downloadLimit = 0;
        bool accepted = false;
    };

    AddOptions askAddOptions(const QString& title);
    QString selectedTorrentId() const;
    void setupUi();
    void applyDarkTheme();
    static QString rateText(int bytesPerSecond);

    TorrentSession* m_session = nullptr;
    SettingsStore* m_settings = nullptr;

    QTableWidget* m_table = nullptr;
    QLabel* m_status = nullptr;
    QSpinBox* m_globalUpload = nullptr;
    QSpinBox* m_globalDownload = nullptr;
    QComboBox* m_speedProfile = nullptr;
    QTimer m_refreshTimer;
};
