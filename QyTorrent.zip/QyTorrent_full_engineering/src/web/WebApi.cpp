#include "WebApi.hpp"
#include "core/TorrentSession.hpp"
#include "core/SettingsStore.hpp"
#include <QTcpSocket>
#include <QJsonDocument>
#include <QJsonObject>

WebApi::WebApi(TorrentSession* session, SettingsStore* settings, QObject* parent)
    : QObject(parent), m_session(session), m_settings(settings)
{
    connect(&m_server, &QTcpServer::newConnection, this, &WebApi::acceptClient);
}

bool WebApi::start(int port)
{
    if (m_server.isListening()) return true;
    const bool ok = m_server.listen(QHostAddress::LocalHost, quint16(port));
    emit runningChanged();
    return ok;
}

void WebApi::stop()
{
    m_server.close();
    emit runningChanged();
}

void WebApi::acceptClient()
{
    auto* socket = m_server.nextPendingConnection();
    if (!socket) return;
    connect(socket, &QTcpSocket::readyRead, this, [socket, this] {
        socket->readAll();

        QJsonObject body;
        body["app"] = "QyTorrent";
        body["status"] = "ok";
        body["torrents"] = m_session ? m_session->model()->rowCount() : 0;

        const QByteArray json = QJsonDocument(body).toJson(QJsonDocument::Compact);
        QByteArray response;
        response += "HTTP/1.1 200 OK\r\n";
        response += "Content-Type: application/json\r\n";
        response += "Access-Control-Allow-Origin: http://localhost\r\n";
        response += "Content-Length: " + QByteArray::number(json.size()) + "\r\n\r\n";
        response += json;
        socket->write(response);
        socket->disconnectFromHost();
    });
}
