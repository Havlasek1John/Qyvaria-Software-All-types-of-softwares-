#pragma once
#include <QObject>
#include <QTcpServer>

class TorrentSession;
class SettingsStore;

class WebApi : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool running READ running NOTIFY runningChanged)
public:
    explicit WebApi(TorrentSession* session, SettingsStore* settings, QObject* parent = nullptr);
    bool running() const { return m_server.isListening(); }

    Q_INVOKABLE bool start(int port);
    Q_INVOKABLE void stop();

signals:
    void runningChanged();

private slots:
    void acceptClient();

private:
    TorrentSession* m_session = nullptr;
    SettingsStore* m_settings = nullptr;
    QTcpServer m_server;
};
