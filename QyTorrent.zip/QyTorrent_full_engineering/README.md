# QyTorrent

QyTorrent is a Qt desktop torrent client prototype for Windows and Linux.

This fixed build intentionally uses **Qt Widgets instead of QML**. That avoids the Pop!_OS/COSMIC error:

```text
module "QtQml.WorkerScript" is not installed
```

The app still includes the same desktop features:

- Add `.torrent` files
- Add magnet links
- Choose download folder/drive before starting
- Pause, resume, remove
- Per-torrent upload/download limits
- Global upload/download limits
- Auto Seed Boost mode
- Fast Download / Ratio Builder / Seed Forever / Normal modes
- Ratio, seeder, leecher, peer, tracker, and file hooks
- Sequential download option
- Dark desktop UI
- Linux app-menu and desktop launchers
- Windows desktop and Start Menu shortcuts

## Linux Pop!_OS / Ubuntu / Debian

Install dependencies:

```bash
cd QyTorrent_full_engineering
chmod +x packaging/linux/install-deps-popos.sh
./packaging/linux/install-deps-popos.sh
```

Build and install app/menu launchers:

```bash
chmod +x packaging/linux/build-and-install-linux.sh
./packaging/linux/build-and-install-linux.sh
```

Run from terminal:

```bash
packaging/linux/run-qytorrent.sh
```

Run directly:

```bash
./build/bin/QyTorrent
```

Debug system:

```bash
packaging/linux/doctor.sh
cat ~/.local/share/qytorrent/qytorrent-launch.log
```

The launcher installs:

```text
~/.local/share/applications/qytorrent.desktop
~/.local/share/applications/qytorrent-debug.desktop
~/Desktop/QyTorrent.desktop
~/Desktop/QyTorrent Debug.desktop
```

On GNOME/COSMIC, if the desktop icon is blocked, right-click it and choose **Allow Launching**.

## Windows

Install CMake and Qt 6.4+ first. Then run PowerShell:

```powershell
cd C:\path\to\QyTorrent_full_engineering
powershell -ExecutionPolicy Bypass -File .\packaging\windows\build-and-install-windows.ps1
```

Shortcut-only:

```powershell
powershell -ExecutionPolicy Bypass -File .\packaging\windows\install-shortcuts.ps1
```

## Why this version should run on COSMIC

Earlier builds used QML/Qt Quick. Your system was missing a QML runtime module:

```text
module "QtQml.WorkerScript" is not installed
```

This version removes the QML frontend from the executable and uses Qt Widgets, which is included with `qt6-base-dev` and is much more reliable for Linux desktop packaging.


## Drive picker and 100MB+ optimizer

This version adds a real hard-drive destination picker before adding a torrent or magnet. You can pick an internal disk, external drive, mounted Linux drive under `/media`, `/mnt`, `/run/media`, or a Windows drive such as `D:\QyTorrent`.

The Qt Widgets UI also includes a global performance selector:

- Balanced
- High throughput
- Extreme / 100MB+ capable

For 100 MB/s+ legal torrent downloads, use the Extreme profile, leave download limit at unlimited, choose a fast SSD/NVMe destination, use a legal swarm with many fast seeders, and make sure your listening port is open.
