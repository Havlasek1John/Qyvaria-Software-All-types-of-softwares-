# Auto Seed Boost algorithm

When a torrent starts:

```text
read swarm health
read tracker/private flag
measure current upload capacity
connect to high-quality peers
prioritize rare pieces
upload to peers that reciprocate
avoid wasting upload on dead/slow peers
increase upload until user limit or network saturation
monitor download gain
reduce upload if it hurts download latency
```

## Peer scoring

Peer score should use:

- download rate from peer
- upload rate to peer
- latency
- choking state
- rare piece availability
- failed blocks
- reciprocity

## Modes

### Normal

No extra tuning. Respect user/global limits.

### Fast Download

Share enough to improve reciprocity, but avoid saturating upload so download ACKs are not delayed.

### Ratio Builder

Raise upload slot count and upload limit within configured caps.

### Seed Forever

Prioritize long-term seeding, private tracker ratio health, and stable disk/network behavior.

## Anti-goals

QyBoost must not:

- fake ratio
- bypass private tracker rules
- disable private torrent restrictions
- hide user bandwidth usage
- upload content the user has not chosen
