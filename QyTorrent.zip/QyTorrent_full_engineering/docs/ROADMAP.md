# Roadmap

## v0.3 current engineered starter

- Qt 6/QML UI
- libtorrent session integration
- Add torrent/magnet with selected download path
- Per-torrent/global limits
- Pause/resume/remove
- Boost mode skeleton
- Peer/file/status views
- Web API stub

## v0.4

- Resume data save/load
- Session restore
- Full tracker table
- Full peer table with country/client/protocol
- Full file tree
- Tray icon
- Notifications
- Port test

## v0.5

- RSS downloader
- Search plugin sandbox
- Private tracker profiles
- Seeding scheduler
- Auto shutdown

## v1.0

- Signed Windows installer
- AppImage/Flatpak/deb
- Translation support
- Crash-safe resume data
- Security review
