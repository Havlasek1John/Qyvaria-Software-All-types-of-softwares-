# Qt Widgets COSMIC Fix

This build replaces the QML/Qt Quick frontend with a Qt Widgets frontend.

Reason: Pop!_OS/COSMIC system Qt 6.4.2 may not include every QML runtime module by default.
The user log showed:

```text
module "QtQml.WorkerScript" is not installed
```

The fixed build avoids QML completely and links only:

- Qt6::Core
- Qt6::Gui
- Qt6::Widgets
- Qt6::Network
- Qt6::Concurrent

Run:

```bash
./packaging/linux/install-deps-popos.sh
./packaging/linux/build-and-install-linux.sh
./packaging/linux/run-qytorrent.sh
```
