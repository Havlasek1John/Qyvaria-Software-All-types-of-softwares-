# QyTorrent Drive Picker + Speed Optimizer

## Drive picker

QyTorrent now shows a full destination dialog before adding a `.torrent` or magnet:

- `Mounted drive` lists every ready writable drive reported by Qt `QStorageInfo`.
- Each drive row shows root path, free space, total space, filesystem, and display name.
- `Use selected drive` creates/uses a `QyTorrent` folder on that drive.
- `Browse any drive/folder…` lets you pick external drives, `/media/...`, `/mnt/...`, Windows drive letters, or any custom folder.
- Recent destinations are remembered in app settings.

Recommended Linux external-drive locations:

```text
/media/<your-user>/<drive-name>/QyTorrent
/mnt/<drive-name>/QyTorrent
/run/media/<your-user>/<drive-name>/QyTorrent
```

Recommended Windows external-drive locations:

```text
D:\QyTorrent
E:\QyTorrent
F:\QyTorrent
```

## Speed profiles

The global performance selector has three modes:

### Balanced
Safer default for weaker routers, HDDs, Wi‑Fi, or many background tasks.

### High throughput
Default for modern systems. It increases peer capacity, tracker peer requests, disk I/O threads, file pool, request queue, and socket buffers.

### Extreme / 100MB+ capable
For strong legal swarms, fast wired or high-quality Wi‑Fi, SSD/NVMe download destination, and routers that can handle many connections. It increases:

- session connection limit
- active torrent limits
- initial torrent connect boost
- tracker `num_want`
- peer list size
- disk I/O and hashing threads
- file pool size
- send/receive socket buffers
- request queues
- upload slots

## Getting closer to 100 MB/s+

Software settings can only remove bottlenecks. Actual speed also needs:

1. A legal torrent with many fast seeders.
2. A fast enough ISP line. 100 MB/s is about 800 Mb/s before overhead.
3. A fast destination drive, preferably SSD/NVMe.
4. An open listening port in your router/firewall.
5. No global or per-torrent download cap.
6. Upload capped around 70–85% of real upload capacity if your connection has bufferbloat.
7. Sequential download off unless previewing media.
8. Avoid slow USB sticks or old HDDs for very high-speed downloads.

QyTorrent does not spoof ratio, bypass trackers, or force peers to upload. Auto Seed Boost only shares fairly and tunes legal BitTorrent behavior.
