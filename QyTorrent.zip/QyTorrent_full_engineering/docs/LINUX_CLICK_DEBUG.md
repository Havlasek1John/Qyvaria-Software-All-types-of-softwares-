# Linux click-to-run debugging

If clicking QyTorrent appears to do nothing, run:

```bash
packaging/linux/run-qytorrent-debug.sh
```

or open **QyTorrent Debug** from your applications menu.

Logs are saved to `~/.local/share/qytorrent/qytorrent-launch.log`.

Common Ubuntu/Debian fix:

```bash
sudo apt update
sudo apt install -y qml6-module-qtquick qml6-module-qtquick-controls qml6-module-qtquick-dialogs qml6-module-qtquick-layouts qt6-qpa-plugins
```

On GNOME desktop, right-click `QyTorrent.desktop` and choose **Allow Launching**.
