# Linux Qt 6.4.2 Fix

Some Debian/Ubuntu-based systems ship Qt 6.4.2. QyTorrent now requires Qt 6.4+ instead of Qt 6.5+.

If you still see a Qt 6.5 error, run this from the project root:

```bash
sed -i 's/find_package(Qt6 6\.5/find_package(Qt6 6.4/' CMakeLists.txt
sed -i 's/qt_standard_project_setup(REQUIRES 6\.5)/qt_standard_project_setup(REQUIRES 6.4)/' CMakeLists.txt
rm -rf build
./packaging/linux/build-and-install-linux.sh
```
