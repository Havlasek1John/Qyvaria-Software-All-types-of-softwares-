# QyTorrent architecture

## Frontend

Qt 6/QML provides the main desktop UI. The QML layer never talks directly to libtorrent. It calls `TorrentSession` invokable methods.

## Core

`TorrentSession` owns the libtorrent session, torrent handles, model updates, alerts, pause/resume/remove, speed limits, sequential download, file priorities, and add torrent workflow.

`TorrentModel` exposes torrents to QML with roles such as name, progress, ratio, seeders, leechers, speed, boost mode, and save path.

`SettingsStore` persists default download folder, global speed limits, UI mode, and Web API settings.

`DownloadPlanner` validates and creates the selected download folder before a torrent starts. This is where Windows drive paths and Linux mount paths are normalized.

## QyBoost

`QyBoostEngine` runs a timed optimization cycle. The current implementation is intentionally conservative: it does not bypass tracker rules, it does not spoof ratio, and it does not ignore user limits.

Boost mode goals:

- connect to useful peers
- avoid wasting upload on dead peers
- protect latency
- upload more when it helps
- keep rare pieces valuable
- maintain private tracker compliance
