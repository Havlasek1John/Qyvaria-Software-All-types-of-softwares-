param(
  [string]$InstallDir = ""
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($InstallDir)) {
  $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
  $ProjectRoot = Resolve-Path (Join-Path $ScriptDir "..\..")
  $Candidates = @(
    (Join-Path $ProjectRoot "build\bin\Release\QyTorrent.exe"),
    (Join-Path $ProjectRoot "build\bin\QyTorrent.exe"),
    (Join-Path $ProjectRoot "build\Release\QyTorrent.exe"),
    (Join-Path $ProjectRoot "build\QyTorrent.exe"),
    (Join-Path $ProjectRoot "dist\windows\QyTorrent.exe")
  )

  $Exe = $null
  foreach ($c in $Candidates) {
    if (Test-Path $c) { $Exe = (Resolve-Path $c).Path; break }
  }

  if (-not $Exe) {
    $Found = Get-ChildItem -Path $ProjectRoot -Filter "QyTorrent.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($Found) { $Exe = $Found.FullName }
  }
} else {
  $Exe = Join-Path $InstallDir "QyTorrent.exe"
}

if (-not $Exe -or -not (Test-Path $Exe)) {
  Write-Host "QyTorrent.exe was not found."
  Write-Host "Build first, then run this again:"
  Write-Host "  cmake -S . -B build -DCMAKE_BUILD_TYPE=Release"
  Write-Host "  cmake --build build --config Release"
  exit 1
}

$Shell = New-Object -ComObject WScript.Shell

$Desktop = [Environment]::GetFolderPath("Desktop")
$StartMenuPrograms = Join-Path ([Environment]::GetFolderPath("Programs")) "QyTorrent"
New-Item -ItemType Directory -Force -Path $StartMenuPrograms | Out-Null

$DesktopLink = Join-Path $Desktop "QyTorrent.lnk"
$StartLink = Join-Path $StartMenuPrograms "QyTorrent.lnk"

foreach ($LinkPath in @($DesktopLink, $StartLink)) {
  $Shortcut = $Shell.CreateShortcut($LinkPath)
  $Shortcut.TargetPath = $Exe
  $Shortcut.WorkingDirectory = Split-Path -Parent $Exe
  $Shortcut.Description = "QyTorrent - Share smarter. Download faster."
  $Shortcut.IconLocation = "$Exe,0"
  $Shortcut.Save()
}

Write-Host "Installed Windows shortcuts:"
Write-Host "  Desktop: $DesktopLink"
Write-Host "  Start Menu: $StartLink"
Write-Host "Executable: $Exe"
