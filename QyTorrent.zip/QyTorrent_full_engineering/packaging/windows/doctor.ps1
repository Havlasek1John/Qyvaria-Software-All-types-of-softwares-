$ErrorActionPreference = "Continue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $ScriptDir "..\..")
Write-Host "QyTorrent Windows doctor"
Write-Host "Project: $ProjectRoot"
Write-Host ""

foreach ($c in @("cmake", "git")) {
  $cmd = Get-Command $c -ErrorAction SilentlyContinue
  if ($cmd) { Write-Host "$c: $($cmd.Source)" } else { Write-Host "$c: MISSING" }
}

$Candidates = @(
  (Join-Path $ProjectRoot "build\bin\Release\QyTorrent.exe"),
  (Join-Path $ProjectRoot "build\bin\QyTorrent.exe"),
  (Join-Path $ProjectRoot "build\Release\QyTorrent.exe"),
  (Join-Path $ProjectRoot "build\QyTorrent.exe")
)

Write-Host ""
Write-Host "Binary candidates:"
foreach ($c in $Candidates) {
  if (Test-Path $c) { Write-Host "  OK: $c" } else { Write-Host "  Missing: $c" }
}
