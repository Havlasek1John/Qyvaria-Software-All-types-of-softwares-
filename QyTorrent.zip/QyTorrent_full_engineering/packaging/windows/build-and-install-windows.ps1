$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $ScriptDir "..\..")
Set-Location $ProjectRoot

if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
  Write-Host "cmake is missing. Install CMake first:"
  Write-Host "  winget install Kitware.CMake"
  exit 1
}

Write-Host "Building QyTorrent Qt Widgets version. No QML runtime is required."
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release

& (Join-Path $ScriptDir "install-shortcuts.ps1")
Write-Host ""
Write-Host "Run:"
Write-Host "  .\build\bin\QyTorrent.exe"
