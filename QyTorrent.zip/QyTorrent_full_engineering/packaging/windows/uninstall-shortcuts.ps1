$DesktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) "QyTorrent.lnk"
$StartMenuPrograms = Join-Path ([Environment]::GetFolderPath("Programs")) "QyTorrent"
Remove-Item -Force -ErrorAction SilentlyContinue $DesktopLink
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $StartMenuPrograms
Write-Host "Removed QyTorrent Windows shortcuts."
