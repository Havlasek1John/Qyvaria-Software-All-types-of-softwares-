Unicode True
Name "QyTorrent"
OutFile "QyTorrentSetup.exe"
InstallDir "$PROGRAMFILES64\QyTorrent"
RequestExecutionLevel admin

Page directory
Page instfiles

Section "Install"
  SetOutPath "$INSTDIR"
  File /r "..\..\dist\windows\*"

  CreateDirectory "$SMPROGRAMS\QyTorrent"
  CreateShortcut "$DESKTOP\QyTorrent.lnk" "$INSTDIR\QyTorrent.exe" "" "$INSTDIR\QyTorrent.exe" 0
  CreateShortcut "$SMPROGRAMS\QyTorrent\QyTorrent.lnk" "$INSTDIR\QyTorrent.exe" "" "$INSTDIR\QyTorrent.exe" 0
  CreateShortcut "$SMPROGRAMS\QyTorrent\Uninstall QyTorrent.lnk" "$INSTDIR\Uninstall.exe"

  WriteUninstaller "$INSTDIR\Uninstall.exe"

  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\QyTorrent" "DisplayName" "QyTorrent"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\QyTorrent" "UninstallString" "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\QyTorrent.lnk"
  Delete "$SMPROGRAMS\QyTorrent\QyTorrent.lnk"
  Delete "$SMPROGRAMS\QyTorrent\Uninstall QyTorrent.lnk"
  RMDir "$SMPROGRAMS\QyTorrent"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\QyTorrent"
SectionEnd
