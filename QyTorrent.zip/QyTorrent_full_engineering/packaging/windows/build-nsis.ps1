$ErrorActionPreference = "Stop"
cmake -S ../.. -B ../../build-windows -DCMAKE_BUILD_TYPE=Release
cmake --build ../../build-windows --config Release
Write-Host "Use windeployqt on QyTorrent.exe, then build an installer with NSIS or WiX."
