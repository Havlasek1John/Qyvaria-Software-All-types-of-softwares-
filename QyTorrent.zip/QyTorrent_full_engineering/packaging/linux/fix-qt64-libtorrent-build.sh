#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."

echo "Patching Qt 6.4 + libtorrent compatibility..."
sed -i 's/find_package(Qt6 6\.5/find_package(Qt6 6.4/' CMakeLists.txt || true
sed -i 's/qt_standard_project_setup(REQUIRES 6\.5)/qt_standard_project_setup(REQUIRES 6.4)/' CMakeLists.txt || true

python3 - <<'PY'
from pathlib import Path

main = Path("src/main.cpp")
s = main.read_text()
if '#include <QUrl>' not in s:
    s = s.replace('#include <QQuickStyle>\n#include <QIcon>\n',
                  '#include <QQuickStyle>\n#include <QIcon>\n#include <QUrl>\n')
replacement = '''    // Qt 6.4 compatibility: QQmlApplicationEngine::loadFromModule() was added in Qt 6.5.
    engine.load(QUrl(QStringLiteral("qrc:/qt/qml/QyTorrent/Main.qml")));
    if (engine.rootObjects().isEmpty()) {
        engine.load(QUrl(QStringLiteral("qrc:/QyTorrent/Main.qml")));
    }
'''
s = s.replace('    engine.loadFromModule("QyTorrent", "Main");\n', replacement)
main.write_text(s)

ts = Path("src/core/TorrentSession.cpp")
s = ts.read_text()
s = s.replace('const bool activeDownload = !st.is_seeding && st.state != lt::torrent_status::paused;',
              'const bool activeDownload = !st.is_seeding && !st.paused;')
ts.write_text(s)
PY

rm -rf build
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel

chmod +x packaging/linux/install-desktop.sh || true
./packaging/linux/install-desktop.sh || true

echo
echo "Built. Run:"
echo "  ./build/bin/QyTorrent"
echo
echo "If it does not open, try:"
echo "  QT_DEBUG_PLUGINS=1 ./build/bin/QyTorrent"
