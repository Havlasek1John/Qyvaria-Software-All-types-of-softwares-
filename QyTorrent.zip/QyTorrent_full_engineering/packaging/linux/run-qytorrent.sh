#!/usr/bin/env bash
set -u
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
LOG_DIR="$HOME/.local/share/qytorrent"
LOG_FILE="$LOG_DIR/qytorrent-launch.log"
mkdir -p "$LOG_DIR"

find_bin() {
  local candidates=(
    "$PROJECT_ROOT/build/bin/QyTorrent"
    "$PROJECT_ROOT/build/QyTorrent"
    "$PROJECT_ROOT/QyTorrent"
  )
  for c in "${candidates[@]}"; do
    if [[ -f "$c" && -x "$c" ]]; then echo "$c"; return 0; fi
  done
  find "$PROJECT_ROOT" -type f -executable \( -name 'QyTorrent' -o -name 'qytorrent' \) 2>/dev/null | head -n 1
}
BIN="$(find_bin)"
{
  echo "============================================================"
  echo "QyTorrent launch: $(date)"
  echo "Project root: $PROJECT_ROOT"
  echo "Binary: ${BIN:-NOT FOUND}"
  echo "Desktop session: ${XDG_CURRENT_DESKTOP:-unknown}"
  echo "Display: ${DISPLAY:-none}"
  echo "Wayland display: ${WAYLAND_DISPLAY:-none}"
} >> "$LOG_FILE"
if [[ -z "$BIN" || ! -f "$BIN" ]]; then
  echo "QyTorrent executable not found. Build it first." | tee -a "$LOG_FILE"
  echo "Expected: $PROJECT_ROOT/build/bin/QyTorrent" | tee -a "$LOG_FILE"
  exit 127
fi

# Widgets-only app: no QML import paths are needed.
export QT_PLUGIN_PATH="${QT_PLUGIN_PATH:-/usr/lib/x86_64-linux-gnu/qt6/plugins}"
cd "$PROJECT_ROOT" || exit 1
"$BIN" "$@" >> "$LOG_FILE" 2>&1
status=$?
echo "QyTorrent exit code: $status at $(date)" >> "$LOG_FILE"
if [[ "$status" -ne 0 ]]; then
  echo ""
  echo "QyTorrent failed with exit code $status."
  echo "Log file: $LOG_FILE"
  echo ""
  tail -n 160 "$LOG_FILE" || true
fi
exit "$status"
