#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

echo "QyTorrent fix-all: building the Qt Widgets version, not the old QML version."
chmod +x packaging/linux/build-and-install-linux.sh
./packaging/linux/build-and-install-linux.sh
