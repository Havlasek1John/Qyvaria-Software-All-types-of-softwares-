#!/usr/bin/env bash
set -u
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
echo "QyTorrent Linux doctor"
echo "Project: $PROJECT_ROOT"
echo
echo "Commands:"
for c in cmake ninja c++ pkg-config; do
  printf "  %-12s " "$c"
  command -v "$c" || echo "MISSING"
done
echo
echo "Qt packages:"
pkg-config --modversion Qt6Core 2>/dev/null | sed 's/^/  Qt6Core: /' || echo "  Qt6Core: MISSING"
pkg-config --modversion Qt6Widgets 2>/dev/null | sed 's/^/  Qt6Widgets: /' || echo "  Qt6Widgets: MISSING"
echo
echo "libtorrent:"
pkg-config --modversion libtorrent-rasterbar 2>/dev/null | sed 's/^/  libtorrent-rasterbar: /' || echo "  libtorrent-rasterbar: optional/missing"
echo
echo "Binary:"
if [[ -x "$PROJECT_ROOT/build/bin/QyTorrent" ]]; then
  echo "  OK: $PROJECT_ROOT/build/bin/QyTorrent"
  ldd "$PROJECT_ROOT/build/bin/QyTorrent" | grep -E 'not found|Qt6|torrent|ssl|crypto' || true
else
  echo "  Missing. Build with: ./packaging/linux/build-and-install-linux.sh"
fi
