#!/usr/bin/env bash
set -u
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
"$SCRIPT_DIR/run-qytorrent.sh"
code=$?
echo
echo "Exit code: $code"
echo "Log file: $HOME/.local/share/qytorrent/qytorrent-launch.log"
echo
read -r -p "Press Enter to close..."
exit "$code"
