#!/usr/bin/env bash
set -euo pipefail
rm -f "$HOME/.local/share/applications/qytorrent.desktop"
rm -f "$HOME/Desktop/QyTorrent.desktop"
rm -f "$HOME/.local/share/icons/hicolor/scalable/apps/qytorrent.svg"
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
gtk-update-icon-cache "$HOME/.local/share/icons/hicolor" 2>/dev/null || true
echo "Removed QyTorrent Linux launchers."
