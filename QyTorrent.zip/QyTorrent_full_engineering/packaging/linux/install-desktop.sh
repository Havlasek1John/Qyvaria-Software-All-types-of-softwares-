#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
RUNNER="$SCRIPT_DIR/run-qytorrent.sh"
DEBUG_RUNNER="$SCRIPT_DIR/run-qytorrent-debug.sh"
chmod +x "$RUNNER" "$DEBUG_RUNNER"

BIN=""
for c in "$PROJECT_ROOT/build/bin/QyTorrent" "$PROJECT_ROOT/build/QyTorrent" "$PROJECT_ROOT/build/src/QyTorrent" "$PROJECT_ROOT/QyTorrent"; do
  if [[ -f "$c" && -x "$c" ]]; then BIN="$c"; break; fi
done
if [[ -z "$BIN" ]]; then
  BIN="$(find "$PROJECT_ROOT" -type f -executable \( -name 'QyTorrent' -o -name 'qytorrent' \) 2>/dev/null | head -n 1 || true)"
fi

mkdir -p "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/scalable/apps" "$HOME/Desktop" "$SCRIPT_DIR/icons"
ICON_SRC="$SCRIPT_DIR/icons/qytorrent.svg"
if [[ ! -f "$ICON_SRC" ]]; then
cat > "$ICON_SRC" <<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><rect width="128" height="128" rx="28" fill="#151a24"/><path d="M32 40h64v14H32zM32 61h44v14H32zM32 82h64v14H32z" fill="#76e4f7"/><circle cx="93" cy="68" r="15" fill="#8cffb7"/></svg>
SVG
fi
cp "$ICON_SRC" "$HOME/.local/share/icons/hicolor/scalable/apps/qytorrent.svg"

DESKTOP_FILE="$HOME/.local/share/applications/qytorrent.desktop"
DEBUG_DESKTOP_FILE="$HOME/.local/share/applications/qytorrent-debug.desktop"
DESKTOP_COPY="$HOME/Desktop/QyTorrent.desktop"
DEBUG_DESKTOP_COPY="$HOME/Desktop/QyTorrent Debug.desktop"

cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=QyTorrent
GenericName=Torrent Client
Comment=Share smarter. Download faster.
Exec=$RUNNER
Icon=qytorrent
Terminal=false
StartupNotify=true
StartupWMClass=QyTorrent
Categories=Network;FileTransfer;P2P;Qt;
Keywords=torrent;magnet;p2p;download;seed;
MimeType=application/x-bittorrent;x-scheme-handler/magnet;
EOF

cat > "$DEBUG_DESKTOP_FILE" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=QyTorrent Debug
GenericName=Torrent Client Debug Launcher
Comment=Run QyTorrent in a terminal and show launch errors.
Exec=$DEBUG_RUNNER
Icon=qytorrent
Terminal=true
StartupNotify=false
Categories=Network;FileTransfer;P2P;Qt;
EOF

cp "$DESKTOP_FILE" "$DESKTOP_COPY"
cp "$DEBUG_DESKTOP_FILE" "$DEBUG_DESKTOP_COPY"
chmod +x "$DESKTOP_FILE" "$DEBUG_DESKTOP_FILE" "$DESKTOP_COPY" "$DEBUG_DESKTOP_COPY"
gio set "$DESKTOP_COPY" metadata::trusted true 2>/dev/null || true
gio set "$DEBUG_DESKTOP_COPY" metadata::trusted true 2>/dev/null || true
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
gtk-update-icon-cache "$HOME/.local/share/icons/hicolor" 2>/dev/null || true

echo "Installed QyTorrent launchers."
echo "Normal menu launcher: $DESKTOP_FILE"
echo "Debug menu launcher:  $DEBUG_DESKTOP_FILE"
echo "Desktop launcher:     $DESKTOP_COPY"
echo "Debug desktop:        $DEBUG_DESKTOP_COPY"
[[ -n "$BIN" ]] && echo "Detected binary: $BIN" || echo "Warning: QyTorrent binary was not found yet."
echo "If normal click does nothing, open 'QyTorrent Debug'."
echo "Log file: $HOME/.local/share/qytorrent/qytorrent-launch.log"
