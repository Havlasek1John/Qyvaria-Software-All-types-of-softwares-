#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

if ! command -v cmake >/dev/null 2>&1; then
  echo "cmake: command not found"
  echo "Install build tools first:"
  echo "  sudo apt update && sudo apt install -y build-essential cmake ninja-build pkg-config qt6-base-dev qt6-declarative-dev libtorrent-rasterbar-dev"
  exit 1
fi

cmake -S . -B build-appimage -DCMAKE_BUILD_TYPE=Release
cmake --build build-appimage --parallel
echo "Build complete."
echo "To add QyTorrent to the app menu and Desktop:"
echo "  chmod +x packaging/linux/install-desktop.sh"
echo "  ./packaging/linux/install-desktop.sh"
echo ""
echo "Optional AppImage packaging still needs linuxdeployqt/appimagetool installed."
