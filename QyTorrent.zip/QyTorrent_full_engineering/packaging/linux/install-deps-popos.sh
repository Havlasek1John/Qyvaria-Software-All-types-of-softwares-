#!/usr/bin/env bash
set -euo pipefail
echo "Installing QyTorrent build/runtime dependencies for Pop!_OS / Ubuntu / Debian..."
sudo apt update
sudo apt install -y \
  build-essential cmake ninja-build pkg-config git \
  qt6-base-dev qt6-base-dev-tools qt6-qpa-plugins \
  libtorrent-rasterbar-dev libboost-system-dev libssl-dev zlib1g-dev
echo "Dependencies installed. Now run:"
echo "  ./packaging/linux/build-and-install-linux.sh"
