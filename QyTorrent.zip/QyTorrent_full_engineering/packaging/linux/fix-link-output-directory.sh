#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

python3 - <<'PY'
from pathlib import Path

p = Path("CMakeLists.txt")
s = p.read_text()
needle = 'qt_add_executable(QyTorrent ${QYTORRENT_SOURCES})\n'
block = '''
# Avoid Qt QML generated directory named "QyTorrent" colliding with the executable
# in older Qt/CMake builds. Put the real binary in build/bin/QyTorrent.
set_target_properties(QyTorrent PROPERTIES
  RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
)
'''
if 'RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"' not in s:
    s = s.replace(needle, needle + block + '\n')
p.write_text(s)

p = Path("src/main.cpp")
if p.exists():
    s = p.read_text()
    if 'loadFromModule("QyTorrent", "Main")' in s:
        if '#include <QUrl>' not in s:
            s = s.replace('#include <QIcon>\n', '#include <QIcon>\n#include <QUrl>\n')
        s = s.replace('    engine.loadFromModule("QyTorrent", "Main");\n',
'''    engine.load(QUrl(QStringLiteral("qrc:/qt/qml/QyTorrent/Main.qml")));
    if (engine.rootObjects().isEmpty()) {
        engine.load(QUrl(QStringLiteral("qrc:/QyTorrent/Main.qml")));
    }
''')
        p.write_text(s)

p = Path("src/core/TorrentSession.cpp")
if p.exists():
    s = p.read_text()
    s = s.replace('const bool activeDownload = !st.is_seeding && st.state != lt::torrent_status::paused;',
                  'const bool activeDownload = !st.is_seeding && !st.paused;')
    p.write_text(s)

p = Path("packaging/linux/install-desktop.sh")
if p.exists():
    s = p.read_text()
    if '"$PROJECT_ROOT/build/bin/QyTorrent"' not in s:
        s = s.replace('  "$PROJECT_ROOT/build/QyTorrent"\n',
                      '  "$PROJECT_ROOT/build/bin/QyTorrent"\n  "$PROJECT_ROOT/build/QyTorrent"\n')
    if '"$PROJECT_ROOT/build-appimage/bin/QyTorrent"' not in s:
        s = s.replace('  "$PROJECT_ROOT/build-appimage/QyTorrent"\n',
                      '  "$PROJECT_ROOT/build-appimage/bin/QyTorrent"\n  "$PROJECT_ROOT/build-appimage/QyTorrent"\n')
    p.write_text(s)
PY

rm -rf build
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel

chmod +x "$SCRIPT_DIR/install-desktop.sh"
"$SCRIPT_DIR/install-desktop.sh"

echo
echo "Built. Run:"
echo "  $PROJECT_ROOT/build/bin/QyTorrent"
