#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

if ! command -v cmake >/dev/null 2>&1; then
  echo "cmake is missing."
  echo "Install build tools with:"
  echo "  sudo apt update && sudo apt install -y build-essential cmake ninja-build pkg-config qt6-base-dev libtorrent-rasterbar-dev"
  exit 127
fi

if ! command -v ninja >/dev/null 2>&1; then
  echo "ninja-build is missing."
  echo "Install it with:"
  echo "  sudo apt install -y ninja-build"
  exit 127
fi

echo "Building QyTorrent Qt Widgets version. This version does not use QML, so it avoids missing QtQml.WorkerScript errors."
rm -rf build
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel

chmod +x packaging/linux/install-desktop.sh
./packaging/linux/install-desktop.sh

echo
echo "Built and installed launchers."
echo "Run now:"
echo "  packaging/linux/run-qytorrent.sh"
echo "or:"
echo "  ./build/bin/QyTorrent"
