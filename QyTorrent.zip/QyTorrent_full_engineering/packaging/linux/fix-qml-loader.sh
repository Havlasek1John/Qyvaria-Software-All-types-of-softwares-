#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

python3 - <<'PY'
from pathlib import Path
import re
main = Path("src/main.cpp")
s = main.read_text()
for inc in ['#include <QDir>', '#include <QFileInfo>', '#include <QDebug>']:
    if inc not in s:
        s = s.replace('#include <QUrl>\n', '#include <QUrl>\n' + inc + '\n')

new = '''    // Qt 6.4 compatibility: load the QML from the source tree first.
    // This avoids distro-specific qt_add_qml_module resource path differences.
    QStringList qmlCandidates;
    const QString projectRoot = qEnvironmentVariable("QYTORRENT_PROJECT_ROOT");
    if (!projectRoot.isEmpty()) {
        engine.addImportPath(projectRoot + "/src/qml");
        engine.addImportPath(projectRoot + "/src/qml/components");
        qmlCandidates << projectRoot + "/src/qml/Main.qml";
    }
    engine.addImportPath(QDir::currentPath() + "/src/qml");
    engine.addImportPath(QDir::currentPath() + "/src/qml/components");
    qmlCandidates
        << QDir::currentPath() + "/src/qml/Main.qml"
        << QCoreApplication::applicationDirPath() + "/../../src/qml/Main.qml"
        << QCoreApplication::applicationDirPath() + "/../src/qml/Main.qml";

    bool loaded = false;
    for (const QString &candidate : qmlCandidates) {
        if (QFileInfo::exists(candidate)) {
            engine.load(QUrl::fromLocalFile(QFileInfo(candidate).absoluteFilePath()));
            loaded = !engine.rootObjects().isEmpty();
            if (loaded) break;
        }
    }

    if (!loaded) {
        engine.load(QUrl(QStringLiteral("qrc:/qt/qml/QyTorrent/src/qml/Main.qml")));
    }
    if (engine.rootObjects().isEmpty()) {
        engine.load(QUrl(QStringLiteral("qrc:/qt/qml/QyTorrent/Main.qml")));
    }
    if (engine.rootObjects().isEmpty()) {
        engine.load(QUrl(QStringLiteral("qrc:/QyTorrent/Main.qml")));
    }

    if (engine.rootObjects().isEmpty()) {
        qCritical() << "QyTorrent could not load Main.qml. Tried local source tree and qrc paths.";
        return -1;
    }'''
s2 = re.sub(r'    // Qt 6\.4 compatibility:.*?if \(engine\.rootObjects\(\)\.isEmpty\(\)\) \{\n        return -1;\n    \}', new, s, flags=re.S)
if s2 == s:
    s2 = s.replace('    engine.loadFromModule("QyTorrent", "Main");\n\n    if (engine.rootObjects().isEmpty()) {\n        return -1;\n    }', new)
main.write_text(s2)

qml = Path("src/qml/Main.qml")
t = qml.read_text()
t = t.replace('import QyTorrent\n', '')
if 'import "components"' not in t:
    t = t.replace('import QtQuick.Layouts\n', 'import QtQuick.Layouts\nimport "components"\n')
qml.write_text(t)

for script in [Path("packaging/linux/run-qytorrent.sh"), Path("packaging/linux/run-qytorrent-debug.sh")]:
    if script.exists():
        r = script.read_text()
        if 'export QYTORRENT_PROJECT_ROOT=' not in r:
            r = r.replace('export QT_QUICK_CONTROLS_STYLE="${QT_QUICK_CONTROLS_STYLE:-Basic}"\n',
                          'export QT_QUICK_CONTROLS_STYLE="${QT_QUICK_CONTROLS_STYLE:-Basic}"\nexport QYTORRENT_PROJECT_ROOT="$PROJECT_ROOT"\n')
        script.write_text(r)
PY

rm -rf build
if command -v ninja >/dev/null 2>&1; then
  cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
else
  cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
fi
cmake --build build --parallel
chmod +x "$SCRIPT_DIR/install-desktop.sh" "$SCRIPT_DIR/run-qytorrent.sh" "$SCRIPT_DIR/run-qytorrent-debug.sh"
"$SCRIPT_DIR/install-desktop.sh"
echo ""
echo "Now run:"
echo "  $SCRIPT_DIR/run-qytorrent.sh"
