#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

chmod +x packaging/linux/install-deps-popos.sh || true
chmod +x packaging/linux/build-and-install-linux.sh
./packaging/linux/build-and-install-linux.sh

echo
echo "Starting QyTorrent..."
exec ./build/bin/QyTorrent
